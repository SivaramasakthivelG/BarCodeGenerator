related: [[Android Related]]

---

```kotlin
private fun setUpViewPager() {  
    Timber.d(" MediaBrowseListActivity setUpViewPager")  
    browseViewModel.start()  
    miniPlayerViewModel.start()  
    browseViewModel.getBrowseCategories()  
    pagerAdapter = BrowseListPagerAdapter(supportFragmentManager)  
    var defaultMediaItems = ArrayList<MediaBrowserCompat.MediaItem>()  
    var sortAndOrderedList = ArrayList<MediaBrowserCompat.MediaItem>()  
  
    binding?.browseListTab?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {  
        override fun onTabSelected(tab: TabLayout.Tab?) {  
            removeTooltip()  
        }  
  
        override fun onTabUnselected(tab: TabLayout.Tab?) {  
            removeTooltip()  
        }  
  
        override fun onTabReselected(tab: TabLayout.Tab?) {  
            removeTooltip()  
        }  
    })1
```