
[[Advantages of using Const]]

[[Lateinit vs lazy in kotlin]]

[[What is viewmodel and how it is useful]]

[[SDK]]

[[Context vs Application context]]


- Service 
- MVVM 
- Notification
- Push notification 
- Android lifecycle 
- Map & socket
- Retrofit 
- 