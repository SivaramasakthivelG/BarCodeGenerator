![[Pasted image 20241001133733.png]]



```java

 private static final int MOD = 1000000007;

  

    public int countGoodNumbers(long n) {

        return helper(n,0,1);

    }

  

    public int helper(long n, long i, long ans){

        if(n == i) return (int) ans;

  

        if(i % 2 == 0){

            ans= (ans*5)%MOD;

        }else{

            ans =(ans*4)%MOD;

        }

  

        return helper(n,i+1,ans);
```