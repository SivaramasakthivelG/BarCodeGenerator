---
Testing SetUp: Gradle works
---



testOptions {  
    unitTests {  
        includeAndroidResources = true  
    }  
}


testImplementation("org.robolectric:robolectric:4.10.3")  
testImplementation("org.mockito:mockito-core:3.12.4")



Related files: 

[[Using binding]]
[[Fragment Test Setup]]
