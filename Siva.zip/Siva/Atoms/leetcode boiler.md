[[leetcode]]

---

System.out.print();


```
for(int i = 0; i<n; i++){
		}

```

