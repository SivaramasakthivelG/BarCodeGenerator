
fun 1

NavigationState.Maneuver.Type.BEGINNING_OF_ROUTE ->  
    return R.drawable.direction_depart

NavigationState.Maneuver.Type.STRAIGHT

NavigationState.Maneuver.Type.ON_RAMP_SLIGHT_LEFT

NavigationState.Maneuver.Type.ON_RAMP_SLIGHT_RIGHT

NavigationState.Maneuver.Type.ON_RAMP_NORMAL_RIGHT

NavigationState.Maneuver.Type.ON_RAMP_SHARP_LEFT

NavigationState.Maneuver.Type.ON_RAMP_SHARP_RIGHT

NavigationState.Maneuver.Type.ON_RAMP_U_TURN_LEFT,  
NavigationState.Maneuver.Type.ROUNDABOUT_ENTER_AND_EXIT_CCW_U_TURN ->  
    return R.drawable.direction_uturn_left
    
NavigationState.Maneuver.Type.ON_RAMP_U_TURN_RIGHT,  
NavigationState.Maneuver.Type.ROUNDABOUT_ENTER_AND_EXIT_CW_U_TURN ->  
    return R.drawable.direction_uturn_right