![[Pasted image 20240606142745.png]]

[[realtime example]]