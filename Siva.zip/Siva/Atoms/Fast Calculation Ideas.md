[[Tables 11-20]]

[[Squares till 50]]

[[Mind math ideas]]

[[Cube roots]]

[[Square root ideas]]