```
Uri.parse("android.resource://app/src/main/res/drawable-nodpi/av_t_folder_playlist_icon.png")
```

