<svg width="214" height="203" viewBox="0 0 214 203" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">  
<g clip-path="url(#clip0_34877_624442)">  
<g filter="url(#filter0_f_34877_624442)">  
<path d="M197.73 200.68C197.73 192.748 188.157 185.141 171.116 179.533C154.076 173.924 130.964 170.773 106.865 170.773C82.7662 170.773 59.6543 173.924 42.6138 179.533C25.5733 185.141 16 192.748 16 200.68L106.865 200.68H197.73Z" fill="#006982" fill-opacity="0.8"/>  
</g>  
<circle cx="107" cy="65.7734" r="64" fill="url(#pattern0)" stroke="#20DFFA" stroke-width="2"/>  
 fill="white"/>  
</g>  
<defs>  
<filter id="filter0_f_34877_624442" x="-14" y="140.773" width="241.727" height="89.9062" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">  
<feFlood flood-opacity="0" result="BackgroundImageFix"/>  
<feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>  
<feGaussianBlur stdDeviation="15" result="effect1_foregroundBlur_34877_624442"/>  
</filter>  
<pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">  
<use xlink:href="#image0_34877_624442" transform="translate(-0.388889) scale(0.000925926)"/>  
</pattern>  
<clipPath id="clip0_34877_624442">  
<rect y="0.773438" width="214" height="202" rx="8" fill="white"/>  
</clipPath>  
<image id="image0_34877_624442" width="1920" height="1080" xlink:href="data:image/jpeg;basR4p9i8pR6dH//Z"/>  
</defs>  
</svg>