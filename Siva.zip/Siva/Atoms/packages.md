[[unit testing boiler plate]]

"com.android.bluetooth"


usb
"com.aptiv.mediaservice" 


alexa
"com.aptiv.alexavoice" 

"com.aptiv.androidauto"

Radio
"com.aptiv.radio.service"

"com.aptiv.carplay"

mtp
"com.aptiv.mtpservice"


MediaUtils.currentSrcPackage = "com.aptiv.mediaservice"