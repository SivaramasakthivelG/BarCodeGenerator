[[example floating action button]]

```kotlin

floatingActionButton: FloatingActionButton(  
  child: Icon(Icons.add),  
  onPressed: () async{  
    // navigatorKey.currentState?.pushNamed(Constants.TRACK_SCREEN);  
  
    TimeOfDay morningTime = TimeOfDay(hour: 8, minute: 25);  
  
    await NotificationService.showNotification(  
        medicineID: 1212,  
        title: "Morning",  
        body: "kjhj",  
        scheduleTime: morningTime);  
   /*  
    AddMedicineModel? medicineData;  
    DateTime dateTime = DateTime.now();    DateTime formattedDate = DateTime(dateTime.year, dateTime.month, dateTime.day);    String formattedDateString = DateFormat('yyyy-MM-dd HH:mm:ss.SSS').format(formattedDate);  
    String formattedTimeString = DateFormat('h:mm a').format(dateTime);  
    print('Date: $formattedDateString');    print('Time: $formattedTimeString');  
    await dbHelper.updateMedicineColorByNotification(884148283, formattedDateString,1);    */},  
),

```


```dart 


/* 
floatingActionButton: FloatingActionButton(
  heroTag: null,
  onPressed: () {
    Navigator.pushReplacement(
      context,
      CupertinoPageRoute(
        builder: (context) => AddPrescriptionPage(
          title: "Edit Prescription",
          editPrescriptionId: 0, // Default ID
          editPrescriptionName: "djfkd", // Default to empty string
          editHospitalName: "jdfhd", // Default to empty string
          onDate: DateFormat('dd-MMM-yyyy').format(DateTime.now()), // Default to current date
          isRemainderExtended: "TRUE",
          isFromExtend: "TRUE",
          editPrescriptionFromDate: DateTime.now(), // Default to today
          editPrescriptionToDate: DateTime.now().add(Duration(days: 7)), // Default to one week later
          followOnAction: "None", // Default action
          refreshCallBack: refreshPage,
        )
      ),
    );
  },
  child: Icon(Icons.add),
),
*/


```

