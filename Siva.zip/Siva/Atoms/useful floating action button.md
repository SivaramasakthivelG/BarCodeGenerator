[[example floating action button]]

```kotlin

floatingActionButton: FloatingActionButton(  
  child: Icon(Icons.add),  
  onPressed: () async{  
    // navigatorKey.currentState?.pushNamed(Constants.TRACK_SCREEN);  
  
    TimeOfDay morningTime = TimeOfDay(hour: 8, minute: 25);  
  
    await NotificationService.showNotification(  
        medicineID: 1212,  
        title: "Morning",  
        body: "kjhj",  
        scheduleTime: morningTime);  
   /*  
    AddMedicineModel? medicineData;  
    DateTime dateTime = DateTime.now();    DateTime formattedDate = DateTime(dateTime.year, dateTime.month, dateTime.day);    String formattedDateString = DateFormat('yyyy-MM-dd HH:mm:ss.SSS').format(formattedDate);  
    String formattedTimeString = DateFormat('h:mm a').format(dateTime);  
    print('Date: $formattedDateString');    print('Time: $formattedTimeString');  
    await dbHelper.updateMedicineColorByNotification(884148283, formattedDateString,1);    */},  
),

```