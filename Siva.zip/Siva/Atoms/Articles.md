
In grammatical context they are called determiners

![[Pasted image 20240626152314.png]]


![[Pasted image 20240626154058.png]]


![[Pasted image 20240626154336.png]]


![[Pasted image 20240626154841.png]]


![[Pasted image 20240626160016.png]]

![[Pasted image 20240626160259.png]]


![[Pasted image 20240626182721.png]]



![[Pasted image 20240626182706.png]]