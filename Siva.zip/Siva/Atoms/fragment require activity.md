---
Testing: require activity, fragment get activity, getactivity to a fragment
---

---

```kotlin
@Test  
fun verify_contactDetailedListFragmentVisibility() {  
    val activity =  
        Robolectric.buildActivity(CallActivity::class.java)  
            .create()  
            .start()  
            .resume()  
            .get()  
    val fragment = ContactsDetailListFragment(ContactsData())  
    fragment.arguments = Bundle()  
    activity  
        .supportFragmentManager  
        .beginTransaction()  
        .add(android.R.id.content, fragment, "")  
        .commitNow()  
    fragment.let {  
        val relativeLayout: ConstraintLayout =  
            it.requireActivity().findViewById(R.id.fragment_contact_detail)  
        Truth.assertThat(relativeLayout.visibility).isEqualTo(View.VISIBLE)  
    }  
}