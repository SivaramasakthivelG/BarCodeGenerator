[[Factors affecting process]]

---

1. Is the business understandable, Do you trust the promoter?
2. Market cap > INR 1000 cr
3. OPM > 10%
4. Profit making with low debt compared to the sector avg
5. Significant market share in the sector
6. Long runway for growth 
7. What is moat around the business? 
	- Unique selling points
8. what are the Green red and yellow flags for the company in the financial statements
9. What is the appropriate valuation range for this stock? 



some specific questions to raise
- Is the sector and the company has any macro threat or high competitive intensity?
- does the company have a strong acquisition strategy?
- Is that a business where beginner can enter and make money?
- can the company free to adjust prices in response to inflation? 

