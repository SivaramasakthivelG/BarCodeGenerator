---
Testing: javasetfield, javagetfield, Fragment scenario, fragment scenario different,Fragment,setfield
---
Related:
[[Fragment Test Setup]]
[[Fragment management]]
[[getView in fragments]]


---

![[HelpAndSupportFragmentTest.kt]]
The HelpAndSupportFragment covers different way of of getting layout inflator and binding and with anbu anna help java set field thing also new!

```
val livedate =  SxmDeviceManager::class.java.getDeclaredField("_isDeviceAvailable")
           livedate.isAccessible = true
           val test =    livedate.get(ServiceUtil.INSTANCE.serviceManager) as                                    MutableLiveData<Boolean>
           test.value = false
           test.value = true
```
