val room_version = "2.6.1"  
  
implementation("androidx.room:room-runtime:$room_version")  
annotationProcessor("androidx.room:room-compiler:$room_version")  

// To use Kotlin annotation processing tool (kapt)  
kapt("androidx.room:room-compiler:$room_version")