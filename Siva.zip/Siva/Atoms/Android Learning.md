
Simple concepts: 

Lambda
Trailing lambda


[[Must learn concepts]]

[[advanced android concepts]]
