[[Android Questions]]

---

Android plan
- 


Concepts on focus
- Work manager
- Firebase authentication
- Json parsing 
- web sockets
- tensorflow lite


[[Must learn concepts]]

[[advanced android concepts]]
