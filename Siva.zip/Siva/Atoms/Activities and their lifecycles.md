[[Android Related]]
next topic: [[Task, Back Stack & LaunchMode]]

---
_life cycle diagram: [[Pasted image 20240530113818.png]]
What is activity?

oncreate
onstart
onresume
onpause
onstop - onrestart
on destroy
