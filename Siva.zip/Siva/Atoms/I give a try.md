```

  
@RunWith(value = Parameterized::class)  
class CustomMediaSourceParmeterizedTest(val input: Bitmap,val expected: Boolean) {  
  
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()  
    @Test  
    fun test(){  
  
        val result = expected  
        val ink = input  
        assertEquals(expected,result)  
    }  
  
    companion object{  
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()  
  
        val b1 = BitmapFactory.decodeResource(context.resources,R.drawable.btn_preset_pressed)  
        val b2 = BitmapFactory.decodeResource(context.resources,R.drawable.ic_media_cover_usb)  
        @JvmStatic  
        @Parameters        fun data(): List<Array<Any>>{  
            return listOf(arrayOf(b1,true),  
                   arrayOf(b2,true))  
  
        }  
    }  
  
}  
@RunWith(value = Parameterized::class)  
class CustomMediaSourceParmeterizedTest(val input: Bitmap,val expected: Boolean) {  
  
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()  
    @Test  
    fun test(){  
  
        val result = expected  
        val ink = input  
        assertEquals(expected,result)  
    }  
  
    companion object{  
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()  
  
        val b1 = BitmapFactory.decodeResource(context.resources,R.drawable.btn_preset_pressed)  
        val b2 = BitmapFactory.decodeResource(context.resources,R.drawable.ic_media_cover_usb)  
        @JvmStatic  
        @Parameters        fun data(): List<Array<Any>>{  
            return listOf(arrayOf(b1,true),  
                   arrayOf(b2,true))  
  
        }  
    }  
  
}
```