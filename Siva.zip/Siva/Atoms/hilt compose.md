implementation ("com.google.dagger:hilt-android:2.48")  
kapt ("com.google.dagger:hilt-android-compiler:2.48")  
  
implementation("androidx.hilt:hilt-navigation-compose:1.2.0")