---
Testing: Reflection
---
![[Task 1.zip]]


```
 @Test  
	    fun verify_presetRecyclerView_whenFavoritesListIsNull() {  
	        launchFragmentInHiltContainer<FmFragment> {  
	            val presetRecyclerView: RecyclerView =  
                requireActivity().findViewById(R.id.preset_recycler_view)  
	//          ReflectionHelpers.setField(this,"presetLimit",ArrayList<FavStation>())  
	            val presetLimit = ReflectionHelpers.getField<ArrayList<FavStation>>(this,"presetLimit")  
	            assertThat(presetLimit.size).isNotNull()  
	            assertThat(presetRecyclerView).isNotNull()  
	            favoritesLiveData.value = null  
	            Shadows.shadowOf(Looper.getMainLooper()).idle()  
	            assertThat(presetRecyclerView.visibility).isEqualTo(View.GONE)  
        }  
    }
```
