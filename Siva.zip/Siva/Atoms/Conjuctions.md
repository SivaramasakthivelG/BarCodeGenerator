Conjunctions are joiners, they are used to join works, phrases, or clause.

"And","But" or "are" three common conjunction