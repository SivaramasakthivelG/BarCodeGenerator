```kotlin
/*
 * Copyright (c) 2022 Aptiv. All rights reserved.
 * Confidential - Restricted Aptiv information. Do not disclose.
 */
package com.aptiv.phone.ui.fragments.contacts

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Looper
import android.os.StrictMode
import android.os.StrictMode.VmPolicy.Builder
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.MutableLiveData
import com.android.car.ui.uxr.DrawableStateImageView
import com.aptiv.phone.HiltTestActivity
import com.aptiv.phone.MainCoroutineRule
import com.aptiv.phone.R
import com.aptiv.phone.databinding.ContactDetailListFragmentBinding
import com.aptiv.phone.foundation.domain.phoneManager.model.ContactNumbersData
import com.aptiv.phone.foundation.domain.phoneManager.model.ContactsData
import com.aptiv.phone.presentation.ContactDataItem
import com.aptiv.phone.presentation.viewmodel.ContactsViewModel
import com.aptiv.phone.utils.launchFragmentInHiltContainer
import com.google.common.truth.Truth
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import java.lang.reflect.Field
import java.lang.reflect.Method
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.MockitoAnnotations
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@HiltAndroidTest
@RunWith(RobolectricTestRunner::class)
@Config(application = HiltTestApplication::class)
class ContactDetailedListFragmentTest {
    @ExperimentalCoroutinesApi @get:Rule var mainCoroutineRule = MainCoroutineRule()
    @get:Rule(order = 0) val hiltInjectRule = HiltAndroidRule(this)
    private var contactDetailedListFragment: ContactsDetailListFragment? = null
    var binding: ContactDetailListFragmentBinding? = null

    var activity: HiltTestActivity? = null
    @Before
    fun init() {
        hiltInjectRule.inject()
        MockitoAnnotations.openMocks(this)

        val contactData =
            ContactsData(
                "1",
                "recherd",
                "1234567890",
                "2",
                "",
                "blr",
                "karnataka",
                "india",
                "gggg",
                "32323",
                "sdsd@sds.com",
                "1")

        contactDetailedListFragment = ContactsDetailListFragment(contactData)
        activity =
            Robolectric.buildActivity(HiltTestActivity::class.java).create().start().resume().get()
        val policy: StrictMode.VmPolicy = Builder().detectAll().penaltyLog().build()
        StrictMode.setVmPolicy(policy)
    }

    @Test
    fun verify_contactDetailedListFragmentVisibility() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            val relativeLayout: ConstraintLayout =
                this.requireActivity().findViewById(R.id.fragment_contact_detail)
            Truth.assertThat(relativeLayout.visibility).isEqualTo(View.VISIBLE)
        }
    }

    @Test
    fun verify_listener() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            val imageButton: DrawableStateImageView =
                this.requireActivity().findViewById(R.id.back_button)
            imageButton.performClick()
        }
    }
    /*@Test
    fun verify_listener_othervalue() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            val imageButton: ImageButton = this.requireActivity().findViewById(R.id.call_button)
            imageButton.performClick()
        }
    }*/
    @Test
    fun verify_setUpRecyclerView() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                val viewModelObj by activityViewModels<ContactsViewModel>()

                lateinit var contactItem: ContactsData
                lateinit var arrayList: ArrayList<ContactsData>
                lateinit var lst: MutableLiveData<ArrayList<ContactsData>>
                val contactList = MutableLiveData<List<ContactsData>>()
                var multiplecontact = MutableLiveData<List<ContactNumbersData>>()
                arrayList = ArrayList()
                val listContactNumbersData = ArrayList<ContactNumbersData>()
                contactItem =
                    ContactsData(
                        "1",
                        "richard",
                        "1234567890",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                val contactItem2 =
                    ContactsData(
                        "2",
                        "rechard",
                        "9876543210",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                arrayList.add(contactItem)
                arrayList.add(contactItem2)
                contactList.value = arrayList
                lst = MutableLiveData()
                lst.value = arrayList

                val contactItemData1 =
                    ContactNumbersData(
                        "1234567890",
                        1,
                        "1",
                        "rechard1",
                    )
                val contactItemData2 =
                    ContactNumbersData(
                        "1234567890",
                        2,
                        "2",
                        "rechard2",
                    )
                listContactNumbersData.add(contactItemData1)
                listContactNumbersData.add(contactItemData2)
                multiplecontact.value = listContactNumbersData
                viewModelObj.multiContactList = multiplecontact
                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "setMultipleContacts", List::class.java)
                method.isAccessible = true
                method.invoke(this, listContactNumbersData.toList())
            }
        }
    }

    @Test
    fun verify_setUpRecyclerView_null() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                val viewModelObj by activityViewModels<ContactsViewModel>()

                lateinit var contactItem: ContactsData
                lateinit var arrayList: ArrayList<ContactsData>
                lateinit var lst: MutableLiveData<ArrayList<ContactsData>>
                val contactList = MutableLiveData<List<ContactsData>>()
                var multiplecontact = MutableLiveData<List<ContactNumbersData>>()
                arrayList = ArrayList()
                val listContactNumbersData = ArrayList<ContactNumbersData>()
                contactItem =
                    ContactsData(
                        "1",
                        "richard",
                        "1234567890",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                val contactItem2 =
                    ContactsData(
                        "2",
                        "rechard",
                        "9876543210",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                arrayList.add(contactItem)
                arrayList.add(contactItem2)
                contactList.value = arrayList
                lst = MutableLiveData()
                lst.value = arrayList

                val contactItemData1 =
                    ContactNumbersData(
                        "1234567890",
                        1,
                        "1",
                        "rechard1",
                    )
                val contactItemData2 =
                    ContactNumbersData(
                        "1234567890",
                        2,
                        "2",
                        "rechard2",
                    )
                listContactNumbersData.add(contactItemData1)
                listContactNumbersData.add(contactItemData2)
                multiplecontact.value = null // listContactNumbersData
                viewModelObj.multiContactList = multiplecontact
                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "setMultipleContacts", List::class.java)
                method.isAccessible = true
                method.invoke(this, arrayList.toList())
            }
        }
    }

    @Test
    fun verify_setUpRecyclerView_null_object() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                val viewModelObj by activityViewModels<ContactsViewModel>()
                lateinit var contactItem: ContactsData
                lateinit var arrayList: ArrayList<ContactsData>
                lateinit var lst: MutableLiveData<ArrayList<ContactsData>>
                val contactList = MutableLiveData<List<ContactsData>>()
                var multiplecontact = MutableLiveData<List<ContactNumbersData>>()
                arrayList = ArrayList()
                val listContactNumbersData = ArrayList<ContactNumbersData>()
                contactItem =
                    ContactsData(
                        "1",
                        "richard",
                        "1234567890",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                val contactItem2 =
                    ContactsData(
                        "2",
                        "rechard",
                        "9876543210",
                        "mobile",
                        "abc",
                        "pune",
                        "Maharashtra",
                        "India",
                        "sb Road",
                        "426064",
                        "rechard@gmail.com",
                        "0")

                arrayList.add(contactItem)
                arrayList.add(contactItem2)
                contactList.value = arrayList
                lst = MutableLiveData()
                lst.value = arrayList

                val contactItemData1 =
                    ContactNumbersData(
                        "1234567890",
                        1,
                        "1",
                        "rechard1",
                    )
                val contactItemData2 =
                    ContactNumbersData(
                        "1234567890",
                        2,
                        "2",
                        "rechard2",
                    )
                listContactNumbersData.add(contactItemData1)
                listContactNumbersData.add(contactItemData2)
                multiplecontact.value = null // listContactNumbersData
                viewModelObj.multiContactList = null
                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "setMultipleContacts", List::class.java)
                method.isAccessible = true
                method.invoke(this, null)
            }
        }
    }

    @Test
    fun verify_setUpRecyclerView_empty() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            val viewModelObj by activityViewModels<ContactsViewModel>()
            var multiplecontact = MutableLiveData<List<ContactNumbersData>>()
            val listContactNumbersData = ArrayList<ContactNumbersData>()
            multiplecontact.value = listContactNumbersData
            viewModelObj.multiContactList = multiplecontact
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod(
                    "setMultipleContacts", List::class.java)
            method.isAccessible = true
            method.invoke(this, listContactNumbersData)
        }
    }

    @Test
    fun verify_checkAndUpdateContactDetails() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactsDetailListFragment::class.java.getDeclaredField("binding")
                nameField.isAccessible = true
                nameField.set(contactDetailedListFragment, binding)
                var contactDataItem =
                    ContactDataItem(
                        contactId = "1",
                        contactNumber = "9876543210",
                        contactName = "contactName",
                        contactType = "typeOfContact",
                        photoUri = "",
                        city = "city",
                        stateRegion = "stateRegion",
                        country = "country",
                        street = "street",
                        zip = "zip",
                        email = "email",
                        numbersCount = "1")

                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, contactDataItem)
                assert(binding?.emailName?.text.toString() == "email")
            }
        }
    }
    @Test
    fun verify_checkAndUpdateContactDetails1() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactDetailListFragmentBinding::class.java.getDeclaredField("binding")
                nameField.setAccessible(true)
                nameField.set(contactDetailedListFragment, binding)
                var contactDataItem =
                    ContactDataItem(
                        contactId = "1",
                        contactNumber = "9876543210",
                        contactName = "contactName",
                        contactType = "typeOfContact",
                        photoUri = "",
                        city = "city",
                        stateRegion = "stateRegion",
                        country = "country",
                        street = "street",
                        zip = "zip",
                        email = null,
                        numbersCount = "2")

                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, contactDataItem)
            }
        }
    }
    @Test
    fun verify_checkAndUpdateContactDetails2() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            binding = ContactDetailListFragmentBinding.bind(this.mView)
            val nameField: Field =
                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            nameField.setAccessible(true)
            nameField.set(contactDetailedListFragment, binding)
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod(
                    "checkAndUpdateContactDetails", ContactDataItem::class.java)
            method.isAccessible = true
            method.invoke(this, null)
        }
    }

    @Test
    fun verify_checkAndUpdateContactDetails_null() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactsDetailListFragment::class.java.getDeclaredField("binding")
                nameField.setAccessible(true)
                nameField.set(contactDetailedListFragment, binding)
                var mContactDataItem =
                    ContactDataItem(
                        contactId = "8",
                        contactNumber = "9876543210",
                        contactName = null,
                        contactType = "Mobile",
                        photoUri = null,
                        city = null,
                        stateRegion = null,
                        country = null,
                        street = null,
                        zip = null,
                        email = null,
                        numbersCount = "1")

                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, mContactDataItem)
            }
        }
    }

    @ExperimentalCoroutinesApi
    @Test
    fun verify_checkAndUpdateContactDetails_null_1() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactsDetailListFragment::class.java.getDeclaredField("binding")
                nameField.setAccessible(true)
                nameField.set(contactDetailedListFragment, binding)
                var mContactDataItem =
                    ContactDataItem(
                        contactId = "8",
                        contactNumber = null,
                        contactName = null,
                        contactType = "Mobile",
                        photoUri = null,
                        city = null,
                        stateRegion = null,
                        country = null,
                        street = null,
                        zip = null,
                        email = null,
                        numbersCount = "1")

                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, mContactDataItem)
            }
        }
    }

    @Test
    fun verify_variables() {
        contactDetailedListFragment!!.street = "null"
        contactDetailedListFragment!!.city = "null"
        contactDetailedListFragment!!.zip = "null"
        contactDetailedListFragment!!.state = "null"
        contactDetailedListFragment!!.country = "null"

        Assert.assertNotNull(contactDetailedListFragment!!.street)
        Assert.assertNotNull(contactDetailedListFragment!!.city)
        Assert.assertNotNull(contactDetailedListFragment!!.zip)
        Assert.assertNotNull(contactDetailedListFragment!!.state)
        Assert.assertNotNull(contactDetailedListFragment!!.country)
    }

    @Test
    fun verify_checkAndUpdateContactDetails_null_2() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactsDetailListFragment::class.java.getDeclaredField("binding")
                nameField.setAccessible(true)
                nameField.set(contactDetailedListFragment, binding)
                var mContactDataItem =
                    ContactDataItem(
                        contactId = "8",
                        contactNumber = "",
                        contactName = null,
                        contactType = "Mobile",
                        photoUri = null,
                        city = null,
                        stateRegion = null,
                        country = null,
                        street = null,
                        zip = null,
                        email = null,
                        numbersCount = "1")

                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, mContactDataItem)
            }
        }
    }

    @Test
    fun verify_setCurrentItem() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                /*this.setCurrentItem(
                ContactsData(
                    "1",
                    "richard",
                    "1234567890",
                    "2",
                    "",
                    "blr",
                    "karnataka",
                    "india",
                    "gggg",
                    "32323",
                    "sdsd@sds.com",
                    "2"))*/
            }
        }
    }

    @Test
    fun verify_setContactImage_null() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            binding = ContactDetailListFragmentBinding.bind(this.mView)
            val nameField: Field =
                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            nameField.isAccessible = true
            nameField.set(this, binding)
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod(
                    "setContactImage", String::class.java)
            method.isAccessible = true
            method.invoke(this, "1")
        }
    }

    @Test
    fun verify_setPhoto() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            binding = ContactDetailListFragmentBinding.bind(this.mView)
            val nameField: Field =
                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            nameField.isAccessible = true
            nameField.set(this, binding)
            val bitmap = BitmapFactory.decodeResource(resources, R.drawable.ic_phone)
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod(
                    "setPhoto", Bitmap::class.java)
            method.isAccessible = true
            method.invoke(this, bitmap)
        }
    }

    @Test
    fun verify_setPhoto_null() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            binding = ContactDetailListFragmentBinding.bind(this.mView)
            val nameField: Field =
                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            nameField.isAccessible = true
            nameField.set(this, binding)
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod(
                    "setPhoto", Bitmap::class.java)
            method.isAccessible = true
            method.invoke(this, null)
        }
    }

    @Test
    fun verify_checkAndUpdateContactDetails0() {
        runTest {
            launchFragmentInHiltContainer<ContactsDetailListFragment> {
                val viewModelObj by activityViewModels<ContactsViewModel>()
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                binding = ContactDetailListFragmentBinding.bind(this.mView)
                val nameField: Field =
                    ContactsDetailListFragment::class.java.getDeclaredField("binding")
                nameField.setAccessible(true)
                nameField.set(contactDetailedListFragment, binding)
                var contactDataItem =
                    ContactDataItem(
                        contactId = "1",
                        contactNumber = "9876543210",
                        contactName = "contactName",
                        contactType = "typeOfContact",
                        photoUri = "",
                        city = "city",
                        stateRegion = "stateRegion",
                        country = "country",
                        street = "street",
                        zip = "zip",
                        email = null,
                        numbersCount = "2")
                val listContactNumbersData = ArrayList<ContactNumbersData>()
                var multiplecontact = MutableLiveData<List<ContactNumbersData>>()
                //                listContactNumbersData.add(contactDataItem)
                //                multiplecontact.value = listContactNumbersData
                //                viewModelObj.multiContactList = multiplecontact
                val method: Method =
                    ContactsDetailListFragment::class.java.getDeclaredMethod(
                        "checkAndUpdateContactDetails", ContactDataItem::class.java)
                method.isAccessible = true
                method.invoke(this, contactDataItem)
            }
        }
    }
    @Test
    fun verify_onResume() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            //            binding = ContactDetailListFragmentBinding.bind(this.mView)
            //            val nameField: Field =
            //                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            //            nameField.isAccessible = true
            //            nameField.set(this, binding)
            val method: Method =
                ContactsDetailListFragment::class.java.getDeclaredMethod("onResume")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_onStart() {
        launchFragmentInHiltContainer<ContactsDetailListFragment> {
            //            binding = ContactDetailListFragmentBinding.bind(this.mView)
            //            val nameField: Field =
            //                ContactsDetailListFragment::class.java.getDeclaredField("binding")
            //            nameField.isAccessible = true
            //            nameField.set(this, binding)
            val method: Method = ContactsDetailListFragment::class.java.getDeclaredMethod("onStart")
            method.isAccessible = true
            method.invoke(this)
        }
    }
}
```