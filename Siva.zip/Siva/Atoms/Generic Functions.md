
```kotlin

class <T>Resource(name: T){


}

fun main(){
	val rats: Resource<String> = Resource("Dhoni")
}

```