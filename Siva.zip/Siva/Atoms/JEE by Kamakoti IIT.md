- Application of different concepts
- Higher order thinking skills
	- Quick Comprehension 

Not cleared JEE now chairman for JEE, he emphasis on
-  Hard work
-  Art
-  Triggering point


---

- Fail is a first attempt in learning
- 