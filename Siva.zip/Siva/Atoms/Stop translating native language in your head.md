Overloading - English video with subtitles, read and hear audio of a books.

Oversaturating - Do some long language listening works

Forced description - Try to describe surrounding

Shadowing - Repeat the phrases and pronunciations of English videos and content.

Visualization - Having an Image is very powerful in avoiding translating

English only dictionary

Repetition repeat what you learnt 