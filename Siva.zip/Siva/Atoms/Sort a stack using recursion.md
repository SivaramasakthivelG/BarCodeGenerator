

```java

public class Main {  
    public static void main(String[] args) {  
  
        Stack<Integer> st = new Stack<>();  
        st.push(9);  
        st.push(2);  
        st.push(3);  
  
        iterate(st);  
          
        System.out.println(st);  
  
  
  
    }  
  
    public static void iterate(Stack<Integer> st){  
        if(st.empty()){  
            return;  
        }  
  
        int current = st.pop();  
        iterate(st);  
  
        insertAtrightPos(st,current);  
    }  
  
    public static void insertAtrightPos(Stack<Integer> st, int temp){  
        if(st.empty() || st.peek() > temp){  
            st.push(temp);  
            return;  
        }  
  
        int current = st.pop();  
        insertAtrightPos(st,temp);  
  
        st.push(current);  
    }  
  
  
}

```