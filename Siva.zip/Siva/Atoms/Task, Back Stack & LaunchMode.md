
Task
BackStack
Launch Mode
	Standard
	SingleTop
	Single Task
	Single Instance