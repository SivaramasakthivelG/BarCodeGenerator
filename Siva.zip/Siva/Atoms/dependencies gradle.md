id("kotlin-kapt")

// retrofit  
implementation ("com.squareup.retrofit2:retrofit:2.9.0")  
implementation ("com.squareup.retrofit2:converter-gson:2.9.0")  
implementation "com.squareup.okhttp3:okhttp:5.0.0-alpha.2"

---

[[UT Setup]]

[[Splash Screen]]

[[viewModel and Coroutine]]

// [[Top-level build gradle]] file where you can add configuration options common to all sub-projects/modules.  

---

// Glide  
implementation("com.github.bumptech.glide:glide:4.11.0")  
kapt("com.github.bumptech.glide:compiler:4.11.0")

---

//viewmodel  
implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.2")  
implementation ("androidx.fragment:fragment-ktx:1.8.0")  

---

//paging  
implementation ("androidx.paging:paging-runtime-ktx:3.3.0")

---


//[[Dagger - Hilt(xml)]]

---


// Navigation Components  
implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")  
implementation("androidx.navigation:navigation-ui-ktx:2.7.7")

---

//livedata compose observe as state
implementation("androidx.compose.runtime:runtime-livedata:1.6.6") 



---

//[[room]]

---

image 
implementation("io.coil-kt:coil-compose:2.6.0")