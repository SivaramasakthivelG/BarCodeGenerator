[[find the if the array is sorted and rotated]]

GeeksforGeeks

---

```java

class Solution {
    // Function to return a list containing the union of the two arrays.
    public static ArrayList<Integer> findUnion(int arr1[], int arr2[], int n, int m) {
        int i = 0, j = 0;

        HashSet<Integer> hash = new HashSet<>();
        ArrayList<Integer> arrList = new ArrayList<>();

        while (i < n && j < m) {
            if (arr2[j] < arr1[i]) {
                hash.add(arr2[j]);
                j++;
            } 
            else if(arr2[j] == arr1[i]) {
                hash.add(arr1[i]);
                i++;
                j++;
            } else {
                hash.add(arr1[i]);
                i++;
            }
        }

        while (i < n) {
            hash.add(arr1[i]);
            i++;
        }

        while (j < m) {
            hash.add(arr2[j]);
            j++;
        }

        arrList = new ArrayList<>(hash);

        Collections.sort(arrList);

        return arrList;
    }
}

```

