---
Testing: Binding, Layout Inflation, alternate,
---
Parent: [[Unusual setfield]] - by using we can access full code.

```
@Before
    fun setUp() {
        helpAndSupportFragment = HelpAndSupportFragment()
        val inflater = LayoutInflater.from(ApplicationProvider.getApplicationContext())

        sxmDeviceManager = SxmDeviceManager()
        binding = FragmentHelpSupportBinding.inflate(inflater)

    }
```


Related: [[Using binding]]
