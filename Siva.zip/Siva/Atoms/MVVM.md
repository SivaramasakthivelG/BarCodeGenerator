[[MVI]]
[[DI(Dependency injections)]]
[[Coroutine series]]

---


Model - It is a repository which collects all data(data from api, service)
ViewModel - Business Logic (filter list, validation of users)
View - only contains the logic for views no business logic involved

