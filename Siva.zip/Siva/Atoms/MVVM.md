[[MVI]]
[[DI(Dependency injections)]]
[[Coroutine series]]

---
[[Dictionary app using MVVM and retrofit]]

- Model - It is a repository which collects all data(data from api, service) 
	- Fetch data(from remote api or your local repo's)
- ViewMdel - Business Logic (filter list, validation of users)
	- Bridge model and UI with Business logic
- View - only contains the logic for views no business logic involved
	- UI



