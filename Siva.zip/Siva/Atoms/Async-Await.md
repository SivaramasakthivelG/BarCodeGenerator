Parent:[[Coroutine series]]

---

```kotlin

fun asyncAwait() {  
    val TAG = "MainActivity"  
  
    GlobalScope.launch(Dispatchers.IO) {  
  
        val one = async {  
            doNetworkCall()  
            Log.d(TAG, "11")  
        }  
        Log.d(TAG, "${one.await()}")  
  
  
        val two = async {  
            doNetworkCall2()  
            Log.d(TAG, "33")  
        }  
        Log.d(TAG, "${two.await()}")  
  
  
        async {  
            delay(1000)  
            Log.d(TAG, "0000")  
        }  
    }}

suspend fun doNetworkCall(): String {  
    delay(5000L)  
    return "vina"  
}  
  
suspend fun doNetworkCall2(): String {  
    delay(3000L)  
    return "Siva"  
  
}

```

