








```

It's clear that, without clarity in mind, we can't decide at what price to buy? how much? so we need a strong valuation and monitoring framework to gain clarity without that we can't survive in market !

```












understanding business is very crucial or else only pain is the return !

