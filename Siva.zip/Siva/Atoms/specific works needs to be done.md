[[Important math concepts]]

For English: 
- 10 hard words
- listen one min video with foreign pronunciation


For Math:
- Learn fast calculation ideas 
- properties of square root
- tables


>In a school, out of 400 students, 300 students opt for at least one subject out of Biology, Chemistry and Mathematics. If 120 students opted for Biology, 150 students opted for Chemistry, 200 students opted for Mathematics and 30 opted for all the three subjects, find the number of students who opted for exactly two subjects.


