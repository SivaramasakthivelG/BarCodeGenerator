---
Kotlin: MutableList, list,
---
[[Fragment management]]

---


```fun main() {  
    val dataa: MutableList<Boolean> = mutableListOf(true)

    println(dataa)  
}

