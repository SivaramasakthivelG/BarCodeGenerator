---
Testing: fragment constructor problem fix, constructor now found, activity building aliter
---
related: [[fragment require activity]]


---

```kotlin

@Test  
fun verify_setUpRecyclerView() {  
    val activity =  
        Robolectric.buildActivity(CallActivity::class.java)  
            .create()  
            .start()  
            .resume()  
            .get()  
    val fragment = ContactsDetailListFragment(ContactsData())  
    fragment.arguments = Bundle()  
    activity  
        .supportFragmentManager  
        .beginTransaction()  
        .add(android.R.id.content, fragment, "")  
        .commitNow()  
    fragment.let {  
        val viewModelObj by it.activityViewModels<ContactsViewModel>()  
  
        lateinit var contactItem: ContactsData  
        lateinit var arrayList: ArrayList<ContactsData>  
        lateinit var lst: MutableLiveData<ArrayList<ContactsData>>  
        val contactList = MutableLiveData<List<ContactsData>>()  
        var multiplecontact = MutableLiveData<List<ContactNumbersData>>()  
        arrayList = ArrayList()  
        val listContactNumbersData = ArrayList<ContactNumbersData>()  
        contactItem =  
            ContactsData(  
                "1",  
                "richard",  
                "1234567890",  
                "mobile",  
                "abc",  
                "pune",  
                "Maharashtra",  
                "India",  
                "sb Road",  
                "426064",  
                "rechard@gmail.com",  
                "0")  
  
        val contactItem2 =  
            ContactsData(  
                "2",  
                "rechard",  
                "9876543210",  
                "mobile",  
                "abc",  
                "pune",  
                "Maharashtra",  
                "India",  
                "sb Road",  
                "426064",  
                "rechard@gmail.com",  
                "0")  
  
        arrayList.add(contactItem)  
        arrayList.add(contactItem2)  
        contactList.value = arrayList  
        lst = MutableLiveData()  
        lst.value = arrayList  
  
        val contactItemData1 =  
            ContactNumbersData(  
                "1234567890",  
                1,  
                "1",  
                "rechard1",  
            )  
        val contactItemData2 =  
            ContactNumbersData(  
                "1234567890",  
                2,  
                "2",  
                "rechard2",  
            )  
        listContactNumbersData.add(contactItemData1)  
        listContactNumbersData.add(contactItemData2)  
        multiplecontact.value = listContactNumbersData  
        viewModelObj.multiContactList = multiplecontact  
        val method: Method =  
            ContactsDetailListFragment::class.java.getDeclaredMethod(  
                "setMultipleContacts", List::class.java)  
        method.isAccessible = true  
        method.invoke(it, listContactNumbersData.toList())  
    }  
}

```