
![[Pasted image 20240520191651.png|800]]

```kotlin
@Test  
fun test_contextNull() {  
    Mockito.`when`(intent!!.action).thenReturn(Intent.ACTION_SCREEN_ON)  
    val mocContext = Mockito.mock(Context::class.java)  
    val userManager = Mockito.mock(UserManager::class.java)  
    Mockito.`when`(userManager.isSystemUser).thenReturn(false)  
    Mockito.`when`(mocContext.getSystemService(Context.USER_SERVICE)).thenReturn(userManager)  
    mediaBootCompleteReceiver!!.onReceive(mocContext, intent)  
}
```