related: [[Android Related]]
[[bias layout params]]

---
```kotlin

fun setMargin(view: View, left:Int, right:Int, top:Int, bottom:Int){  
  
    val layoutParams = view.layoutParams as? ViewGroup.MarginLayoutParams  
    layoutParams?.setMargins(left,top,right,bottom)  
    view.requestLayout()  
}
//calling that function

binding.mTvItemPlayableTitle.let { setMargin(it,100,0,0,0) }



```