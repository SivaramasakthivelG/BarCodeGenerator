---
Coroutine: first, dealy, global scope
---

next topic : [[Suspend function]]



---


```kotlin


package com.example.coroutines  
  
import android.content.ContentValues.TAG  
import androidx.appcompat.app.AppCompatActivity  
import android.os.Bundle  
import android.util.Log  
import kotlinx.coroutines.Delay  
import kotlinx.coroutines.GlobalScope  
import kotlinx.coroutines.delay  
import kotlinx.coroutines.launch  
  
class MainActivity : AppCompatActivity() {  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
        setContentView(R.layout.activity_main)  
  
        val TAG = "Main Activity"  
  
        GlobalScope.launch {  
            delay(3000L)  
            Log.d(TAG, "Coroutine is fun ${Thread.currentThread().name}")//2  
	    GlobalScope.launch {  
                delay(3000L)  
                Log.d(TAG, "This is Third  ${Thread.currentThread().name}")//2  
            }  
        }  
        Log.d(TAG, "outer scope ${Thread.currentThread().name}") //1  
  
  
        GlobalScope.launch {  
            delay(3000L)  
            Log.d(TAG, "T444444  ${Thread.currentThread().name}")//2  
        }  
  
  
    }  
  
}
```