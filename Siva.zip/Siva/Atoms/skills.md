Kotlin fundamentals
Co routines
Preference screens
Compose basics
MVVM, MVI basics

#### Punctual for Meetings

I consistently arrive on time for all scheduled meetings, prepared to contribute effectively.

#### Adherence to Accepted Boundaries on Attendance

I strictly adhere to the organization's attendance policies, ensuring reliability and responsibility.

#### HR Policies of the Organization

I comply with HR policies, promoting a harmonious and legally compliant workplace.

#### Respect to Others

I prioritize respect in all interactions, fostering a positive and inclusive work environment.



