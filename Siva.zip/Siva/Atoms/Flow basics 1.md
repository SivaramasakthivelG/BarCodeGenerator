Reactive programming - Being notified about changes in our code and sending them through a pipeline that potentially modifies them

A flow is a coroutine that can emit multiple values over a period of time 