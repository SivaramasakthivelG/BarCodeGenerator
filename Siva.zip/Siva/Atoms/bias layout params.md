related: [[dialog params]]
[[simple params]]
[[setMargin textview(layout params)]]
```kotlin

private fun updateOngoingCallOptionsUI(isSplit:Boolean){  
hideHoldButton(isTrue = isSplit)  
val holdLayoutParams = binding!!.ongoingCallOptions.hold._layoutParams_ as ConstraintLayout.LayoutParams  
holdLayoutParams._marginStart_ = if(isSplit) 42 else 0  
holdLayoutParams._marginEnd_ = if(isSplit) 88 else 153  
binding!!.ongoingCallOptions.hold._layoutParams_ = holdLayoutParams  
  
val dialerLayoutParams = binding!!.ongoingCallOptions.dialer._layoutParams_ as ConstraintLayout.LayoutParams  
dialerLayoutParams._marginEnd_ = if(isSplit) 88 else 153  
binding!!.ongoingCallOptions.dialer._layoutParams_ = dialerLayoutParams  
//  
// val optionEndCallLayoutParams = binding!!.ongoingCallOptions.optionEndCall.layoutParams as ConstraintLayout.LayoutParams  
// optionEndCallLayoutParams.horizontalBias = 0.5f  
// binding!!.ongoingCallOptions.optionEndCall.layoutParams = optionEndCallLayoutParams  
//  
val muteLayoutParams = binding!!.ongoingCallOptions.mute._layoutParams_ as ConstraintLayout.LayoutParams  
// muteLayoutParams.horizontalBias = 0.65f  
muteLayoutParams._marginStart_ = if(isSplit) 88 else 153  
binding!!.ongoingCallOptions.mute._layoutParams_ = muteLayoutParams  
//  
val transferLayoutParams = binding!!.ongoingCallOptions.transfer._layoutParams_ as ConstraintLayout.LayoutParams  
transferLayoutParams._marginEnd_ = if(isSplit) 30 else 0  
muteLayoutParams._marginStart_ = if(isSplit) 88 else 153  
binding!!.ongoingCallOptions.transfer._layoutParams_ = transferLayoutParams  
  
val callOption = binding!!.ongoingCallOptions.callOptions._layoutParams_ as ConstraintLayout.LayoutParams  
callOption._marginStart_ = if(isSplit) 20 else 0  
binding!!.ongoingCallOptions.callOptions._layoutParams_ = callOption  
  
binding!!.ongoingCallOptions.callOptions.requestLayout()  
  
}
```