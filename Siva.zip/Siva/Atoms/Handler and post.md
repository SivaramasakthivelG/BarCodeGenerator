```
Mockito.`when`(handler.post(ArgumentMatchers.any(Runnable::class.java))).thenAnswer {  
    (it.arguments[0] as Runnable).run()  
    true  
}

```

for valid post we need to take the handler from class and set that with out mock handler.


```
    mediaClientDataControl!!.mHandler = handler  
  
    Shadows.shadowOf(Looper.getMainLooper()).idle()  
```