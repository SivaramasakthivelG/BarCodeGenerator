related : [[Mockito]]
[[spy example]]

[[super spy example]]

next concept: [[Argument captor for anonymous classes]]

---

![[Pasted image 20240531114522.png]]

Here instead of stubbing using when we use spy to call the real implementation, yet need more clarification, for example when I normally call the interface with the value it also going to return 100, then what is the use of spying it 


[[Spy by aneesh misty]]