If you just want to be normal - May be your friendship is getting more serious than you expected or you have only lately realized how much you miss being on your own.

You're forgetting who you are 

you have your own baggage to work on.

If you language is different not speaking language

Moving away can also be a reason

If mindset doesn't aligns


