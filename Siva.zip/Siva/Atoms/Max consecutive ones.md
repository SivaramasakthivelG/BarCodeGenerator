`Concept
- We have to count the consecutive one and check whether its is max count, if yet replace or else return.

`


```kotlin


class Solution {

    fun findMaxConsecutiveOnes(nums: IntArray): Int {

        var max = 0;
        var res = 0;

        val n = nums.size

        for(i in 0 until nums.size){

            if(nums[i]==1){
                max++;

            }else {
                res = if(max>res) max else res
                max = 0;                
            }

        }

        return if(res>max) res else max

  

    }

}


```