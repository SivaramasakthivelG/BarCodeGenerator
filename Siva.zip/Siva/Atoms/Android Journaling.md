[[Splash screen with time control]]

[[Retrofit concept]]

[[Room Databast]]

[[Datastore store locally]]

[[Navigation Compose]]

