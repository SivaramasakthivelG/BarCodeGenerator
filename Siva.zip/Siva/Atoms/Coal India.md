[[Shyam analysis]]
