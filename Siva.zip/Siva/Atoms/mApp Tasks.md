#mapp
minus sound remove 
[[background service flutter]]
[[current task (notification)]]

---

dp update
```kotlin
Future<List<MedicineUpdateModel>> getVaryingDateRows(  
    int notificationId, String date) async {  
  List<MedicineUpdateModel> _medicineUpdateList = [];  
  Database? dbClient = await db as Database;  
  
  List<Map> maps = await dbClient.query(  
      tableMedicineUpdate,  
      where:  
      '$NotificationId = ? AND $columnMedicineVaryingDate = ?',  
      whereArgs: [notificationId,date]);  
  
  if (maps.isNotEmpty) {  
    maps.forEach((f) {  
      _medicineUpdateList  
          .add(MedicineUpdateModel.fromMap(f as Map<String, dynamic>));  
    });  
  }  
  
  return _medicineUpdateList;  
}
```