


![[Pasted image 20240905185546.png]]