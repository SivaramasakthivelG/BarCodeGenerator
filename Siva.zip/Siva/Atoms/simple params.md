val lp = analog_height.layoutParams as LinearLayout.LayoutParams  
lp.height = 213  
analog_height.layoutParams = lp