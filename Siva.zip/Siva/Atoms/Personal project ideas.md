[[Quotidian shorts]]
Expense Tracker
Poetry app
Crazy draw with stickers enabled and save to gallery options

Bit unusual apps for pure learning:
Email dumper
