We don't need multiple activities, fragments, xml, and importantly View and data binding also not needed.

Arrangement and alignment
video link: https://youtu.be/bo5TAnctPCA?si=pONWrEkusCjYKPHv

![[Pasted image 20240709164515.png]]


