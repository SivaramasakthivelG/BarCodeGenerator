[[Windows logo shortcuts]]
[[Linux commands]]

---

ctrl/shift/fn/prtscn - for cropped screenshots
