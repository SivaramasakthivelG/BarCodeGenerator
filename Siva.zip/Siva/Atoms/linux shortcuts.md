[[Windows logo shortcuts]]

---

ctrl/shift/fn/prtscn - for cropped screenshots
