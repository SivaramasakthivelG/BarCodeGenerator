[[Gradle checks before commit (jacoco)(gradle)(push)]]

---
logger commands--------

For Wifi - hisip_rtr AP F0 0D 31 01 01
 
For Hotspot - hisip_rtr AP F0 0D A4 01 01

Enabling the USB------------------------------------------------------------------ 
-> adb root
-> adb shell "echo host > /sys/bus/platform/devices/a600000.ssusb/mode"


Card enabling commands------------------------------------------------------------

P__DI_EE__Driv1Id

hisip_rtr AP F0 0D 44 01 00
hisip_rtr AP F0 0D 44 01 01
 
 
P__DI_EE__Driv2Id

hisip_rtr AP F0 0D 45 01 00
hisip_rtr AP F0 0D 45 01 01