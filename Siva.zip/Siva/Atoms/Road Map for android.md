Kotlin
Fundamental android concepts
- UI basics
- Permissions
- fragments
- navigations
- etc

 Jetpack compose
Avoid architecture patters, coroutine, clean architecture, coroutine like that stuff, And do something that works well...

---

Co routines and flow 
Work with local database (room lib)
Retrofit (Randrom duck like free api's available, weather api)
MVVM and MVI
Dependency injection

Build something like google calender where we use all the concepts with the necessary conecpts below 
- Authentication
- Caching strategy
- Reminders
- Data sync