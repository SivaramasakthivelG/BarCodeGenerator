val alertDialog = dialog.create()  
val window = alertDialog.window  
val layoutParams = window?.attributes  
layoutParams?.apply {  
    val marginInPixels = 38  
    y -= marginInPixels  
}  
window?.attributes = layoutParams  
return alertDialog