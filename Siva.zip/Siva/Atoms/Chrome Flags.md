chrome://flags/

---
related: [[Pc basic shortcuts]]