
- Read the question
- observe patterns slowly
- Note down the edge cases
- Write pseudocode
- Trial run
- Execute

