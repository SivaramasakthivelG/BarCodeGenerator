
https://youtube.com/watch?v=5SQP0qfUDjI&list=PL_EpgjfGg7lxpGJduJvu_HsNtrb9lCA-b

https://gist.github.com/mvaisakh/1a45694e33584592e8fae37fe29d757d

https://youtu.be/G1X-WKezZTM?si=EnBg1Hw1W6yTu_nv

https://youtu.be/OehS76YAoXs?si=y2f-z14boTlszrd2

https://youtu.be/j1v5yTOfo-4?si=c9QP_Tg5_NWwrqp9

https://youtu.be/hzm4sZVav_c?si=SAYC_HrK9jaiw8on