[[writing to learn]]
[[Learning List]]
[[Elon musk on learning]]

---
Video link : https://youtu.be/TDYa2pPMx0k?si=EWBjK4JfOONeOhE8

Links suggested by Python programmer for this video:
	Here are the links: 
	1. Teaching the Science of Learning - [https://gilesm.me/scienceoflearning](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbUtHbU9lbk5DYndsNHJrT010NHo1NGV4bUp1d3xBQ3Jtc0tueHBKSnR2UHBpMlZNTHdIRXFfZ1NKaHRXSlk5dDZrckUybHdvZ1dqU2NDNEZQU3NYeDRwV1FtTmRpTHNDdkdCZ0ZWSEk4OEh6SndZcDNyWmplUlNOY1VTb2gzWWRFa19sam1QckRKM2tsZWJqVjZEdw&q=https%3A%2F%2Fgilesm.me%2Fscienceoflearning&v=TDYa2pPMx0k) 
	2. Learning Scientists - [https://www.learningscientists.org/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbjhpZUZXRDZudlBRdGY2cHJTNU02aUJtN0JuZ3xBQ3Jtc0tsZ3o4el80S1VfODFSNDJxRElMc1Z3aVBCd1liUk5iZEEwMWVmN1p5c0JCWnFfZ1ZvUnR5YnZzOXZPVzNrd0xwTGdhMTFOUlFPLUV0WE1IVkktY3lRZm1rakVwOGl2QlVxak5tTUhqellHc01TbUhmcw&q=https%3A%2F%2Fwww.learningscientists.org%2F&v=TDYa2pPMx0k) 
	3. Coursera How to Learn Course - [https://gilesm.me/learninghowtolearn](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbXRiVkkteFlpYjNqVjlqVXhFWnQ5dU5Qenc4UXxBQ3Jtc0tsbU5wTjR5NlhBX3RiMkFyUlM5SnZoNUpJN2RBakRpM1RFT09OUE1aeDdqTUVaMXlaS19CRC1oU3ZoaGdFRWtvY01NX1N5ZXREdzA5dVRpRmRiQVlYNkdlUUNzeFlPYTFQd3pzbzBlTWlYTmlzZU5PNA&q=https%3A%2F%2Fgilesm.me%2Flearninghowtolearn&v=TDYa2pPMx0k) (affiliate) 
	4. Make it Stick - [https://amzn.to/3PWyLqc](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbGtkVzhrN1VvNTVZUUdrMElyWS1LX2R5T2hBZ3xBQ3Jtc0trTXJhYkpDNHI0amd4VGlpWmRKY0dSZ0l1WUpXMU9DSGRNVzdCTDZCaXI3WUhmei1ZMEdRaEd5eE5RNlhGR0R1S0p6cGc0c01QZkFOTHR4dmU5YXQxMHpIaXoxZUtVc2ctOTl1WEpleTBkQmtaaFdCdw&q=https%3A%2F%2Famzn.to%2F3PWyLqc&v=TDYa2pPMx0k) (affiliate link)



For learning anything you need Courage and Patience !
***Four Study Strategies*** to adopt
---
- Retrieval practice(Testing)
	- Our brain learn better when we try to retrieve info
	- It required more effort 
	- The hard you try to retrieve the info, the better you will learn and understand it.

- Distributed Practice 
	- Spaced learning is very effective, போட்டு திணிப்பதை விட
	- For example, to remember something for 1 Week, learning episodes should be 
	    be spaced to 12 to 24 hours.
	 - To remember something for 5 years, your space should be 6 month - 12 months apart.

- Interleaving
	- While reading books, the conventional approach is read all the books of a author then they move to another author, But you should interleave and switch to multiple books, It forces Testing and Distributed practice. 

- Elaborative Interrogation
	- ![[Pasted image 20231116014400.png]]
		- How and why questions !

***Two Strategies two avoid***
---
- Highlighting and Rereading the them! (என்னடா சொல்றீங்க)
- Highlighting creates an **Illusion you know everything**, Highlighting doesn't mean you understand them !
- So don't Color the pages!
- Don't copy paste.