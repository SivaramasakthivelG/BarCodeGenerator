---
Testing: dialog, dialog launcher,support fragment manager
---
related: [[Fragment Test Setup]]

---

```kotlin

@Test  
fun test_sampleDialog() {  
  
 contactDetailedListFragment.show(activity!!.supportFragmentManager,"tag")  
  
}

```