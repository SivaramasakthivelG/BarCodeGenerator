Get Rid of the Data You Don’t Need with Filters

Find Duplicates in Any List Quickly and Easily

Count Occurrences of a Name or Number with COUNTIF

Add up Numbers When a Certain Condition Is Met with SUMIF

Pull Info From Multiple Tables with VLOOKUP