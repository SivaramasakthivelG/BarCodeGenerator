---
Testing: getView, Fragments view, viewgroupt, xml fields using view, Mockito, Mockito when
tags:
  - mockitowhen
---


```
@Test
    fun test_setUpViews() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {

            val view = it.onCreateView(it.layoutInflater, it.view as ViewGroup, args)

            val imageButton = view?.findViewById<ImageButton>(R.id.ib_stop)
            val previousButton = view?.findViewById<ImageButton>(R.id.ib_prev)
            val fastForward = view?.findViewById<ImageButton>(R.id.ib_fast_forward)
            val fastRewind = view?.findViewById<ImageButton>(R.id.ib_fast_rewind)

            it.setupViews(view)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            val motionEvent = mock(MotionEvent::class.java)
            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_DOWN)

            imageButton!!.performClick()
            imageButton.dispatchTouchEvent(motionEvent)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_UP)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_UP)
            previousButton!!.performClick()
            previousButton.dispatchTouchEvent(motionEvent)
            previousButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            fastForward!!.performClick()
            fastForward.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)

            fastRewind!!.performClick()
            fastRewind.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_CANCEL)
            imageButton!!.performClick()
            imageButton.dispatchTouchEvent(motionEvent)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }