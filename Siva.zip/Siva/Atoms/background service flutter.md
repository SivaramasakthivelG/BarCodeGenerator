

- dbHelper.addNotificationSound(medicineID, text);
	- we can update the above method with time and date 
	- run a background service which triggers the _speaktext_ func when the time arrives 


```dart

  
class BackgroundService {  
  static final FlutterTts flutterTts = FlutterTts();  
  
  static void onStart(ServiceInstance service) async {  
    if (service is AndroidServiceInstance) {  
      service.on('start_speech').listen((event) async {  
        await _speakText("Hello! Notification received.");  
      });  
    }  
  }  
  
  static Future<void> initializeService() async {  
    final service = FlutterBackgroundService();  
  
    await service.configure(  
      androidConfiguration: AndroidConfiguration(  
        onStart: onStart,  
        isForegroundMode: true,  
      ),  
      iosConfiguration: IosConfiguration(  
        onForeground: onStart,  
      ),  
    );  
  
    await service.startService();  
  }  
  
  static Future<void> _speakText(String text) async {  
    final Completer<void> completer = Completer<void>();  
  
    await flutterTts.setVoice({'name': 'en-us-x-sfg#male_1-local', 'locale': 'en-US'});  
    await flutterTts.setSpeechRate(0.5);  
    await flutterTts.setVolume(1.0);  
    await flutterTts.setPitch(1.0);  
  
    flutterTts.setCompletionHandler(() {  
      if (!completer.isCompleted) {  
        completer.complete();  
      }  
    });  
  
    await flutterTts.speak(text);  
    await completer.future;  
    await flutterTts.stop();  
  }  
}

```