---
Testing: Mockito
---
[[Mockito solid Example]]

related: [[spy]]

//Basic mocking method

val mockData = Mockito.mock(Rooms::class.java)

//Using **when** with mock

Mockito.`when(Rooms.available()).thenreturn(71)`

*here the Rooms database accessing is skipped using our when function*

Idea of mockito is simple, its superbly explained by Aneesh misty.


Related:
[[Fragment Test Setup]]
[[Testing runnables]]