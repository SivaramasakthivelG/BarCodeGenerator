


```Java


public class Main
{
	public static void main(String[] args) {
        int num = 5;
        print(5);

		
	}
	
	public static void print(int num){
	    if(num == 0){
	        return;
	    }
	    
	    System.out.println(num);
	    print(num-1);
	}
}

```


```Java


public class Main {  
    public static void main(String[] args) {  
  
        printHello(5);  
  
    }  
  
    public static void printHello(int n){  
        if(n<=0) return;  
        printHello(n-1);  
        System.out.println("Hello" + n);  
    }  
}

```