```plantuml
@startuml

actor User

rectangle System {
    (Click on HMI Screen)
    (Launch AA or CP APK)
    (Update UI)
    (Update Tile)
}

User --> (Click on HMI Screen) : Settings Page (BT Connection)
(Click on HMI Screen) --> (Launch AA or CP APK) : Click on AA or CP
(Launch AA or CP APK) --> (Media UI updates) : Handled by Media Repo
(Launch AA or CP APK) --> (Tile UI updates) : Handled by Projection Tile Repo

@enduml

```



```plantuml
@startuml
left to right direction

actor User

rectangle "AA & CP Connection" {
    (HMI)
    (Launch AA or CP APK)
    (Update Media UI)
    (Update Tiles UI)
    (Update System UI)
}

User ..> (HMI) : Click Android Auto or Car Play
(HMI) --> (Launch AA or CP APK)
(Launch AA or CP APK) --> (Update System UI)
(Launch AA or CP APK) --> (Update Media UI) 
(Launch AA or CP APK) --> (Update Tiles UI) 

@enduml

```


flow now -> 
BT screen aa or cp click 
sendBroadcast with intent
launchers AA or CP apk
and Added to system UI
Tiles UI updated
Media UI updated
in Media if the user clicks the source change it happens in
media tab activity and go to source selection activity
there we switch source and update in UI






