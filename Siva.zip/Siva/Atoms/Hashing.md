![[Pasted image 20241003152034.png]]


Collision
- ![[Pasted image 20241003152123.png]]
- ![[Pasted image 20241003152107.png]]