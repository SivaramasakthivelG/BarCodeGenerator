Using routes.

- we need a Screens sealed class to define nav Screens
	- Also create classes for the screens say **Home** and **Details** for example


- To initiate navigation we need a composable function where we define NavHost and it has a parameter navController to setup Nav Host from main activity
	- this NavHost contains **Nav composable** functions which are suited for navigating using the screen
	- In this Nav composable we can also define arguments for the Screens, which are defined in the Screens Composable 


- define clickables and navigate as required.

- When the User launches the app, First screen shows home , when we click the home button by using nav controller we navigate to Details.
- on the Details if we apply popbakstash() then we come to home again if we click the Details.
- Also if we reforce it to home it comes to home, but backstash not poped, so we use popupto(Home) which navigate to Home by poping up the details screen

**Optional paramater**
- ```object Detail: Screen(route = "Detail?id={$ID}&name={$NAME}"){  
    fun putIdName(id: Int = 0, name: String = "Raju"): String{  
        return  "Detail?id=$id&name=$name"  
    }  
}

Here we declared the default values !

