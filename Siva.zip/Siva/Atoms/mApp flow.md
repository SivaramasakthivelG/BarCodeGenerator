[[mApp works done]]
[[mApp Tasks]]
[[useful floating action button]]
[[Snooze work]]
[[current task (notification)]]

---

Main.dart -> signup screen -> splash screen -> homeScreen

### From home screen
- ***MonitorMenu() -> SecondScreen()***
	- MonitorMenu loads as per the constructor params for all four sleep, movement, behaviour, functions
	- SecondScreen has symptoms and its update features (Dialog flow)
		- `_leftListViewContainer
			- `_leftGridItemOdd
		- `_rightListViewContainer
			- `_rightListViewContainer

- ***PrescriptionHomePage()*** -> 
	- **PrescriptionCompactListView** (Rx)
		- **AddPrescriptionPage**  (+ Icon to add Rx)
		- **NewViewPrescriptionPage** (> viewPrescription )

	- **NewMedicineView** (Medicines)
		- **NewMedicineExpandViewWithAdvice**

	- **MedicineTodayViewPage** (Track)
		- **MedicineTodayExpandView**

	- **ScheduleViewPage** (Schedule)
		- **MedicineExpandView** (> prescription) -> ScheduleChangePage
		- **TimeSlotExpandView** 
		- ScheduleChangePage (when we click thee prescription)

- ***DashBoard()*** ->

- ***Resources -> Only animation***


---

navigationDrawer -> contains excel logic

