Internet availability
Bathroom and room space, height, air flow, position
Water flow speed
