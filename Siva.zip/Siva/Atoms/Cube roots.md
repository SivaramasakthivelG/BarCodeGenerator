[[Cubes till 20]]


![[Pasted image 20240622124628.png]]




example 1 

![[Pasted image 20240622125012.png]]

example 2 
![[Pasted image 20240622125313.png]]