

```java

public class Main {  
    public static void main(String[] args) {  
  
        int[] arr = new int[]{5, 7, 8, 3, 2, 6};  
        int n = arr.length;  
        int index;  
        for (int i = 0; i < n; i++) {  
  
            index = getIndex(arr, i);  
            sort(arr,index,i);  
        }  
  
        for(int i: arr){  
            System.out.println(i);  
        }  
  
    }  
  
    public static int getIndex(int[] arr, int index) {  
        for (int i =index;i<arr.length;i++){  
            if(arr[index] > arr[i]){  
                index = i;  
            }  
        }  
  
        return index;  
    }  
  
    public static void sort(int[] arr, int index,int pos) {  
        int temp = arr[pos];  
        arr[pos] = arr[index];  
        arr[index] = temp;  
    }  
  
  
}

```