![[Pasted image 20240531165347.png]]

![[Pasted image 20240531165403.png]]

```
@Test  
@Throws(java.lang.Exception::class)  
fun testmTrackProgressRunnable() {  
  
    viewModel.isMediachanged = true  
  
    var track: Field =  
        NowPlayingViewModel::class.java.getDeclaredField
        ("mTrackProgressRunnable")  
    track.isAccessible = true  
    var trk = track.get(viewModel) as Runnable  
    trk.run()  
    assertNotNull(viewModel)  
}
```

