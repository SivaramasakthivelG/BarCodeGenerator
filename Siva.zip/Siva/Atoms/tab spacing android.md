
related: [[Android Related]]

---


for (i in 0 until binding?.browseListTab!!.tabCount) {  
    val tab = (binding?.browseListTab?.getChildAt(0) as ViewGroup).getChildAt(i)  
    val p = tab.layoutParams as ViewGroup.MarginLayoutParams  
    p.setMargins(0, 0, 8, 0)  
    tab.requestLayout()  
}

