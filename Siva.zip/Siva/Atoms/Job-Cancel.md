```kotlin

fun cancel(){  
    val TAG = "MainActivity"  
  
  
    val job = GlobalScope.launch(Dispatchers.IO){  
  
        for(i in 30..40){  
            fiboSeries(i)  
            if(isActive) Log.d(TAG, "$i")  
        }  
    }  
  
    runBlocking {  
        delay(3000)  
        job.cancel()  
        Log.d(TAG, "AAA")  
  
    }  
  
    GlobalScope.launch(Dispatchers.IO) {  
  
        Log.d(TAG, "BBB")  
    }  
  
  
}

```