
related: [[gitc - push code]]


Before code push we should check the velow all in andorid studio:  
./gradlew detekt  
./gradlew lintDebug 
./gradlew spotlessCheck  
./gradlew spotlessApply  
./gradlew jacocoTestReport  
./gradlew assemble


