[[Banking-  The next multibagger...]]

---
![[Pasted image 20240710194734.png]]


![[Pasted image 20240710194815.png]]


![[Pasted image 20240710194831.png]]



![[Pasted image 20240710195016.png]]



