[[Balance sheet]]

**what is goodwill writeoff:**
![[Pasted image 20240513115543.png]]

or Goodwill impairment.

**Working capital Crisis**

![[Pasted image 20240513123354.png]]

**Debt distress**
![[Pasted image 20240513133747.png]]