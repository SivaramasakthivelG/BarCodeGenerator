
Lateinit used to avoid null checks and null pointer exceptions, by using that we avoid initializing with null 
- Lateinit always be var
- it is mutable

```kotlin
val mentor : Mentor?= null
//which can done effectively using lateinit
lateinit var mentor: Mentor;

```


**Lazy**
It is used to defer the initialization of a instance, until it is used somewhere. 
used to defer initilization of expensive objects
- lazy is always val
- single instance created and used throughout





```kotlin

private val _detectedFaceCount = MutableStateFlow(0)  
val detectedFaceCount = _detectedFaceCount  
  
private val _bitmapList = MutableStateFlow<List<Bitmap>>(emptyList())  
val bitmapListFlow = _bitmapList.asStateFlow()  
  
val bitmapList: MutableList<Bitmap> = mutableListOf()  
  
private var captureCounter = 0  
private val captureInterval = 2000L

if (_detectedFaceCount.value >= 3 || captureCounter >= 3) {  
    imageProxy.close()  
    return  
}

faceBitmap?.let { bitmap ->  
    if (captureCounter < 3) {  
        CoroutineScope(Dispatchers.Main).launch {  
            delay(captureInterval * captureCounter)  
            if (captureCounter < 3) {  
                bitmapList.add(bitmap)  
                _bitmapList.value = bitmapList  
                Toast.makeText(  
                    context,  
                    "Image ${captureCounter.plus(1)} Captured",  
                    Toast.LENGTH_SHORT  
                ).show()  
                captureCounter++  
                Log.d(  
                    "Image Count",  
                    "Captured Images: ${bitmapList.size}"  
                )  
  
                if (captureCounter >= 3) {  
                    _detectedFaceCount.value = 3  
                }  
            }  
        }  
    }  
}

```