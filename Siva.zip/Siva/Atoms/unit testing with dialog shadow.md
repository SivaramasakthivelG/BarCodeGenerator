```kotlin

@Test
fun testOnCreateDialog_performSetButtonClick_2() {
    launchFragmentInHiltContainer<SocDialogFragment> {
        ReflectionHelpers.callInstanceMethod<Void>(
            this, "onCreateDialog",
            ReflectionHelpers.ClassParameter(String::class.java, "Test Title"),
            ReflectionHelpers.ClassParameter(Int::class.java, 0)
        )

        val fragmentView = requireView()
        val navController = mock<NavController>()
        Navigation.setViewNavController(fragmentView, navController)

        val dialog = ShadowDialog.getLatestDialog()
        val btnSet = dialog.findViewById<View>(R.id.set_button)
        btnSet.performClick()

        Shadows.shadowOf(Looper.getMainLooper()).idle()
    }
}


```