```

package com.example.composepractice  
  
import android.graphics.drawable.Icon  
import android.os.Bundle  
import android.view.View  
import android.widget.Toast  
import androidx.activity.ComponentActivity  
import androidx.activity.compose.setContent  
import androidx.activity.contextaware.ContextAware  
import androidx.activity.viewModels  
import androidx.compose.foundation.Image  
import androidx.compose.foundation.background  
import androidx.compose.foundation.clickable  
import androidx.compose.foundation.layout.Box  
import androidx.compose.foundation.layout.Column  
import androidx.compose.foundation.layout.Row  
import androidx.compose.foundation.layout.fillMaxSize  
import androidx.compose.foundation.layout.fillMaxWidth  
import androidx.compose.foundation.layout.height  
import androidx.compose.foundation.layout.padding  
import androidx.compose.foundation.layout.width  
import androidx.compose.material.icons.Icons  
import androidx.compose.material.icons.filled.Home  
import androidx.compose.material.icons.filled.Menu  
import androidx.compose.material.icons.filled.MoreVert  
import androidx.compose.material.icons.filled.Person  
import androidx.compose.material.icons.filled.Search  
import androidx.compose.material3.Divider  
import androidx.compose.material3.DrawerValue  
import androidx.compose.material3.ExperimentalMaterial3Api  
import androidx.compose.material3.Icon  
import androidx.compose.material3.IconButton  
import androidx.compose.material3.MaterialTheme  
import androidx.compose.material3.ModalDrawerSheet  
import androidx.compose.material3.ModalNavigationDrawer  
import androidx.compose.material3.NavigationDrawerItem  
import androidx.compose.material3.Surface  
import androidx.compose.material3.Text  
import androidx.compose.material3.TopAppBar  
import androidx.compose.material3.TopAppBarDefaults  
import androidx.compose.material3.rememberDrawerState  
import androidx.compose.runtime.*  
import androidx.compose.runtime.livedata.observeAsState  
import androidx.compose.ui.Alignment  
import androidx.compose.ui.Modifier  
import androidx.compose.ui.draw.blur  
import androidx.compose.ui.graphics.Color  
import androidx.compose.ui.platform.LocalContext  
import androidx.compose.ui.platform.LocalLifecycleOwner  
import androidx.compose.ui.res.painterResource  
import androidx.compose.ui.text.font.FontFamily  
import androidx.compose.ui.text.font.FontStyle  
import androidx.compose.ui.tooling.preview.Preview  
import androidx.compose.ui.unit.dp  
import androidx.compose.ui.unit.sp  
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen  
import androidx.lifecycle.Lifecycle  
import androidx.lifecycle.viewModelScope  
import androidx.navigation.compose.rememberNavController  
import com.example.composepractice.ui.theme.ComposePracticeTheme  
import com.example.composepractice.ui.theme.GreenWt  
import kotlinx.coroutines.delay  
import kotlinx.coroutines.launch  
  
class MainActivity : ComponentActivity() {  
  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
  
        actionBar?.hide()  
  
        val splashScreen = installSplashScreen()  
  
        val viewModel by viewModels<MainViewModel>()  
  
        splashScreen.setKeepOnScreenCondition {  
            viewModel.isReady.value == true  
        }  
  
        setContent {  
            ComposePracticeTheme {  
                Surface(color = MaterialTheme.colorScheme.background) {  
                    Column(modifier = Modifier.fillMaxSize()) {  
                        LearnTopAppBar()  
                        MainContent(viewModel)  
                    }  
                }            }        }    }  
}  
  
@OptIn(ExperimentalMaterial3Api::class)  
@Composable  
fun NavigationDrawer(){  
    val navController = rememberNavController()  
    val coroutineScope = rememberCoroutineScope()  
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)  
    val context = LocalContext.current.applicationContext  
  
    ModalNavigationDrawer(drawerState = drawerState, gesturesEnabled = true, drawerContent = {  
        ModalDrawerSheet {  
            Box(modifier = Modifier  
                .background(GreenWt)  
                .fillMaxWidth()  
                .height(140.dp)){  
                Text(text = "")  
            }  
            Divider()  
            NavigationDrawerItem(label = { Text(text = "Home", color = Color.Black) },  
                selected = false,  
                icon = { androidx.compose.material3.Icon(imageVector = Icons.Filled.Home,contentDescription ="Home")},  
                onClick = {  
                    coroutineScope.launch {  
                        drawerState.close()  
                    }  
                    navController.navigate(Screens.Home.screens){  
                        popUpTo(0)  
                    }  
                 })  
            NavigationDrawerItem(label = { Text(text = "Profile", color = Color.Black) },  
                selected = false,  
                icon = { androidx.compose.material3.Icon(imageVector = Icons.Filled.Person,contentDescription ="Profile")},  
                onClick = {  
                    coroutineScope.launch {  
                        drawerState.close()  
                    }  
                    navController.navigate(Screens.Profile.screens){  
                        popUpTo(0)  
                    }  
                 })  
        }  
    }) {  
            }  
  
  
}  
  
  
@Composable  
fun MainContent(viewModel: MainViewModel) {  
  
    val isReady by viewModel.isReady.observeAsState()  
  
    LaunchedEffect(Unit) {  
        if (isReady!!) {  
            delay(10000)  
            viewModel.setReady(false)  
        }  
    }  
    UpdateScreen(isReady!!)  
  
}  
  
@Composable  
fun UpdateScreen(state: Boolean) {  
    if (!state) {  
        Greeting(name = "Android")  
    } else {  
        Text(  
            "Loading...",  
            modifier = Modifier.fillMaxSize(),  
            style = MaterialTheme.typography.bodyLarge  
        )  
    }  
}  
  
@OptIn(ExperimentalMaterial3Api::class)  
@Composable  
fun LearnTopAppBar() {  
    val context = LocalContext.current  
    TopAppBar(title = { Text(text = "Whatsapp") }, navigationIcon = {  
        IconButton(onClick = {  
            Toast.makeText(context, "Whatsapp", Toast.LENGTH_SHORT).show()  
        }) {  
            Icon(  
                painter = painterResource(id = R.drawable.whatsapp_img),  
                contentDescription = "wt"  
            )  
        }  
    }, colors = TopAppBarDefaults.largeTopAppBarColors(  
        containerColor = GreenWt,  
        titleContentColor = Color.White,  
        navigationIconContentColor = Color.White,  
    ), actions = {  
        IconButton(onClick = {  
            Toast.makeText(context, "Profile", Toast.LENGTH_SHORT).show()  
        }) {  
            Icon(  
                imageVector = Icons.Filled.Person,  
                contentDescription = "Profile", tint = Color.White  
            )  
        }  
        IconButton(onClick = {  
            Toast.makeText(context, "Search", Toast.LENGTH_SHORT).show()  
        }) {  
            Icon(  
                imageVector = Icons.Filled.Search,  
                contentDescription = "Search", tint = Color.White  
            )  
        }  
        IconButton(onClick = {  
            Toast.makeText(context, "Menu", Toast.LENGTH_SHORT).show()  
        }) {  
            Icon(  
                imageVector = Icons.Filled.MoreVert,  
                contentDescription = "Menu", tint = Color.White  
            )  
        }  
    }    )  
  
}  
  
@Composable  
fun Greeting(name: String, modifier: Modifier = Modifier) {  
  
    val byte by remember {  
        mutableStateOf(0)  
    }  
  
    val context = LocalContext.current  
    val toast = {  
        Toast.makeText(context, "Wow $byte", Toast.LENGTH_SHORT).show()  
    }  
  
  
    Column(  
        modifier = Modifier  
            .padding(2.dp)  
            .height(500.dp)  
            .width(300.dp)  
    ) {  
        Text(  
            text = "Hello $name!",  
            modifier = modifier  
                .clickable(onClick = toast)  
                .background(Color.Magenta),  
            fontStyle = FontStyle(1),  
            fontFamily = FontFamily.SansSerif,  
            fontSize = 30.sp,  
        )  
  
        Image(  
            painter = painterResource(id = R.drawable.lion_image),  
            contentDescription = "Lion image"  
        )  
  
    }  
  
}  
  
@Preview(showBackground = true)  
@Composable  
fun GreetingPreview() {  
    ComposePracticeTheme {  
        NavigationDrawer()  
    }  
}

```