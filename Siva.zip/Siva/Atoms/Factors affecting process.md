Irregular sleep pattern
Irregular office timings
Missing scuttle but on weekends