


Shadows.shadowOf(Looper.getMainLooper()).idle()

ReflectionHelpers.setField(mediaWidgetService, "mBrowser", mBrowser)

```
ReflectionHelpers.callInstanceMethod<Void>(mediaWidgetService,"setDefaultAlbumArt",ReflectionHelpers.ClassParameter(RemoteViews::class.java,remoteViews))

```


**GetField**
```

val callback = ReflectionHelpers.getField<CarPropertyEventCallback>(mediaConnectorService, "carPropertyEventCallback")

```




val mockData = Mockito.mock(Rooms::class.java)


```
Mockito.`when`(Rooms.available()).thenreturn(71)

```



```
Shadows.shadowOf(Looper.getMainLooper()).runOneTask()
```

