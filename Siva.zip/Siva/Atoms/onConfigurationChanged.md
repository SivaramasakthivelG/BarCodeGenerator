```

@Test  
fun test_onConfigurationChanged() {  
    activity!!.apply {  
  
        val configuration = Configuration()  
        configuration.locale = Locale("Tamil","India")  
  
        ReflectionHelpers.callInstanceMethod<Void>(activity,"onConfigurationChanged",  
            ReflectionHelpers.ClassParameter(Configuration::class.java,configuration))  
        Shadows.shadowOf(Looper.getMainLooper()).idle()  
  
  
    }  
}

```

