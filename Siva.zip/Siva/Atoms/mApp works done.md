pixel 7 notification issue fixed 

voice speed changed and 3 minor fixes 