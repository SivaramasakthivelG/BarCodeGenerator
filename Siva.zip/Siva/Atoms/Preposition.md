![[Pasted image 20240626115144.png]]


**Time,Place,Position**

Prepositions and articles only preceeds a noun

![[Pasted image 20240626115737.png]]

![[Pasted image 20240626120335.png]]
according sound like a verb but according to is a compound preposition.


![[Pasted image 20240626120402.png]]

![[Pasted image 20240626125200.png]]
We informed by the authorities 


![[Pasted image 20240626140527.png]]


![[Pasted image 20240626140542.png]]

![[Pasted image 20240626140554.png]]

![[Pasted image 20240626140626.png]]

![[Pasted image 20240626140606.png]]