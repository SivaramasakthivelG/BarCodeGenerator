[[Excel]]
[[In android(Android learning list)]]

Priority
- Clean architecture
- Json handling, parse from website data 



Observer unitTest
override functions unitTest
spy
spy for throwing exceptions
test case for anonymous class
call back unit testing 
mockito then answer 