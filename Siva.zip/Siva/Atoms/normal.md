
```java

class Solution {

    public void rotate(int[] arr, int k) {

       int n = arr.length;

       while(k>0){

        int temp = arr[n-1];
        for(int i=n-1;i>0;i--){
           arr[i] = arr[i-1];
        }

        arr[0] = temp;
        k--;

        }

    }

}

```