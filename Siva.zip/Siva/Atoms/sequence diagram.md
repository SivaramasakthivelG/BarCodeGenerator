

```plantuml
@startuml
participant User
participant BluetoothUtils
participant CnhiProjectionSystemBarButton
participant MediatabActivity
participant MediaSourceManager
participant MediaBrowserManager
participant SystemUI

User -> BluetoothUtils: Press AA or CP
BluetoothUtils -> CnhiProjectionSystemBarButton: handleaacp() broadcast
activate CnhiProjectionSystemBarButton
CnhiProjectionSystemBarButton -> SystemUI: Update with AA or CP logo
deactivate CnhiProjectionSystemBarButton

activate MediatabActivity
MediatabActivity -> MediaSourceManager: Start SourceSelectionActivity
MediaSourceManager -> MediaBrowserManager: Observe currentSourceViewModel
MediaBrowserManager -> MediaBrowserManager: Register user action (AA/CP)
MediaBrowserManager -> SystemUI: Update Tiles (AA/CP)
deactivate MediatabActivity

@enduml

```

