
provider (listen vs watch):
- listen: false -> which is default
	- it won't rebuild the widget
- Watch
	- it rebuilds the widget


---
for giottus

Sliver
mizin
controllers
const 
final
basic oops 
statful, stateless widgets 
inkwell, gesture detectors
api integration
unit testing and Ui testing 
release process and proguart rules
higher order fucntions 
build context 
profiling 
accessing native code
memory leak 
error handling 
singleton,
db cration 
bloc , stream vs future 
Hydrated bloc 
routing (gorouter vs nav 2 )
material app 
git 
firebase 
ci/cd idea 
async/ await 
widget lifecycle
performance optimization 
widget tree management 
factory 
