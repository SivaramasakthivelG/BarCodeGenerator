what to do now ? 
अब क्या करें?

My home is two kilometers away
मेरा घर dho किलोमीटर दूर है

I teach my sister
मैं अपनी बहन को पढ़ाता हूँ

My sister teaches me 
मेरी बहन मुझे सिखाती है