adb root

adb remount

adb devices

adb connect 192.168.225.165

adb shell "echo host > /sys/bus/platform/devices/a600000.ssusb/mode"

adb install C:\8689mj\Ihp_Media_updated\Media\app\release\app-release.apk


updated wifi and hotspot the HSIP commands are 

**Enable Wifi:**

hisip_rtr AP F0 0D 31 01 01  
hisip_rtr AP F0 0D A3 01 01

**Enable Hotspot:**

hisip_rtr AP F0 0D 31 01 01  
hisip_rtr AP F0 0D A4 01 01