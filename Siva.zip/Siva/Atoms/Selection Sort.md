[[Selection sort readable code]]

we find max/min in an ascending or descending order then we continously swap with respective array items


```c



int select(int arr[], int i)
{
    int n = sizeof(arr)/sizeof(arr[0]);
    selectionSort(arr,n);
    return arr[i];
}


void selectionSort(int arr[], int n)
{
    int temp;
    for(int i = 0; i < n - 1; i++){
        int min = i;
        for(int j = i; j<n;j++){
        if(arr[j] < arr[min]){
            temp = arr[j];
            arr[j] = arr[min];
            arr[min] = temp;
        }
        }
    }
 
}

```