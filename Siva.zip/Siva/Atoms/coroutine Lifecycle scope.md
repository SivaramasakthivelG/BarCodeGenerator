[[Coroutine series]]
[[Activities and their lifecycles]]


---
global scope lives as long as the application lives


While using global scope the co routine is active even after it moves to the second activity
![[Pasted image 20231127194426.png]]


problem in global scope :
![[Pasted image 20231127194743.png]]




Now the first global scope is moved to lifecycle scope so now the co routine ends when the delay of 5 seconds 
![[Pasted image 20231127194556.png]]


Problem fix using **Lifecyclescope**

![[Pasted image 20231127194904.png]]