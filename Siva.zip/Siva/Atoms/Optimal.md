```java


class Solution {
    // Function for finding maximum and value pair
    public static int lenOfLongSubarr(int arr[], int n, int k) {
        
     HashMap<Integer,Integer> map = new HashMap<>();
     int maxlen = 0;
     int sum = 0;
     map.put(0,-1);
     for(int i=0; i<n;i++){
         sum+=arr[i];
         if(map.containsKey(sum-k)){
             maxlen = Math.max(maxlen,i-map.get(sum-k));
         }
         
         if(!map.containsKey(sum)){
             map.put(sum,i);
         }
         
     }
     
     return maxlen;
        
    }
}

```