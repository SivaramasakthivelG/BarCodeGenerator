[[leetcode boiler]]

---
1.  [[find the if the array is sorted and rotated]]

Problems:
- 290
- 392
- [560](https://leetcode.com/problems/subarray-sum-equals-k/)
- [791. Custom Sort String](https://leetcode.com/problems/custom-sort-string/)
- [767. Reorganize String](https://leetcode.com/problems/reorganize-string/)
- [2287. Rearrange Characters to Make Target String](https://leetcode.com/problems/rearrange-characters-to-make-target-string/)
- [1. Two Sum](https://leetcode.com/problems/two-sum/)
- 287
- 53
- 2554
- 315
- 15 (3Sum)
- 735



