1.  [[find the if the array is sorted and rotated]]
