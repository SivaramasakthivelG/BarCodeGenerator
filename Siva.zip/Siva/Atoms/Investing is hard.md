

```

Businesses are not excel spreadsheets 
businesses are people 

```

```

95% of due diligence is analyzing if customers and employees are happy and why. your edge is that 95% of investors will not do this

```

```

They only thing more important  than having great investment thesis is knowing what will kill your investment thesis and having the decisiveness to act 

```


```

If you're truly prepared than you should be prepared to be wrong 

```

