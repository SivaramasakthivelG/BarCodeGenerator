package com.aptiv.energyapphmi  
  
import android.content.Context  
import android.os.Bundle  
import android.view.LayoutInflater  
import androidx.fragment.app.testing.FragmentScenario  
import androidx.fragment.app.testing.launchFragmentInContainer  
import androidx.lifecycle.Lifecycle  
import androidx.test.core.app.ApplicationProvider  
import com.aptiv.energyapphmi.databinding.ActivityMainBinding  
import com.aptiv.energyapphmi.databinding.FragmentMainBinding  
import com.aptiv.energyapphmi.ui.MainFragment  
import org.junit.Before  
import org.junit.Test  
import org.junit.runner.RunWith  
import org.robolectric.Robolectric  
import org.robolectric.RobolectricTestRunner  
  
@RunWith(RobolectricTestRunner::class)  
class MainFragmentTest {  
  
//    lateinit var mainActivity: MainActivity  
//    private var fragmentHome: FragmentScenario<MainFragment>? = null  
//    private lateinit var binding: FragmentMainBinding  
//  
//    @Before  
//    fun setup() {  
//  
//        mainActivity = Robolectric.buildActivity(MainActivity::class.java).create().start().get()  
//  
//        val layoutInflater =  
//            ApplicationProvider.getApplicationContext<Context>()  
//                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as  
//                    LayoutInflater  
//        binding = FragmentMainBinding.inflate(layoutInflater)  
//  
//  
//    }  
  
    @Test  
    fun testFragmentLifeCycle() {  
//        val b = Bundle()  
//        fragmentHome =  
//            launchFragmentInContainer(  
//                fragmentArgs = Bundle(), initialState = Lifecycle.State.INITIALIZED  
//            )  
//        fragmentHome!!.moveToState(Lifecycle.State.CREATED)  
//        fragmentHome!!.onFragment { fragment ->  
//            fragment.onCreate(b)  
//            fragmentHome!!.onFragment { fragment ->  
//                fragment.onStart()  
//                fragmentHome!!.onFragment { fragment ->  
//                    fragment.onResume()  
//                    fragmentHome!!.onFragment { fragment ->  
//                        fragment.onPause()  
//                        fragmentHome!!.onFragment { fragment ->  
//                            fragment.onStop()  
//                            fragmentHome!!.onFragment { fragment -> fragment.onDestroy() }  
//                        }  
//                    }  
//                }  
//            }  
//        }  
    }  
  
}