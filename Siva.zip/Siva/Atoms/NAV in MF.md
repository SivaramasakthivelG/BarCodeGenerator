Mf are not nav based

They are theme based, market situation based and more importantly Portfolio based.