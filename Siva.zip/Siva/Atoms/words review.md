[[April review]]

---
Words to look for:

		intricate,
		abstruse, 
		valor, 
		perverse,
		impetus,	
		reproach




