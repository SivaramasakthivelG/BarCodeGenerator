
- sort a dictionary(contains string and age), by key (case insensisitive)
- given n, for every odd number update res variable (10,-5) back and forth 
- reverse a string 
- segregate odd and even number in an array 
- find a largest number in an array 
- 
