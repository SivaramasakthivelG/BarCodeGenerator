
```dart

/*bottomNavigationBar: BottomAppBar(  
  shape: CircularNotchedRectangle(),  child: Row(    mainAxisAlignment: MainAxisAlignment.spaceBetween,    children: [      SizedBox(        width: 150,        height: 50,        child: ElevatedButton(          onPressed: _cancelProcess,          style: ElevatedButton.styleFrom(            shape: RoundedRectangleBorder(                borderRadius: BorderRadius.circular(8)),          ),          child: Text("Cancel"),        ),      ),      SizedBox(        width: 150,        height: 50,        child: ElevatedButton(          onPressed: _processAnswer,          style: ElevatedButton.styleFrom(            shape: RoundedRectangleBorder(                borderRadius: BorderRadius.circular(8)),          ),          child: Text("Next"),        ),      ),    ],  ),),*/

```