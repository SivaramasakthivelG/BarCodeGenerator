
![[Pasted image 20231027163844.png]]