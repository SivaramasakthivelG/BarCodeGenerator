
```mermaid
graph TD;
    User_Clicks_Source-->Check_Source_Type;
    
    Check_Source_Type -->|Audio Package| Launch_AudioSetting_Screen;
    Check_Source_Type -->|MTP Connection| Launch_LauncherScreen_USB;
    Check_Source_Type -->|BT Connection| Launch_LauncherScreen_BT;
    Check_Source_Type -->|Android Auto| Launch_LauncherScreen_AndroidAuto;
    Check_Source_Type -->|Apple CarPlay| Launch_LauncherScreen_AppleCarPlay;
    Check_Source_Type -->|Alexa| Launch_LauncherScreen_Alexa;

    Launch_AudioSetting_Screen-->End;
    Launch_LauncherScreen_USB-->End;
    Launch_LauncherScreen_BT-->End;
    Launch_LauncherScreen_AndroidAuto-->End;
    Launch_LauncherScreen_AppleCarPlay-->End;
    Launch_LauncherScreen_Alexa-->End;

    classDef green fill:#9f9,stroke:#333,stroke-width:2px;
    classDef gray fill:#ddd,stroke:#333,stroke-width:2px;

    User_Clicks_Source:::green;
    Check_Source_Type:::gray;
    Launch_AudioSetting_Screen:::green;
    Launch_LauncherScreen_USB:::green;
    Launch_LauncherScreen_BT:::green;
    Launch_LauncherScreen_AndroidAuto:::green;
    Launch_LauncherScreen_AppleCarPlay:::green;
    Launch_LauncherScreen_Alexa:::green;
    End:::green;


```
]




```mermaid
sequenceDiagram
    participant RootView as RootView
    participant MediaSourceAdapter as MediaSourceAdapter
    participant onSourceSelection as onSourceSelection
    participant MediaHmiIntent as MediaHmiIntent
    participant RadioIntent as RadioIntent
    participant UpdateUI as UpdateUI

    RootView ->> MediaSourceAdapter: root.setOnClickListener(MediaSource)
    MediaSourceAdapter ->> onSourceSelection: Calls onSourceSelection function
    onSourceSelection -->> MediaHmiIntent: StartIntent for MediaHmi
    onSourceSelection -->> RadioIntent: StartIntent for Radio
    MediaHmiIntent -->> UpdateUI: Update UI for MediaHmi
    RadioIntent -->> UpdateUI: Update UI for Radio

```


```mermaid
graph TD;
    RootView[RootView] -->|Click Event| MediaSourceAdapter[MediaSourceAdapter];
    MediaSourceAdapter -->|Calls onSourceSelection| onSourceSelection[onSourceSelection];
    onSourceSelection -->|StartIntent for MediaHmi| MediaHmiIntent[MediaHmiIntent];
    onSourceSelection -->|StartIntent for Radio| RadioIntent[RadioIntent];
    MediaHmiIntent -->|Update UI for MediaHmi| UpdateUI[UpdateUI];
    RadioIntent -->|Update UI for Radio| UpdateUI;

```

```mermaid
flowchart TD;
    RootView[Root View] -->|Click Event| MediaSourceAdapter[MediaSourceAdapter];
    MediaSourceAdapter -->|Calls onSourceSelection| onSourceSelection[onSourceSelection];
    onSourceSelection -->|StartIntent for MediaHmi| MediaHmiIntent[MediaHmiIntent];
    onSourceSelection -->|StartIntent for Radio| RadioIntent[RadioIntent];
    MediaHmiIntent -->|Update UI for MediaHmi| UpdateUI[Update UI for MediaHmi];
    RadioIntent -->|Update UI for Radio| UpdateUI[Update UI for Radio];

    classDef rootViewStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef adapterStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef functionStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef intentStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef updateUIStyle fill:#f9f,stroke:#333,stroke-width:2px;

    style RootView rootViewStyle;
    style MediaSourceAdapter adapterStyle;
    style onSourceSelection functionStyle;
    style MediaHmiIntent intentStyle;
    style RadioIntent intentStyle;
    style UpdateUI updateUIStyle;

```


```mermaid
flowchart TD;
    RootView[Root View] -->|Click Event| MediaSourceAdapter[MediaSourceAdapter];
    MediaSourceAdapter --> onSourceSelection[onSourceSelection];
    onSourceSelection -->|Update Source UI| DecideIntent{StartMedia or RadioIntent};
    DecideIntent -->|If Media| MediaHmiIntent[LaunchMedia];
    DecideIntent -->|If Radio| RadioIntent[LaunchRadio];
    MediaHmiIntent -->|Update UI for MediaHmi|UpdateUI[Update UI for MediaHmi];
    RadioIntent -->|Update UI for Radio| UpdateUI[Navigation Update];

    classDef rootViewStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef adapterStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef functionStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef intentStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef updateUIStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef decisionStyle fill:#f9f,stroke:#333,stroke-width:2px,stroke-dasharray: 5, 5;

    style RootView rootViewStyle;
    style MediaSourceAdapter adapterStyle;
    style onSourceSelection functionStyle;
    style MediaHmiIntent intentStyle;
    style RadioIntent intentStyle;
    style UpdateUI updateUIStyle;
    style DecideIntent decisionStyle;

```






```mermaid
flowchart TD;
    RootView[Root View] -->|Click Event| MediaSourceAdapter[MediaSourceAdapter];
    MediaSourceAdapter -->|Calls onSourceSelection| onSourceSelection[onSourceSelection];
    onSourceSelection -->|Update Source UI| DecideIntent{Start Media or Radio Intent};
    DecideIntent -->|If Media| MediaHmiIntent[Launch Media];
    DecideIntent -->|If Radio| RadioIntent[Launch Radio];
    MediaHmiIntent -->|Update UI for MediaHmi| UpdateUI[Update UI for MediaHmi];
    RadioIntent -->|Update UI for Radio| UpdateUI[Navigation Update];

    classDef rootViewStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef adapterStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef functionStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef intentStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef updateUIStyle fill:#f9f,stroke:#333,stroke-width:2px;
    classDef decisionStyle fill:#f9f,stroke:#333,stroke-width:2px,stroke-dasharray: 5, 5;

    style RootView rootViewStyle;
    style MediaSourceAdapter adapterStyle;
    style onSourceSelection functionStyle;
    style MediaHmiIntent intentStyle;
    style RadioIntent intentStyle;
    style UpdateUI updateUIStyle;
    style DecideIntent decisionStyle;

```






