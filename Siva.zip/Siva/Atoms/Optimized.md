
```kotlin

fun rotate(nums: IntArray, k: Int) {
    val n = nums.size
    val arr = IntArray(n)  // Use IntArray instead of Array for better performance with primitive types

    for (i in 0 until n) {
        arr[(i + k) % n] = nums[i]
    }

    for (i in 0 until n) {
        nums[i] = arr[i]
    }
}


```