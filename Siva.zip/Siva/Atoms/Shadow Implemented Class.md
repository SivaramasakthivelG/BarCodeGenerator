package com.aptiv.dtsxmhmi.fragments

[[actvity get current focus ]]

---
###### Imports

import android.os.Bundle
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragment
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.lifecycle.Lifecycle
import com.aptiv.dtsxmhmi.R
import com.aptiv.dtsxmhmi.ServiceUtil
import com.aptiv.dtsxmhmi.main.delegate.PlayControlsDelegate
import com.aptiv.dtsxmhmi.main.events.EventNowPlaying
import com.aptiv.dtsxmhmi.main.events.EventPlayState
import com.aptiv.dtsxmhmi.main.events.EventScope
import com.aptiv.dtsxmhmi.main.events.EventServiceOnUpdate
import com.aptiv.dtsxmhmi.main.events.EventStartOverAvailabilityChange
import com.aptiv.dtsxmhmi.main.events.EventToggleSportsAlerts
import com.aptiv.dtsxmhmi.main.fragments.main.PlayControlsFragment
import com.aptiv.dtsxmhmi.main.viewmodels.NowPlayingViewModel
import com.aptiv.dtsxmhmi.shadow.ShadowNowPlayingInformationType
import com.aptiv.dtsxmhmi.shadow.ShadowPlayStateChangeServiceEvent
import com.siriusxm.emma.generated.MediaController
import com.siriusxm.emma.generated.NowPlayingInformationType
import com.siriusxm.emma.generated.ServiceEvent
import com.siriusxm.emma.generated.ServiceId
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

## Code


```

@RunWith(RobolectricTestRunner::class)
@Config(shadows = [ShadowPlayStateChangeServiceEvent::class, ShadowNowPlayingInformationType::class])
class PlayControlsFragmentTest {
    var fragmentScenario: FragmentScenario<PlayControlsFragment>? = null
    var args = Bundle()
    lateinit var mockFragment: PlayControlsFragment
    lateinit var mockView: View
    lateinit var npType: NowPlayingInformationType
    lateinit var mockPlayControlsDelegate: PlayControlsDelegate
    lateinit var mockEventServiceOnUpdate: EventServiceOnUpdate
    lateinit var ibStop: ImageButton
    lateinit var ibPrev: ImageButton
    lateinit var ibFastRewind: ImageButton
    lateinit var ibPlayPause: ImageButton
    lateinit var ibFastForward: ImageButton
    lateinit var ibNext: ImageButton
    lateinit var ibStartOver: Button
    lateinit var butLive: Button
    lateinit var ibNotifications: ImageButton
    lateinit var eventScope: EventScope
    private lateinit var mockServiceUtil: ServiceUtil

    @Before
    fun setUp() {
        ibStop = mock(ImageButton::class.java)
        ibPrev = mock(ImageButton::class.java)
        ibFastRewind = mock(ImageButton::class.java)
        ibPlayPause = mock(ImageButton::class.java)
        ibFastForward = mock(ImageButton::class.java)
        ibNext = mock(ImageButton::class.java)
        ibStartOver = mock(Button::class.java)
        butLive = mock(Button::class.java)
        mockFragment = mock(PlayControlsFragment::class.java)
        mockView = mock(View::class.java)
        mockServiceUtil = mock(ServiceUtil::class.java)
        npType = mock(NowPlayingInformationType::class.java)
        mockPlayControlsDelegate = mock(PlayControlsDelegate::class.java)
        ibNotifications = mock(ImageButton::class.java)
        eventScope = mock(EventScope::class.java)
        mockEventServiceOnUpdate = mock(EventServiceOnUpdate::class.java)

    }

    @Test
    fun testFragmentLifeCycle() {
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED
            )
        fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
        fragmentScenario!!.onFragment { fragment ->
            fragment.onCreate(args)
            fragmentScenario!!.onFragment { fragment ->
                fragment.onStart()
                fragmentScenario!!.onFragment { fragment ->
                    fragment.onResume()
                    fragmentScenario!!.onFragment { fragment ->
                        fragment.onPause()
                        fragmentScenario!!.onFragment { fragment ->
                            fragment.onStop()
                            fragmentScenario!!.onFragment { fragment -> fragment.onDestroy() }
                        }
                    }
                }
            }
        }
    }

    @Test
    fun test_OnDestroy() {
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED
            )
        fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
        fragmentScenario!!.onFragment { fragment ->
            fragment.onCreate(args)
            fragment.onDetach()
            fragment.onDestroy()
        }
    }

    @Test
    fun test_OnCreateView() {
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED
            )
        fragmentScenario!!.onFragment { fragment ->
            fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
            fragment.onCreate(args)
        }
    }


    @Test
    fun test_eventScope() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {


            val serviceId = Mockito.mock(ServiceId::class.java)
            val serviceEvent = Mockito.mock(ServiceEvent::class.java)

            ShadowPlayStateChangeServiceEvent.setOne(1)

            val eventServiceOnUpdate = EventServiceOnUpdate(serviceId, serviceEvent)
            eventServiceOnUpdate.emit()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)


            ShadowPlayStateChangeServiceEvent.setOne(0)

            val eventServiceOnUpdate1 = EventServiceOnUpdate(serviceId, serviceEvent)
            eventServiceOnUpdate1.emit()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)


            val playState =
                Mockito.mock(com.siriusxm.emma.generated.MediaController.PlayState::class.java)
            val eventPlayState = EventPlayState(playState)
            eventPlayState.emit()

            val eventStartOverAvailabilityChange = EventStartOverAvailabilityChange()
            eventStartOverAvailabilityChange.emit()

            val nowPlayingViewModel = Mockito.mock(NowPlayingViewModel::class.java)
            val eventNowPlaying = EventNowPlaying(nowPlayingViewModel)
            eventNowPlaying.emit()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)


            val toggleSportsAlerts = EventToggleSportsAlerts()
            toggleSportsAlerts.emit()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)


        }
    }


    @Test
    fun test_eventScope1() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {


            val serviceId = Mockito.mock(ServiceId::class.java)
            val serviceEvent = Mockito.mock(ServiceEvent::class.java)

            ShadowPlayStateChangeServiceEvent.setOne(1)

            val eventServiceOnUpdate = EventServiceOnUpdate(serviceId, serviceEvent)
            eventServiceOnUpdate.emit()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)
        }
    }

    @Test
    fun test_setUpViews() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {

            val view = it.onCreateView(it.layoutInflater, it.view as ViewGroup, args)

            val imageButton = view?.findViewById<ImageButton>(R.id.ib_stop)
            val previousButton = view?.findViewById<ImageButton>(R.id.ib_prev)
            val fastForward = view?.findViewById<ImageButton>(R.id.ib_fast_forward)
            val fastRewind = view?.findViewById<ImageButton>(R.id.ib_fast_rewind)

            it.setupViews(view)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            val motionEvent = mock(MotionEvent::class.java)
            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_DOWN)

            imageButton!!.performClick()
            imageButton.dispatchTouchEvent(motionEvent)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_UP)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_UP)
            previousButton!!.performClick()
            previousButton.dispatchTouchEvent(motionEvent)
            previousButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            fastForward!!.performClick()
            fastForward.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)

            fastRewind!!.performClick()
            fastRewind.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle(10000)

            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_CANCEL)
            imageButton!!.performClick()
            imageButton.dispatchTouchEvent(motionEvent)
            imageButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }

    @Test
    fun test_idPrevious() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {

            val view = it.onCreateView(it.layoutInflater, it.view as ViewGroup, args)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            val previousButton = view?.findViewById<ImageButton>(R.id.ib_prev)

            it.setupViews(view)
            Shadows.shadowOf(Looper.getMainLooper()).idle()


            val motionEvent = mock(MotionEvent::class.java)
            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_UP)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            previousButton!!.performClick()
            previousButton.dispatchTouchEvent(motionEvent)
            previousButton.dispatchTouchEvent(motionEvent)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }

    }

    @Test
    fun test_nowPlayingType_none() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {

            ShadowNowPlayingInformationType.setInformation(MediaController.NowPlayingInformation.None)

            it.updateViewState()

            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }

    @Test
    fun test_nowPlayingType_ArtistRadioChannel() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {

            ShadowNowPlayingInformationType.setInformation(MediaController.NowPlayingInformation.ArtistRadioChannel)

            it.updateViewState()

            Shadows.shadowOf(Looper.getMainLooper()).idle()

            ShadowNowPlayingInformationType.setInformation(MediaController.NowPlayingInformation.SportsChannel)

            it.updateViewState()

            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }

    @Test
    fun test_viewNull() {
        val scenario = launchFragment<PlayControlsFragment>()
        scenario.onFragment {
            it.setupViews(view = null)

        }
    }

}

```


