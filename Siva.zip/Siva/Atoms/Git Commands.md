---
Git: commands,keywords,git,
---
related: [[adb commands, aptiv, project,]]
[[Gradle checks before commit (jacoco)(gradle)(push)]]

---
git checkout master
git checkout origin/master

git push origin HEAD:refs/for/master
git pull --rebase


_git - user reset

git config --global --unset credential.helper

git config --global credential.helper store


---
