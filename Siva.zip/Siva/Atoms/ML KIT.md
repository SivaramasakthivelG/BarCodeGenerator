

```kotlin

override fun analyze(imageProxy: ImageProxy) {
    val mediaImage = imageProxy.image
    mediaImage?.let {
        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                // Log the number of detected faces
                val faceCount = faces.size
                println("Detected Faces: $faceCount")
            }
            .addOnFailureListener {
                println("Face detection failed: ${it.message}")
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }
}


```



```kotlin

Log.d("bitmapSize", "${bitmapList.size} ")  
Toast.makeText(context, "Rotate left and hold...", Toast.LENGTH_SHORT).show()  
delay(2000)  
bitmapList.add(bitmap)  
Log.d("bitmapSize", "${bitmapList.size} ")  
Toast.makeText(context, "Rotate left and hold...", Toast.LENGTH_SHORT).show()  
bitmapList.add(bitmap)  
  
imageProxy.close()

```

FaceSaver | deleted | Added | bitmapSize