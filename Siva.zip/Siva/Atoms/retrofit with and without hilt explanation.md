![[Pasted image 20241030182526.png]]

Normal method 
```kotlin

fun createSendGridService(): ApiService.SendGridService {  
    val retrofit = Retrofit.Builder()  
        .baseUrl("https://api.sendgrid.com/")  
        .addConverterFactory(GsonConverterFactory.create())  
        .build()  
  
    return retrofit.create(ApiService.SendGridService::class.java)  
    

```

>[!Important points]
>We return the api service directly here, with its function called sendGridService but using hilt we initially created a module for retrofit  
>
   Then we provide retrofit for a required api service    //then that api service is provided to the required repository}
   

>[!With Hilt]

```kotlin

  
@InstallIn(SingletonComponent::class)  
@Module  
object HiltModule {  
  
    @Singleton  
    @Provides    fun provideRetrofit(): Retrofit{  
        return Retrofit.Builder()  
            .baseUrl("https://api.dictionaryapi.dev/")  
            .addConverterFactory(GsonConverterFactory.create()) // this is to convert the json to kotlin data object  
            .build()  
    }  
  
    // in normal case we directly create this with val apiService = retrofit.create(ApiService::class.java), but we simplify things using hilt  
    @Provides  
    fun provideApiService(retrofit: Retrofit): ApiService {  
        return retrofit.create(ApiService::class.java)  
    }  
  
    @Provides  
    fun provideRepo(apiService: ApiService): DictionaryRepo {  
        return DictionaryRepo(apiService)  
    }  
  
}

```

![[Pasted image 20241030182733.png]]