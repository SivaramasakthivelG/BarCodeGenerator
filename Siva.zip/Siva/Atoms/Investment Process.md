Daily Process:
- Plan and study particular sectors slowly 
- Learn how to value that business 

In weekends:
- Nifty this week 
- 1Portfolio review

