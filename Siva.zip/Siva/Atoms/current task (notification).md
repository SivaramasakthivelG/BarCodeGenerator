
work manager can't schedule @ exact time 
Background and foreground service can't run with exact time for multiple reminders 
Alarm manager not compatiable with current version 

FCM is an option but we need online support 

