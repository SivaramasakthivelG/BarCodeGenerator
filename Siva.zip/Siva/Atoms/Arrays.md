Learnings needed:
- Hashmaps & hashsets, map and sets
- <span style="color:#00b0f0"><span style="color:#00b0f0"><span style="color:#ffff00">Modulus operations</span></span></span>
- <span style="color:#00b0f0">Understanding time and space complexitites</span>
- Collections vs Arrays

New concepts
- <span style="color:#ffff00">LinkedHashset</span>
- 
----

[[find the if the array is sorted and rotated]]

[[Union of Two Sorted Arrays]]

[[Second Largest without sorting]]

[[Max consecutive ones]]

[[Missing number without sort]]

[[Remove duplicates from sorted array]]

[[Rotate array right by one step]]

[[Rotate array by n step]]

[[Move zero's to end]]

[[Rotate array n times]]

Revision Needed Problems

[[Longest Sub-Array with sum K]]