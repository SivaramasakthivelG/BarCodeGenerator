
### Video one

Declaration 
Initialization

Reference variables  
Instance variables 

**reference variables are stored in stack** 

**new -> dynamically allocates memory & and returns reference to it** 

**Student kkk = new Student();**
**compile time    runtime**

"this" keyword -> used to point the reference variable, using that we can assign values (what object you are referring to?)

Objects are stored at heap memory, primitives are not objects 
primitives are stored in stack memory 

In java there is no pass by reference only pass by value 

the values of final primitives  cannot be changed 

when a non primitives is final, you cannot reassign it. 

Garbage collection:
- Finalize -> instruct java to garbage collection
- Process of removing unreferred objects from the heap 

----
### Video two

- Packages
	- creates compartments of the project 
	- we can create same names file in each packages but not two in same package
- Static in java  
	- Population is a global criterion which is independent of object, which leads to static concept 
	- they do not dependent on objects 
	- Static code runs at the start 
- Inner classes
	- Outer classes cannot be static 
- Singleton 
	- blocks using the class's constructors
	- so we make the constructor `private`

---

### Video three

- Inheritance 
	- base class variables and methods can be accessed to child class 
	- when calling child class constructor it also initialize the parent class variables and methods.
	- "super" keyword calls the parent class constructor 
	- "private variables cannot be accessed" even it is a parent class 
	- we can do this!
		- Box ab = new BoxWeight(4,5,6,4) (Box weight is a childClass) [[Pasted image 20250218180330.png]]
		- but we can't do the reverse, since we can't get variables inside the child class 
	- Every class inherits from object class 
	- if super not called in child class, default constructor always be called 
- types of inheritance 
	- Single inheritance - Java
	- Multilevel inheritance - Java
	- Multiple inheritance (not supported in java because if two parents have same variable and used in child class which one it will take?, due to this ambiguity.)
	- Hierarchical inheritance - Java 
	- Hybrid inheritance 
		- combination of single and multiple inheritance (not allowed in java)
- Polymorphism
	- compile time/static polymorphism
		- Methodoverloading
	- run time/ dynamic polymorphism
		- Methodoverriding
			- Parent obj = new Child();
			- done by Dynamic method dispatch 
	- If we make a class final implicitly its methods become final 
	- Static methods cannot be overridden simple logic 
- Encapsulation
	- solves implementation level issue means helps abstraction
	- 
- Abstraction
	- Abstract data types (List,set,map,queue)
	- non abstract data types (int, double, char, arrays)
	- solves design level issue 

---

### video four 
- protected 
	- can be accessed in the subclasses of different package but won't allow i in default for example: int a =8 
	- in other words: in different packages with protected only way to access it by extending the class 
- works 
	- create example for difference between default and protected 
	- and experiment with objects 

---

### Video five 
- Abstract classes
	- If a class contains one or more abstract methods, then it should be a abstract  class 
	- You cannot create object of an abstract class, unless you implement the methods of it, empty methods without implementations throws error 
- Interfaces 
	- We can implement multiple interfaces together 
	- Interface can extend other interfaces 
	- In java 8, interfaces can have default methods, which is useful and default methods can be overridden 
	- Can have static methods, called via the interface class's name 


---

### Video Six 
- Errors vs Exceptions in Java
	- Errors
		- We cannot write code to correct it.
		- Examples:
		  - Stack Overflow Error
		  - Memory Out of Bound
		  - Syntax Error
		  - Critical Issue Crashing the Application

- Exceptions
	- An **exception** is an error in code.
	- It **prevents the normal flow** of the program.
	- Examples:
	  - Dividing by Zero
	  - Number Format Exception
	  - Null Pointer Exception
	  - Parsing Error

- Hierarchy of Exceptions
	- Everything comes from:  
	  **`Object` → `Throwable`** → Divided into two:  
	  - **`Exception`** (Recoverable)
	  - **`Error`** (Irrecoverable)

 Types of Exceptions
1. **Checked Exceptions** (Compile-time)  
   - Example: `FileNotFoundException`
2. **Unchecked Exceptions** (Runtime)  
   - Example: `ArithmeticException`


 Exception Handling
- **Try, Catch, and Finally** are used to handle exceptions.
- We can **explicitly throw exceptions** using `throw`.
- **Multiple `catch` blocks** are allowed, but **only one `finally`** (makes sense).

---

### Video seven 
- ![[Pasted image 20250228204150.png]]
- Collections and maps are interfaces 
	- Vector is syncronized
		- 
		- 