
### Video one

Declaration 
Initialization

Reference variables  
Instance variables 

**reference variables are stored in stack** 

**new -> dynamically allocates memory & and returns reference to it** 

**Student kkk = new Student();**
**compile time    runtime**

"this" keyword -> used to point the reference variable, using that we can assign values (what object you are referring to?)

Objects are stored at heap memory, primitives are not objects 
primitives are stored in stack memory 

In java there is no pass by reference only pass by value 

the values of final primitives  cannot be changed 

when a non primitives is final, you cannot reassign it. 

Garbage collection:
- Finalize -> instruct java to garbage collection 
- Process of removing unreferred objects from the heap 

----
### Video two

- Packages
	- creates compartments of the project 
	- we can create same names file in each packages but not two in same package
- Static in java  
	- Population is a global criterion which is independent of object, which leads to static concept 
	- they do not dependent on objects 
	- Static code runs at the start 
- Inner classes
	- Outer classes cannot be static 
- Singleton 
	- blocks using the class's constructors
	- so we make the constructor `private`

---

### Video three

- Inheritance 
	- base class variables and methods can be accessed to child class 
	- when calling child class constructor it also initialize the parent class variables and methods.
	- "super" keyword calls the parent class constructor 
	- "private variables cannot be accessed" even it is a parent class 
	- we can do this!
		- Box ab = new BoxWeight(4,5,6,4) (Box weight is a childClass) [[Pasted image 20250218180330.png]]
		- but we can't do the reverse, since we can't get variables inside the child class 
	- Every class inherits from object class if not extented
	- if super not called in child class, default constructor always be called 
- types of inheritance 
	- Single inheritance 
	- Multilevel inheritance 
	- Multiple inheritance (not supported in java because if two parents have same variable and used in child class which one it will take?, due to this ambiguity.)
	- Hierarchical inheritance 
	- Hybrid inheritance 
		- combination of single and multiple inheritance (not allowed in java)
- Polymorphism
	- compile time/static polymorphism
		- Methodoverloading
	- run time/ dynamic polymorphism
		- Methodoverriding
			- Parent obj = new Child();
			- done by Dynamic method dispatch 
	- If we make a class final implicitly its methods become final 
	- Static methods cannot be overridden simple logic 
- Encapsulation
	- solves implementation level issue means helps abstraction
	- 
- Abstraction
	- Abstract data types (List,set,map,queue)
	- non abstract data types (int, double, char, arrays)
	- solves design level issue 