
**It's all comes down to being disciplined in weekdays**!
---

- Investing
	- Mint article
	- book reading
- Problem solving (Android)
- Hindi
- IITM (When on leave focus on revision or algebraically manipulating them better)

- We need daily 1-1.5 hrs for IITM, except in holidays.
- 2Hrs atleast for investment

---

**Saturday and Sunday abstract plan**
- Spend time with people
- Be relaxed watch a world cinema
- Review the week n plan 
- Revise weekly content for IITM
- Market wrap up (Plan for the week)

**Monthly must do**
- Portfolio review and valuation label (3rd week)
- While traveling Please read books or watch world cinema!
