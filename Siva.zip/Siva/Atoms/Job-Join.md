next [[Job-Cancel]]

---


- Join is used to stop the below scopes and function until the job ends.
- Jobs asyncly runs the above jobs.

```kotlin

class MainActivity : AppCompatActivity() {  
    @SuppressLint("SetTextI18n", "SuspiciousIndentation")  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
        setContentView(R.layout.activity_main)  
  
        val TAG = "MainActivity"  
  
  
        val job = GlobalScope.launch(Dispatchers.Default){  
            repeat(5){  
                delay(1000)  
                Log.d(TAG, "AD")  
            }  
  
        }  
        
        runBlocking {  
            job.join()  
            delay(2000)  
            Log.d(TAG, "AAA")  
        }  
  
        Log.d(TAG, "BBB")  
  
  
    }  
}

output
	First AD prints for 5 times , then AAA prints, later BBB because runblocking blocks Main(UI) thread. 
```




```kotlin

class MainActivity : AppCompatActivity() {  
    @SuppressLint("SetTextI18n", "SuspiciousIndentation")  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
        setContentView(R.layout.activity_main)  
  
        val TAG = "MainActivity"  
        
		Log.d(TAG, "BBB")  
  
        val job = GlobalScope.launch(Dispatchers.Default){  
            repeat(5){  
                delay(1000)  
                Log.d(TAG, "AD")  
            }  
  
        }  
        
        runBlocking {  
            job.join()  
            delay(2000)  
            Log.d(TAG, "AAA")  
  
        }  
    }  
}
śS
output
	So it executes in line by line so first BBB prints, later AD prints for 5 times , then AAA prints,  
```