[[Foundation from Aneesh Misty]]

---

Use spy when you need normal implementation of the instance also having the power to control it when needed 


![[Pasted image 20240605234001.png]]