![[Pasted image 20240529120343.png]]


![[Pasted image 20240529120457.png]]