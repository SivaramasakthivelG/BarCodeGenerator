<?xml version="1.0" encoding="utf-8"?>  
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"  
    xmlns:app="http://schemas.android.com/apk/res-auto"  
    xmlns:tools="http://schemas.android.com/tools"  
    android:id="@+id/cp_play_with_nav"  
    android:layout_width="match_parent"  
    android:layout_height="wrap_content">  
  
    <androidx.constraintlayout.widget.ConstraintLayout        android:layout_width="360dp"  
        android:layout_height="89.52dp"  
        android:background="@drawable/widget_bg_selector"  
        android:src="@drawable/aa_media_short_tile_bg"  
        android:orientation="vertical">  
  
        <ImageView            android:id="@+id/media_play"  
            android:layout_width="36dp"  
            android:layout_height="36dp"  
            android:layout_marginStart="@dimen/_22dp"  
            android:src="@drawable/cp_media_play"  
            app:layout_constraintBottom_toBottomOf="parent"  
            app:layout_constraintStart_toStartOf="parent"  
            app:layout_constraintTop_toTopOf="parent" />  
  
        <TextView            android:id="@+id/textView2"  
            android:layout_width="266dp"  
            android:layout_height="32dp"  
            android:layout_marginTop="7dp"  
            android:layout_marginEnd="18dp"  
            android:textSize="@dimen/_24sp"  
            app:layout_constraintBottom_toTopOf="@+id/textView"  
            app:layout_constraintEnd_toEndOf="parent"  
            app:layout_constraintTop_toTopOf="parent" />  
  
        <TextView            android:id="@+id/textView"  
            android:layout_width="266dp"  
            android:layout_height="44dp"  
            android:layout_marginEnd="18dp"  
            android:textSize="@dimen/_36sp"  
            android:layout_marginBottom="7.52dp"  
            app:layout_constraintBottom_toBottomOf="parent"  
            app:layout_constraintEnd_toEndOf="parent"  
            app:layout_constraintTop_toBottomOf="@+id/textView2" />  
  
  
    </androidx.constraintlayout.widget.ConstraintLayout>  
</RelativeLayout>