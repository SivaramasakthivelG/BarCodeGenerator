[[Android Related]]
[[MVVM]]

---
![[Pasted image 20240515110851.png]]

