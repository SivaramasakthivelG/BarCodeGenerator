[[Android Related]]
[[MVVM]]

---

Data Layer
- data 
Domain layer
- Business logic
Presentation layer
- Present

before clean architecture we should have strong fundamentals in
- Modular design 
- clear responsibilities
- Separation of concerns


![[Pasted image 20240515110851.png]]

