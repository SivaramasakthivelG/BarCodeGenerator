---
Testing: Shadow, Shadows,
---
Related: [[Shadow Implemented Class]]
[[unit testing boiler plate]]

[[Handler and post]]

---


```
package com.aptiv.dtsxmhmi.shadow;
import com.siriusxm.emma.generated.Banner;
import org.robolectric.annotation.Implementation;
import org.robolectric.annotation.Implements;

@Implements(Banner.class)
public class ShadowBanner {   

	private static String string = "Work";
	
	@Implementation
	public String actionLink() {
	return string;    
	}    

	private static void setString(String s){
	string = s;
	}


} 
```
