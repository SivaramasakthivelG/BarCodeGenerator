inequalities
Sum of square error detection 
distance with equation and a point 
Degrees of polynomial 