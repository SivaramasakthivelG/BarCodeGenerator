**11** * X 


![[Pasted image 20240622112900.png]]


$$(55)^2$$

Works with any two digit number ending with 5 

![[Pasted image 20240622113058.png]]

![[Pasted image 20240622113356.png]]


Best method for all 

![[Pasted image 20240625114629.png]]