
[[English]]

---

[[Standard equations]]

[[Quadratics summary]]

[[Fast Calculation Ideas]]

