[[Find all factorial]]

[[Sort a stack using recursion]]

