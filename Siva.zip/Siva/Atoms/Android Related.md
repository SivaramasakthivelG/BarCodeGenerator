[[Android Questions]]
[[AOSP contents]]

---

[[Useful Android ytube channels]]

[[Android Journaling]]

[[Foundation]]

[[First coroutine]] - First video in the coroutine playlist (use property coroutine to search)

[[UT Setup]] - Testing start (use property testing to search)

[[XML shorcuts]]

[[Android studio shortcuts Main]]

[[Androd Basic shortcuts]]

[[Road Map for android]]

[[Retrofit]]

[[Higher order functions]]

----------

[[dependencies gradle]]