[[Android Related]]
[[Using binding]]


---
buildFeatures {  
    viewBinding true  
}