implementation ("com.google.dagger:hilt-android:2.48")  
kapt ("com.google.dagger:hilt-android-compiler:2.48")  

implementation ("androidx.hilt:hilt-lifecycle-viewmodel:1.0.0-alpha03") 
kapt ("androidx.hilt:hilt-compiler:1.2.0")

[[hilt compose]]