[[Amara raja]]

[[Thomas cook]]

[[Brigade]]

[[Phoenix mills]]

[[Tata power]]

[[Apollo hosp]]

[[Siemens]]

[[Tata elexi]]

[[La Opala]]

[[Alum companies]]

[[Star health]]

