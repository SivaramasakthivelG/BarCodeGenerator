[[Generic Functions]]

```kotlin

val sigma:()->Unit ={
	//trailing lambda
}

val sigma = {

}

two are same, and importatly Lambda only returns last value.

```

```kotlin

val value = {
	println("Output")
}

fun isHeMad(bool: Boolean) = {
	return if(bool){
		value
	}
}

fun main(){
	val b = isHeMad(true)
	b()
	
}


```

```kotlin

//Inline function

fun high(isT: Boolean,playerName: (String)->(String)){
    if(isT){
        println(playerName("ravi"))
    }
}

fun main() {
    high(true){
        "hi $it"
    }
}

```


