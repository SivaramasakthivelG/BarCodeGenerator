

```kotlin

@Test  
fun testOnScrolled() {  
  
    val mockRecyclerView = mock(RecyclerView::class.java)  
  
    val myClass = RecyclerFastScroller(context)  
  
    myClass.attachRecyclerView(mockRecyclerView)  
  
    val captor = ArgumentCaptor.forClass(RecyclerView.OnScrollListener::class.java)  
  
    verify(mockRecyclerView).addOnScrollListener(captor.capture())  
  
    captor.value.onScrolled(mockRecyclerView, 10, 20)  
  
    val spyClass = spy(myClass)  
  
    spyClass.attachRecyclerView(mockRecyclerView)  
  
    captor.value.onScrolled(mockRecyclerView, 10, 20)  
}


```

