#strongRevision

[[Optimal]]

