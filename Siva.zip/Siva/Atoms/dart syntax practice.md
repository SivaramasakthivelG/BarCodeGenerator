[[mApp flow]]

---

``

```dart
Map<String, dynamic> users = {'raju': 2, 'akbar': 1, 'delhi': 3,'Ram': 5};  
  
  var sortByName = users.entries.toList()..sort((a,b) =>        a.key.toLowerCase().compareTo(b.key.toLowerCase()));  
  
    print(sortByName);

```


```dart
String str = "ravi";  
    String res = '';  
  
    for (int i = 0; i <= str.length-1; i++) {  
      res = str[i] + res;  
    }  
  
    print(res);

```

```dart
List<int> nums = [11, 12, 13];  
  
  int res = nums.reduce((a,b) => a+b);  
  
  print(res);
```

```dart

List<int> nums = [11, 12, 13];  
  
  var res = nums.map((a) => a*2).toList();  
  
  print(res);

```

```dart

void main() {  
  List<Map<String, dynamic>> users = [  
    {'name': 'Raj', 'age': 28},  
    {'name': 'Meena', 'age': 35},  
    {'name': 'John', 'age': 31},  
  ];  
  
  var youngest = users.reduce((a,b) => a['age'] < b['age'] ? a: b);  
  
  print(youngest);  
  
}

```

