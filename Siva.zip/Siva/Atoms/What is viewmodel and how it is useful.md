- Used to persist data during configuration changes
- Used for filtering logics

	