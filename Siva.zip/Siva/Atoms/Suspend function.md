---
Coroutine: Suspend fuction, run on ui thread, network call ,
---
next topic: [[Coroutine Dispatchers]]

---

>[!This scope takes 8Sec eventhough the second networkcall finishes in 3 seconds]
>**This is because both suspend fuctions called in same scope**


```kotlin

GlobalScope.launch {  
    val call = doNetworkCall()  
    val call1 = doNetworkCall2()  
  
    runOnUiThread {  
        val text1 = findViewById<TextView>(R.id.text1)  
        val text2 = findViewById<TextView>(R.id.text2)  
  
        text1.text = call  
        text2.text = call1  
    }  
}
suspend fun doNetworkCall():String{  
    delay(5000L)  
    return "vina"  
}  
  
suspend fun doNetworkCall2():String{  
    delay(3000L)  
    return "Siva"  
}
```

### Problem Fix 

>[!Now doNetworkCall runs first as normal]
>**Its because they are in different scope**

```kotlin

  
        GlobalScope.launch {  
            val call = doNetworkCall()  
//            val call1 = doNetworkCall2()  
  
            runOnUiThread {  
                val text1 = findViewById<TextView>(R.id.text1)  
//                val text2 = findViewById<TextView>(R.id.text2)
  
                text1.text = call  
//                text2.text = call1  
            }  
        }      
         
         GlobalScope.launch {  
//            val call = doNetworkCall()  
            val call1 = doNetworkCall2()  
  
            runOnUiThread {  
//                val text1 = findViewById<TextView>(R.id.text1)  
                val text2 = findViewById<TextView>(R.id.text2)  
  
//                text1.text = call  
                text2.text = call1  
            }  
        }  
    }  
  
  
    suspend fun doNetworkCall():String{  
        delay(5000L)  
        return "vina"  
    }  
  
    suspend fun doNetworkCall2():String{  
        delay(3000L)  
        return "Siva"  
    }

```