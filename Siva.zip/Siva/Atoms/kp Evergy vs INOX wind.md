Wind india 12Gigawatts

india plans to increase it to 140GW by 2030

Business overview:
### kp energy
- Kp energy is engaged in the business of providing the balance of plant(BoP) solutions to the wind energy sector
- It begins the journey of a windmill and helps them
- it operates a portfolio of win energy generation assets with a total capacity of 18.4 MW 
- It alo maintains windforms of 200MW
- some of the clients include NTPC, aditya Birla renewable energy and apraava energy.

`Market cap - 23.7 billion`
`Order book in MW - 888.1`

### Inox Wind
- Inox provides engineering, procurement and construction(EPC services) to wind farms
- in december 2023 the company's board approved the amalgamation of inox wind energy with inox wind
- Inox wind manufacturer of wind turbine generators and also provides end to end turnkey solutions, from site acquisition to development operations and maintenance of wind power projects.
- it also has 4 manu plants with a cumulative capacity to produce 1900MW of nacelle and hubs, 1600 MW of blades, and 600MW of towers
- Some of its clients include tata power, adani, ntpc, nhpc and oil india

`Market cap - 167.9 billion`
`Order book in MW - 1276.1`


Revenue: 
KP energy - CAGR - 22.5 in last 5 years, 
Inox wind - (12 %)

Profitability:
Kp energy 16.3% and 17.7 % growth in ebita 
inox energy negative 

debt management:
inox wind has negative interest coverage ratio
interest coveage ratio is 11.7X for kp energy

financial efficiency:
kp - 43%
inox - (13.3)

Valuation:
P/E
P/B

extra:
kp also focuses on solar 

