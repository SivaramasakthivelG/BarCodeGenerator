Navigation
Retrofit
Room
Co routine
Flow
MVVM

---

HILT
UT
Clean architecture

---

TDD