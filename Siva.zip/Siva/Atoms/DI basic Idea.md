// Step 3: Create a Dependency Module  
@Module  
class AppModule {  
    @Provides  
    fun provideSomeDependency(): SomeDependency {  
        return SomeDependencyImpl()  
    }  
}

// Step 4: Annotate a class for injection  
class MyActivity : AppCompatActivity() {  
    @Inject  
    lateinit var someDependency: SomeDependency

    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
  
        // Step 6: Perform Injection  
        (applicationContext as MyApplication).appComponent.inject(this)  
  
        // Step 7: Use Injected Dependencies  
        someDependency.doSomething()  
    }  
}