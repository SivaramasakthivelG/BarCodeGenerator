Hindi
Mint article 