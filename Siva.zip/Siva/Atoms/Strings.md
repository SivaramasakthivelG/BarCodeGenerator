

[[Isomorphic strings]]