---
Testing: Reflection
---

oncreate extraction

```
@Testfun test_onCreate() {    Mockito.`when`(sportsEventDialogItem.homeTeam).thenReturn(hometaem)    Mockito.`when`(sportsEventDialogItem.awayTeam).thenReturn(awaytaem)    Mockito.`when`(scalarSportsEventState.get()).thenReturn(SportsEventState.Delayed)    Mockito.`when`(sportsevent.state()).thenReturn(scalarSportsEventState)    Mockito.`when`(sportsEventDialogItem.sportEvent).thenReturn(sportsevent)    sportEventDialog = SportEventDialog(context, sportsEventDialogItem,{},{})    ReflectionHelpers.callInstanceMethod<Unit>(sportEventDialog,"onCreate",ReflectionHelpers.ClassParameter.from(Bundle::class.java,args))}
```


val args = Bundle()

Related: 
[[UT Setup]]
[[onConfigurationChanged]]
