[[mApp flow]]

---

Dashboard flow

- Secondsceen.dart
	- dbHelper.insertMainData(element);

- Dashboard.dart
	- build() (UI)
		- buildCategory
		- buildTask
		- buildActivity
	- getChartWidget
		- SyncfusionTimeAnnotationChart.dart
			- getActivityRecordSyncFusion (gets all records from db)
		- SyncFustionTimeChartViewModel.dart
			- plotChartDataSync (SCATTER)
				- ScatterSeries<LinearActivity, DateTime>
				- getBandSymptomsDetails
				- showBandSymptomDialog
			- plotLineChart
				- showPlayBackIcon (this function handles refresh)


---

main-> signup.dart -> splashscreen.dart -> homescreen.dart 


HomeScreen.dart
- prescriptions_options_grid.dart
	- manual - newPrescriptionCompactview
		- addprescriptionpage
				- provider.addPrescription(prescriptionModel)
			- copymedicinepage
				- addmedicinestepperpage
						- insertMedicineUpdateTableData
					- prescriptionmedicinesummary
						- addmedicinestepperpage
						- copymedicine
					- newviewprescriptionpage
	- voice - voice_based_prescription
- newmedicineviewpage.dart
	- newmedicineExpandViewWithadvice
- medicineTodayViewPage.dart
	- medicineTodayViewPage
		- addprescriptionviewmodel has db work 
- scheduleviewpage.dart
	- SingleMedicineExpandView
		- ScheduleChangePage
			- createPrescriptionFooter() here we have db methods 