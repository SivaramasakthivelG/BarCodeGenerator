![[Pasted image 20240601110419.png]]
by khan academy, direct equation without using two point formula



![[Pasted image 20240601113305.png]]

![[Pasted image 20240601113450.png]]

