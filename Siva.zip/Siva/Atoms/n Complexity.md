```java

class Solution {
    public void rotate(int[] nums, int k) {
        final int N = nums.length;
        int[] copy = nums.clone();
        // here we use modulus to ensure that we won't go beyond our
        //index (k%N) do that work.
        int rotateID = N - (k % N);
        

        for (int i = 0; i < N; i++) {
            if (rotateID >= N) rotateID = 0;
            nums[i] = copy[rotateID++];
        }
    }
}

```