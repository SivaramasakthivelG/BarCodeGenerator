

`
```
**Input:** nums = [1,1,2]
**Output:** 2, nums = [1,2,_]
**Explanation:** Your function should return k = 2, with the first two elements of nums being 1 and 2 respectively.
It does not matter what you leave beyond the returned k (hence they are underscores).

```

```java

class Solution {

  

    public int main(int[] nums) {

        int k = removeDuplicates(nums);

  

        for (int i = 0; i < k; i++) {

            System.out.print(nums[i] + " ");

        }

        return k;

    }

    public int removeDuplicates(int[] nums){

      LinkedHashSet<Integer> set = new LinkedHashSet<>();


        for(int i=0;i<nums.length;i++){

            set.add(nums[i]);

        }

        int k = set.size();

  

        int j = 0;

        for(int x: set){

            nums[j++] = x;

        }

  

        return k;

  

    }

}

```

