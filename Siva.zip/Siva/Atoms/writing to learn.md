![[Pasted image 20240509125759.png]]

writing forces us to keep asking, Am I saying what I want to say very often the answer is NO

