wmic csproduct  -> to get product info's
