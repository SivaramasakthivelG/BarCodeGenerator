[[temp]]

```widget 

Container(  
  alignment: Alignment.bottomRight,  
  padding: const EdgeInsets.only(bottom: 16.0, right: 16.0),  
  child: ElevatedButton.icon(  
    style: ElevatedButton.styleFrom(  
      backgroundColor: Colors.blue,  
      foregroundColor: Colors.white,  
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),  
      shape: RoundedRectangleBorder(  
        borderRadius: BorderRadius.circular(12), // Smooth rounded corners  
      ),  
      elevation: 4,  
    ),  
    icon: const Icon(Icons.edit, size: 20,color: Colors.white,),  
    label: const Text(  
      "Manual",  
      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),  
    ),  
    onPressed: () {  
      viewModel.manualEntryCallBack();  
    },  
  ),  
),

```



```widget 

     Column(  
       mainAxisAlignment: MainAxisAlignment.center,  
       children: [  
         Row(  
             mainAxisAlignment: MainAxisAlignment.spaceAround,  
/*             children: [  
               ElevatedButton(                 onPressed: () {                   List<String> infoList = viewModel.prescriptionAnswers.where((answer) => answer.trim().isNotEmpty).toList();                   showInfoDialog(context, infoList);                 },                 child: Text("Info",style: TextStyle(color: Colors.black)),               ),*/               /*ElevatedButton(                 onPressed: () {                   viewModel.manualEntryCallBack();                 },                 child: Row(                   mainAxisAlignment: MainAxisAlignment.spaceBetween,                   children: [                     Text("Manual Entry",style: TextStyle(color: Colors.black),),                     SizedBox(width: 10,),                     Icon(Icons.format_align_justify,color: Colors.grey,)                   ],                 ),               ),*/  
             //]         ),

```

```addprescription

builder: (context) => AddPrescriptionPage(  
  title: "Edit Prescription",  
  editPrescriptionName: viewModel.prescriptionAnswers[0].isEmpty ? "Please edit" : viewModel.prescriptionAnswers[0],  
  editHospitalName: viewModel.prescriptionAnswers[1].isEmpty? "Please edit" : viewModel.prescriptionAnswers[1],  
  onDate: viewModel.prescriptionAnswers[2].isEmpty? DateTime.now().toString() : viewModel.prescriptionAnswers[2],  
  editPrescriptionFromDate: viewModel.prescriptionAnswers[3].isEmpty ? DateFormat("d-M-yyyy").parse(DateFormat("d-M-yyyy").format(DateTime.now())) :  
  DateFormat("d-M-yyyy").parse(viewModel.prescriptionAnswers[3]),  
  editPrescriptionToDate: viewModel.prescriptionAnswers[4].isEmpty ? DateFormat("d-M-yyyy").parse(DateFormat("d-M-yyyy").format(DateTime.now())) :  
  DateFormat("d-M-yyyy").parse(viewModel.prescriptionAnswers[4]),  
  followOnAction: viewModel.prescriptionAnswers[5].isEmpty ? "Nonse": viewModel.prescriptionAnswers[5],  
  refreshCallBack: viewModel.refreshCall,  
)

```


```add

builder: (context) => AddPrescriptionPage(  
      title: "Add Prescription",  
      refreshCallBack: viewModel.refreshCall,  
    )

```

