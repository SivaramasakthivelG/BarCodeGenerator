She has more money than you

उसके पास आपसे ज़्यादा पैसा है


Does he sings better than you 
क्या वह आपसे बेहतर गाता है?  or kya vah aapse acha gatha hai


There are fewer people here
यहाँ कम लोग  हैं



