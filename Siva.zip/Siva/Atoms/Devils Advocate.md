129th AIR @ JEE89
Rusticated
Contemplated Suicide
Working with people @ IIT
Director of engineering @ ZOHO

His ideas:
- There will never be a master plan
- Passion of the christ movie
- Karumamae kannayinaar
- Pheripheral vision (Multi skill)
- RRR (Rigor, relevance, relationship)
- ~~Fight~~ Collaboration
- Compete against yourselves
- Play the right game 
- Understand your exceptional talents
- Happiness is the journey.

