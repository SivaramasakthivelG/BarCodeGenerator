![[Pasted image 20240513183937.png]]


Central banks buying:
![[Pasted image 20240513184735.png]]

Gold and Currency War:
![[Pasted image 20240513185343.png]]


Silver vs Gold:

Its clear that Silver's demand is completely overshot supply, and Silver is highly volatile.

![[Pasted image 20240513185601.png]]


![[Pasted image 20240513190033.png]]

Gold mining countries:
![[Pasted image 20240513190220.png]]

Mining Process:
![[Pasted image 20240513190458.png]]


![[Pasted image 20240513190811.png]]

![[Pasted image 20240513190923.png]]