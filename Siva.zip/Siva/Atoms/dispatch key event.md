parent: [[dispatch events]]




	val motionEvent = mock(MotionEvent::class.java)  
            `when`(motionEvent.action).thenReturn(MotionEvent.ACTION_DOWN)

            imageButton!!.performClick()  
            imageButton.dispatchTouchEvent(motionEvent)  
            imageButton.dispatchTouchEvent(motionEvent)  
            Shadows.shadowOf(Looper.getMainLooper()).idle()