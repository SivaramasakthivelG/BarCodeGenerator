[Logeshwaran Sivakumar (Unverified): https://www.geeksforgeeks.org/problems/count-d...](https://teams.microsoft.com/l/message/19:9186d041-f644-4988-9baf-dd0e73c0ff7e_a215848a-2a1f-487c-8481-ad2d384db372@unq.gbl.spaces/1726117997058?context=%7B%22contextType%22%3A%22chat%22%7D)



```
  ArrayList<Long> ar = new ArrayList<>();  
  
        long ans = 1;  
  
  
        for(int i = 1;n>= ans*i; i++){  
            ans = (long) ans * i;  
            ar.add(ans);  
  
        }  
  
        return ar;

```


```

fun main() {  
  val arr = arrayOf(1,2,3,4,5)  
    alternateSwitch(arr)  
}  
  
fun alternateSwitch(arr: Array<Int>){  
    var start = 0;  
    var last = arr.size -1  
    for(i in arr.indices){  
        if(i%2 == 0){  
            println(arr[start])  
            start++  
  
        }else{  
            println(arr[last])  
            last--  
        }  
    }  
}

```


----


getchartwidget -> allocates space for chart 

getMainData -> 

default -> plotmode - > category 
duration -> monthly 

get the data from the main table using these default parameter 

we give those data's to the syncfusion chart 

syncfuction char prepares cartesian series and gives as a neat chart 
