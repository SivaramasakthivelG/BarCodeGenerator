
```kotlin

else if (receivedAction.buttonKeyPressed == 'SNOOZE') {  
  int snoozeMinutes = 15;  
  
  int newTime = DateTime.now().millisecondsSinceEpoch + (snoozeMinutes*60*1000);  
  
  DateTime newDateTime = DateTime.fromMillisecondsSinceEpoch(newTime);  
  
  TimeOfDay newTimeOfDay = TimeOfDay.fromDateTime(newDateTime);  
  
  await AwesomeNotifications().cancel(receivedAction.id!);  
  showNotification(medicineID: receivedAction.id!,  
    title: receivedAction.title!,  
    body: receivedAction.body!,  
    scheduleTime: newTimeOfDay);  
}

```


```dart

onNotificationDisplayedMethod: (notification) async {  
  final service = FlutterBackgroundService();  
  service.invoke("start_speech");  
},

```
