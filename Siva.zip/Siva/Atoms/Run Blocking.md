
Run blocking: 
- ==It waits until the All Coroutines ends, to update UI
- we can use run blocking block to run suspend funcs
- But the process completed asynly\
- **Log print agum but UI update agathu because Run blocking Stops UI thread to Update.**
- We cannot use _Global scope inside run blocking with UI updates inside the global scope, because global scope runs till the app lifecycle destroy.
- **code below run blocking won't execute before run blocking**


```kotlin
  
class MainActivity : AppCompatActivity() {  
    @SuppressLint("SetTextI18n", "SuspiciousIndentation")  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
        setContentView(R.layout.activity_main)  
  
        val TAG = "MainActivity"  
  
  
        runBlocking {  
        // It blocks UI thread(Main thread)
  
            GlobalScope.launch(Dispatchers.IO) {  
                val call = doNetworkCall()  
                //we cannot update UI inside Globalscope 
//                val text1 = findViewById<TextView>(R.id.text1)  
//                text1.text = call  
                Log.d(TAG, "APTIV")  
            }  
  
            val call1 = doNetworkCall2()  
            Log.d(TAG, "APTIV2")  
            val text2 = findViewById<TextView>(R.id.text2)  
            text2.text = call1  
        }  
  
    }  
  
  
    suspend fun doNetworkCall(): String {  
        delay(3000L)  
        return "vina"  
    }  
  
    suspend fun doNetworkCall2(): String {  
        delay(1000L)  
        return "Siva"  
    }

	
  

	first APTIV2 prints after 2 sec APTIV prints.
```
