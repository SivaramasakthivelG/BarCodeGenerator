---
Testing: Mockito complex, Mockito
---
[[Mockito]]
[[Mockito call backs]]


---


![[OngoingCallFragmentTest 2.kt]]


Here the mockito is bit deep

```kotlin
/*
 * Copyright (c) 2022 Aptiv. All rights reserved.
 * Confidential - Restricted Aptiv information. Do not disclose.
 */
package com.aptiv.phone.ui.fragments.call

	import android.content.Context
	import android.net.Uri
	import android.os.Bundle
	import android.os.StrictMode
	import android.telecom.Call
	import android.telecom.PhoneAccountHandle
	import android.view.View
	import androidx.arch.core.executor.testing.InstantTaskExecutorRule
	import androidx.fragment.app.Fragment
	import androidx.test.core.app.ApplicationProvider
	import com.android.car.ui.uxr.DrawableStateImageView
	import com.android.car.ui.uxr.DrawableStateToggleButton
	import com.aptiv.phone.BaseApplication
	import com.aptiv.phone.R
	import com.aptiv.phone.databinding.FragmentOngoingcallBinding
	import com.aptiv.phone.databinding.FragmentPhoneBookBinding
	import com.aptiv.phone.ui.fragments.PhoneBookFragment
	import com.aptiv.phone.ui.helper.callhelpers.CallManager
	import com.aptiv.phone.ui.helper.callhelpers.CallManager.isConference
	import com.aptiv.phone.utils.launchFragmentInHiltContainer
	import com.google.common.truth.Truth
	import dagger.hilt.android.testing.HiltAndroidRule
	import dagger.hilt.android.testing.HiltAndroidTest
	import dagger.hilt.android.testing.HiltTestApplication
	import java.lang.reflect.Method
	import org.junit.Before
	import org.junit.Rule
	import org.junit.Test
	import org.junit.rules.TestRule
	import org.junit.runner.RunWith
	import org.mockito.Mockito
	import org.mockito.MockitoAnnotations
	import org.robolectric.RobolectricTestRunner
	import org.robolectric.annotation.Config
	import org.robolectric.util.ReflectionHelpers
	import java.lang.reflect.Field

@HiltAndroidTest
@RunWith(RobolectricTestRunner::class)
@Config(application = HiltTestApplication::class,shadows = [ContactHelperShadow::class])
class OngoingCallFragmentTest {

    @get:Rule(order = 0) val hiltInjectRule = HiltAndroidRule(this)

    @get:Rule(order = 1) var rule: TestRule = InstantTaskExecutorRule()
    lateinit var details: Call.Details
    lateinit var accountHandle: PhoneAccountHandle
    lateinit var handle: Uri
    private lateinit var binding: FragmentOngoingcallBinding
    @Before
    fun setUp() {
        hiltInjectRule.inject()
        MockitoAnnotations.openMocks(this)
        handle = Mockito.mock(Uri::class.java)
        details = Mockito.mock(Call.Details::class.java)
        accountHandle = Mockito.mock(PhoneAccountHandle::class.java)
        val policy: StrictMode.VmPolicy =
            StrictMode.VmPolicy.Builder().detectAll().penaltyLog().build()
        StrictMode.setVmPolicy(policy)
    }

    @Test(expected = NullPointerException::class)
    fun verifyOnViewCreated() {
        val v = View(ApplicationProvider.getApplicationContext())
        val b = Bundle()

        launchFragmentInHiltContainer<OngoingCallFragment> {
            this.onViewCreated(v, b)
        }
    }

    @Test
    fun verify_btnEndCall() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            val button: DrawableStateImageView =
                this.requireActivity().findViewById(R.id.option_end_call)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()
        }
    }

    @Test
    fun verify_updateUiBasedOnPhoneState() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {

            BaseApplication.appContext = context
            var call: Call = Mockito.mock(Call::class.java)
            var details: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call.details).thenReturn(details)
            Mockito.`when`(details.state).thenReturn(4)
            Mockito.`when`(details.handle).thenReturn(handle)
            Mockito.`when`(details.handle.schemeSpecificPart).thenReturn("1234")
            Mockito.`when`(details.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details.accountHandle.id).thenReturn("3")

            CallManager.onCallAdded(context!!, call)

            CallManager.primaryCalls.clear()
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod("updateUiBasedOnPhoneState")
            method.isAccessible = true
            method.invoke(this)

            CallManager.primaryCalls.add(call)
            method.invoke(this)

            var call2: Call = Mockito.mock(Call::class.java)
            var details2: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call2.details).thenReturn(details2)
            Mockito.`when`(details2.state).thenReturn(7)
            Mockito.`when`(details2.handle).thenReturn(handle)
            Mockito.`when`(details2.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details2.accountHandle.id).thenReturn("3")
            ContactHelperShadow.contactimage = ""

            CallManager.primaryCalls.add(call2)
            method.invoke(this)

            CallManager.primaryCalls.add(call)
            method.invoke(this)

            // STATE_DIALING = 1
            var call3: Call = Mockito.mock(Call::class.java)
            var details3: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call3.details).thenReturn(details3)
            Mockito.`when`(details3.state).thenReturn(1)
            Mockito.`when`(details3.handle).thenReturn(handle)
            Mockito.`when`(details3.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details3.accountHandle.id).thenReturn("3")

            CallManager.primaryCalls.clear()
            CallManager.primaryCalls.add(call)
            CallManager.primaryCalls.add(call3)
            method.invoke(this)

            // STATE_HOLDING = 3
            Mockito.`when`(details3.state).thenReturn(3)

            CallManager.primaryCalls.clear()
            CallManager.primaryCalls.add(call3)
            method.invoke(this)

            // STATE_DIALING = 1;
            Mockito.`when`(details3.state).thenReturn(1)

            CallManager.primaryCalls.clear()
            CallManager.primaryCalls.add(call)
            CallManager.primaryCalls.add(call3)
            method.invoke(this)

            //SingleConferenceCall
            CallManager.primaryCalls.clear()
            SingleConferenceCall()
            method.invoke(this)
        }
    }

    fun SingleConferenceCall()
    {
        var call: Call = Mockito.mock(Call::class.java)
        var details: Call.Details = Mockito.mock(Call.Details::class.java)
        Mockito.`when`(call.details).thenReturn(details)
        Mockito.`when`(details.state).thenReturn(3)
        Mockito.`when`(details.handle).thenReturn(handle)
        Mockito.`when`(details.accountHandle).thenReturn(accountHandle)
        Mockito.`when`(details.accountHandle.id).thenReturn("3")
        Mockito.`when`(details.hasProperty(Call.Details.PROPERTY_CONFERENCE)).thenReturn(true)

        var call1: Call = Mockito.mock(Call::class.java)
        var details1: Call.Details = Mockito.mock(Call.Details::class.java)
        Mockito.`when`(call1.details).thenReturn(details1)
        Mockito.`when`(details1.state).thenReturn(9)
        Mockito.`when`(details1.handle).thenReturn(handle)
        Mockito.`when`(details1.accountHandle).thenReturn(accountHandle)
        Mockito.`when`(details1.accountHandle.id).thenReturn("3")
        Mockito.`when`(details1.hasProperty(Call.Details.PROPERTY_CONFERENCE)).thenReturn(false)

        CallManager.primaryCalls.clear()
        CallManager.primaryCalls.add(call)
        CallManager.primaryCalls.add(call1)
        CallManager.primaryCalls.add(call1)

        Mockito.`when`(call.children).thenReturn(listOf(call1,call1))
    }

    @Test
    fun verify_dialer() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            val button: DrawableStateToggleButton = this.requireActivity().findViewById(R.id.dialer)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()

            val method: Method = OngoingCallFragment::class.java.getDeclaredMethod("openDialer")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_transfer() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            val button: DrawableStateToggleButton =
                this.requireActivity().findViewById(R.id.transfer)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()

            ReflectionHelpers.setField(this, "isCallTransferred", true)
            button.performClick()
        }
    }

    @Test
    fun verify_mute() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            binding = FragmentOngoingcallBinding.bind(this.view!!)
            BaseApplication.appContext = context
            val button: DrawableStateToggleButton =
                this.requireActivity().findViewById(R.id.mute)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()

            binding.ongoingCallOptions.mute.isChecked = false
            button.performClick()
        }
    }

    @Test
    fun verify_hold() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            binding = FragmentOngoingcallBinding.bind(this.view!!)
            val nameField: Field = OngoingCallFragment::class.java.getDeclaredField("binding")
            nameField.isAccessible = true
            nameField.set(this, binding)

            val button: DrawableStateToggleButton = this.requireActivity().findViewById(R.id.hold)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()

            binding.ongoingCallOptions.hold.isChecked = false
            button.performClick()
        }
    }

    @Test
    fun verify_add_call() {
        launchFragmentInHiltContainer<OngoingCallFragment>() {
            val button: DrawableStateImageView = this.requireActivity().findViewById(R.id.add_call)
            button.performClick()
            Truth.assertThat(button.isClickable).isTrue()
        }
    }

    @Test
    fun verify_onDestroy() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method = OngoingCallFragment::class.java.getDeclaredMethod("onDestroy")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_onStop() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method = OngoingCallFragment::class.java.getDeclaredMethod("onStop")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_openConferenceCallScreen() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod("openConferenceCallScreen")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_updateContainer() {
        launchFragmentInHiltContainer<OngoingCallFragment> {

            BaseApplication.appContext = context

            var call: Call = Mockito.mock(Call::class.java)
            var details: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call.details).thenReturn(details)
            Mockito.`when`(details.state).thenReturn(4)
            Mockito.`when`(details.handle).thenReturn(handle)
            Mockito.`when`(details.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details.accountHandle.id).thenReturn("3")
            Mockito.`when`(details.hasProperty(Call.Details.PROPERTY_CONFERENCE)).thenReturn(true)

            var call1: Call = Mockito.mock(Call::class.java)
            var details1: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call1.details).thenReturn(details1)
            Mockito.`when`(details1.state).thenReturn(9)
            Mockito.`when`(details1.handle).thenReturn(handle)
            Mockito.`when`(details1.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details1.accountHandle.id).thenReturn("3")
            Mockito.`when`(details.hasProperty(Call.Details.PROPERTY_CONFERENCE)).thenReturn(false)

            CallManager.primaryCalls.clear()
            CallManager.primaryCalls.add(call)
            CallManager.primaryCalls.add(call1)

            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod("updateContainer")
            method.isAccessible = true
            method.invoke(this)

            var call2: Call = Mockito.mock(Call::class.java)
            var details2: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call2.details).thenReturn(details2)
            Mockito.`when`(details2.state).thenReturn(4)
            Mockito.`when`(details2.handle).thenReturn(handle)
            Mockito.`when`(details2.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details2.accountHandle.id).thenReturn("3")
            Mockito.`when`(details.hasProperty(Call.Details.PROPERTY_CONFERENCE)).thenReturn(true)

            CallManager.primaryCalls.add(call2)
            method.invoke(this)

            Mockito.`when`(call.children).thenReturn(listOf(call1,call2))
            method.invoke(this)
        }
    }

    @Test
    fun verify_openDialer() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method = OngoingCallFragment::class.java.getDeclaredMethod("openDialer")
            method.isAccessible = true
            method.invoke(this)
        }
    }

    @Test
    fun verify_handleButtons() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod(
                    "handleButtons", Boolean::class.java)
            method.isAccessible = true
            method.invoke(this, true)
        }
    }

    @Test
    fun verify_handleButtons1() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod(
                    "handleButtons", Boolean::class.java)
            method.isAccessible = true
            method.invoke(this, false)
        }
    }

    @Test
    fun verify_updateCallState() {
        launchFragmentInHiltContainer<OngoingCallFragment> {

            var call: Call = Mockito.mock(Call::class.java)
            var details: Call.Details = Mockito.mock(Call.Details::class.java)
            Mockito.`when`(call.details).thenReturn(details)
            Mockito.`when`(details.state).thenReturn(7)
            Mockito.`when`(details.handle).thenReturn(handle)
            Mockito.`when`(details.handle.schemeSpecificPart).thenReturn("1234")
            Mockito.`when`(details.accountHandle).thenReturn(accountHandle)
            Mockito.`when`(details.accountHandle.id).thenReturn("3")

            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod(
                    "updateCallState", Call::class.java)
            method.isAccessible = true

            method.invoke(this, call)
        }
    }

/*    @Test
    fun verify_updateConferenceData() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod(
                    "updateConferenceData", Call::class.java)
            method.isAccessible = true
            method.invoke(this, mockCall)
        }
    }*/

/*    @Test
    fun verify_removeSecondCallFrag() {
        launchFragmentInHiltContainer<OngoingCallFragment> {
            val method: Method =
                OngoingCallFragment::class.java.getDeclaredMethod(
                    "removeSecondCallFrag", Fragment::class.java)
            method.isAccessible = true
            method.invoke(this, secondaryCallFragment)
        }
    }*/
}


```