ROI - Return on Interest.

Holding freecash affects the companies ROI.

---

[[Must watch while visiting rental home]]

All you have to do is better management and setting clear boundaries.


