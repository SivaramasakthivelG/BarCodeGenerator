[[diagram]]
[[sequence diagram]]

settings - bluetooth - aa or cp - **broadcast** sent with the intent

Launcher - 

launcher page android and cp press.
```kotlin
holder.viewBinding.root.setOnClickListener {  
    val intent =  
        Intent(Intent.ACTION_MAIN).also { intent ->  
            intent.component = appItem.componentName  
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)  
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)  
        }  
    it.context.startActivity(intent)

```


Projection tile - foreground notification

Media

MediaSourceManager

---
Final flow:
- User press the AA or CP
- In Settings repo, BluetoothUtils class has a function handleaacp() which send a broadcast with intent
- which launches AA or CP apk and  evokes the call back from systemUI Repo in CnhiProjectionSystemBarButton class has a function carPropertyEventCallback which Updates SystemUI with a CP or AA logo.
- In Media Repo By observing the currentSourceViewModel the MediatabActivity class starts a SourceSelectionActivity class in MediaSourceManager repo which is responsible for the Media side UI update according to AA and CP
- In ProjectionTiles Repo there is a class named MediaBrowserManager which has registerUserAction function which receives the broadcast and add AA or CP Tiles according to the filter in the registerUserAction by which Tiles UI also Updated

---
MediaTabActivity flow

MediaTabActivity - > callSourceSelection() - Media source manger(Source selection activity)