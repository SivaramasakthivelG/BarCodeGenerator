[[Cubes till 20]]

![[Pasted image 20240622112555.png]]