ut test report generation
gradle config