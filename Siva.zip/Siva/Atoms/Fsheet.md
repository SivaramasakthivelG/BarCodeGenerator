[[Praveen]]

[[IITM]]

[[Git]]

[[PF (UAN)]]

---

tlzuq8wLtadr9cr

--------------------------------------------------------------------------                     

ChatGpt, figma, postman, takeyouforward,leet, deepseek

sivaramasakthivel.govindaraj@jasmin-infotech.com
Siva88832@

[[Geeksforgeeks]]


---

Adrenaline [[old]]

JIIN17790723
siva@1234


---

Pc 

sivaramasakthivel.govindaraj@jasmin-infotech.com
sakthivel@123

	previous -siva@321

--------------------------------------------------------------------------

JIAS


sivaramasakthivel.govindaraj@jasmin-infotech.com
Siva88832@ji

------------------------------------------------------
Veracrypt,obsidian, Figma

sivaramasakthivel.govindaraj@jasmin-infotech.com
Siva88832@

--------------------------------------------------

Discord : 
Logged in using your current phone number
Siva88832@ji



------------------------------------
mohamadvasim98@gmail.com, 
sivaramsakthivel001@gmail.com
8883257379

--------------

Sivaramasakthivel.G@aptiv.com
tlzuq8wLtadr9cr

net id : 663i98   

-----------------------------------

gerrit

663i98
19hbiQdAEkaGtiqtke4De3dKLGVk9J+fWRP7pTTpKg

-----


personal git
sivaramasakthivel.govindaraj@jasmin-infotech.com
Siva88832@

---


screener : 
sivaramasakthivel.govindaraj@jasmin-infotech.com
Siva@321

----
dell:
sivaramasakthivel200@gmail.com
Siva88832@

---
esavai
Username: Sivaramasakthivel G
6382059462 - mob
Siva88832@
``

Related :

[[Aptiv]]

[[khan academy]]

