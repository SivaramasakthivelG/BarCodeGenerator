
[[Weather api]]


email : sivaramasakthivel200@gmail.com

for movies app : const val API_KEY = "e78e573f"

for newsapi :
bfb1acd6071c4eebbe19b9cda2203086

Pixabay 
**20080215-46215f2c1da8f9edcdb7b3e60**

freeweather  [[free weather login]]
3b21d873a7d84b93ada93158241707

Polygon - maket data api
A5DetYeoqDp8zBlbgT4HZj07G5qENlrj


https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/day/2023-01-09/2023-01-09?apiKey=A5DetYeoqDp8zBlbgT4HZj07G5qENlrj
