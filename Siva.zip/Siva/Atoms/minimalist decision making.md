Define the problem:
Challenge assumptions
Breakdown problem
Analyse fundamentals
Reconstruct solution


---

youtube
- least priority for now
- you can post your simple intuitive thoughts inspiring lines by literature works in tamil 
- Awesome words you hear from the world around you

---


