Define the problem:
Challenge assumptions
Breakdown problem
Analyse fundamentals
Reconstruct solution
