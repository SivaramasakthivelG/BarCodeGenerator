Define the problem:
Challenge assumptions
Breakdown problem
Analyse fundamentals
Reconstruct solution


---

**Please check and update this, lack or clarity leads to soo many distractions**


Investing
- Mastery level priority
- Learn financial statement analysis with Brian Feroldi, Use weekends
	- vertical,horizontal,ratio
- Sincerely read annual reports and follow Jewellery space and make decisions explain to ponraj.
- Mint article
- Have to read ppt of every company you own.

---

Career
- High priority
- Focus on problem solving foundation this month
- Yes unit testing plan is also there 

---

Literature and Movies
- Low priority for now
- Read whenever you feel low or overhyped
- Watch a movie per week.

---
IITM
- Low priority
- Just focus to pass and gain conceptual grab
- main focus graded assignments

---
Youtube
- least priority for now
- you can post your simple intuitive thoughts inspiring lines by literature works in tamil 
- Awesome words you hear from the world around you