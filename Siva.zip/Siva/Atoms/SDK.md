
**Collection of tools,libraries documentations and code samples.**
- Platform specific features
	- Camera, GPS, Storage etc..
- App building and testing 
	- adb and emulator
	- 
- UI components and libraries
	- recyclerview, constraint views
	- 
- Integration with services
	- google maps
	- firebasse
	- 
- Version compatibility
	- androidx provide version compatibility for older divices
