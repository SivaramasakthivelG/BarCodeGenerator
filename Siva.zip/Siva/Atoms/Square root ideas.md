[[Squares till 50]]


![[Pasted image 20240622125545.png]]

_No square numbers end with 2,3,7,8


![[Pasted image 20240622160310.png]]

	sqrt of 1681, think of it end with one or nine and 16 is between 4sq and 5 sq so we get 41 

