

>[!Retrofit flow]
>Retrofit instance 
>API service to initiate the call
>Model class contains the template for the data
>viewModel to receive the data and logically manipulate data
>in screen we get the data from the viewmodel using the query we send as word here 
>


