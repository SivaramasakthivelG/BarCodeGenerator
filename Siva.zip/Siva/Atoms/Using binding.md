---
Testing: Binding, Layout Inflation
---

**While using Binding** (For getting inflating the layout)

```Kotlin

val layoutInflater =  
	    ApplicationProvider.getApplicationContext<Context>()  
	        .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as  
	        LayoutInflater
	//inflate the layout to the binding
	binding = GenreListItemBinding.inflate(layoutInflater)
```



---
Related: [[Layout Inflator and Binding]]