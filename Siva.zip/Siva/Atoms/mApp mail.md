#mapp
[[mApp flow]]
[[mApp checklist]]

---

Hi Arivalagan,  

Here, I have attached the release APK link : 


**Release Notes – v1.0.6**

**What's New?**

- **Voice based Prescription** – The voice-based prescription workflow has been successfully completed, enabling seamless  prescription flow without typing.
    

**Note:**  Please uninstall the previous version before installing v1.0.6 to ensure optimal performance.  

