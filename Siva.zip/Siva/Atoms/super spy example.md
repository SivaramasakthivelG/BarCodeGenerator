![[Pasted image 20240603170415.png]]




```

fun testOnStop1() {  
  
    var cn =  
        ComponentName(  
            "com.aptiv.mediahmi.data.client.connection",  
            "com.aptiv.mediahmi.data.client.connection.ClientConnection")  
  
    var mBrowser1 =  
        MediaBrowserCompat(  
            context,  
            cn as ComponentName?,  
            instance as MediaBrowserCompat.ConnectionCallback?,  
            null)  
    var mock = spyk(mBrowser1, recordPrivateCalls = true)  
    mock.connect()  
    every { mock.isConnected } returns true  
    var media = MediaClientDataControl(context, mock)  
    var c = MediaControllerCompat(context!!, token!!)  
    var playbackStateCompat = mock(PlaybackStateCompat::class.java)  
    var c1 = spyk(c, recordPrivateCalls = true)  
    every { c1.playbackState } returns playbackStateCompat  
    every { c1.playbackState.state } returns 7  
    val field: Field = MediaClientDataControl::class.java.getDeclaredField("mController")  
    field.isAccessible = true  
    field.set(media, c1)  
    media.onStop()  
}

```