---
Testing: binding,view.requesfocus,sportteam
---
![[AddTeamAdapterTest.kt]]


---

above addteamadaptertest contains implementaion for binding.root as viewgroup

```kotlin
    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        context = ApplicationProvider.getApplicationContext()
        alertsUtil = Mockito.mock(AlertsUtil::class.java)
        sportAlerts = Mockito.mock(VectorSportsFavoriteItem::class.java)
        recyclerView = RecyclerView(ApplicationProvider.getApplicationContext())
        recyclerView.layoutManager =
            LinearLayoutManager(ApplicationProvider.getApplicationContext())
        itemList = arrayListOf(buildRacoonTeams(), buildFreyTeams())
        adapter = AddTeamAdaptor(context, itemList)
        recyclerView.adapter = adapter

        val layoutInflater =
            ApplicationProvider.getApplicationContext<Context>()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as
                LayoutInflater
        binding = AddTeamItemBinding.inflate(layoutInflater)

        ShadowVectorSportsFavoriteItem.setSizeData(5)
        Shadows.shadowOf(Looper.getMainLooper()).idle()

    }
```


Below code is bit strange we not used @Test above the code
```kotlin
    fun buildRacoonTeams(): SportsTeam {
        val sportsTeam = Mockito.mock(SportsTeam::class.java)
        Mockito.`when`(sportsTeam.name()).thenReturn("Raccoon")
        Mockito.`when`(sportsTeam.nickname()).thenReturn("Raccoon")
        Mockito.`when`(sportsTeam.isFavorite).thenReturn(true)
        Mockito.`when`(sportsTeam.leagueId()).thenReturn(111)
        Mockito.`when`(sportsTeam.teamId()).thenReturn(1234789)
        Mockito.`when`(sportsTeam.getImageSet(Mockito.any())).thenReturn(Status.OK)
        return sportsTeam
    }
```


```kotlin

/** To test CreateViewHolder returns not null */
    @Test
    fun testCreateViewHolder() {
        (binding!!.root as ViewGroup?)?.let {
            adapter.onCreateViewHolder(it, R.layout.add_team_item)
        }
        TestCase.assertNotNull(binding!!.root)
        Truth.assertThat(binding!!.teamLogo).isNotNull()
        Truth.assertThat(binding!!.textViewSportTeamName).isNotNull()
    }

```



viewholder.view.requestfocus
```kotlin
   @Test
    fun testBindViewHolderFocusedItem() {
        (binding!!.root as ViewGroup?)?.let {
            val vh = adapter.onCreateViewHolder(it, 0)
            vh.view.requestFocus()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            adapter.onBindViewHolder(vh, 0)
            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            Truth.assertThat(vh.view.isFocused).isTrue()
            // Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            // System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }
```