
- approach from first principles thinking 
	- don't have biases to covers your thinking 
		- for example batteries cost too much for a km, so we shouldn't use them for car, but elon knows the fundamentals of it and think better 
	- Physics way of thinking 
		- boil down into most fundamentals and reason out from there 
		- Think in limit (eg: how this portfolio looks, with 2times value and what can lead to loss, elon says example, current price is 800000 per car if my volume increase what is the per car price, if same change design its not an volume kind of issue )

Elon video 
- teach to the problem not to the tools 
- 