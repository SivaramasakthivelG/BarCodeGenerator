What are the problem with this(current): 
- telling "who is him to ask?" and with me "mayir" hurt me.
- Emotional and mental drain.
- There is no scope for improvement due to biases.
- Oru ardour illa (In a multicomplex situation even a widow, Ratna chooses to become a fashion designer in "Is love enough? - Sir)
- I Don't feel this should continue longterm...
- I haven't feel appreciated and supported.
- There is no value for my time.
- I need more time to kill on my own!

I'm feeling that I stick with that only for you...

On the flip side, that is soo healthy and some good memories are also there

What to do now:
- So lets do this 55min sincere check.
- 