![[Pasted image 20240603114125.png]]

in Kotlin

[[I give a try]]

