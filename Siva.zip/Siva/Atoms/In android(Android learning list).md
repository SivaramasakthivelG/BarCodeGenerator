XML
- bias
- weight

Viewmodel
Recycler view
Fragment
co routine
flow 
MVVM
DI





others:
Dialogs
Menu and Navigation

**Philip:**
MVI and MVVM
async, multithreading, concurrency, coroutines.
Kotlin language features... 
State management
Reactive programming,

in comments:
![[Pasted image 20240515115304.png]]