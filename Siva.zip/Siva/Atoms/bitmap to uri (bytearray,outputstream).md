
openInputstream
```
private fun getImageUri(inContext: Context, inImage: Bitmap): Uri? {  
    val bytes = ByteArrayOutputStream()  
    inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)  
    val path =  
        MediaStore.Images.Media.insertImage(inContext.contentResolver, inImage, "Title", null)  
    return Uri.parse(path)  
}

```

