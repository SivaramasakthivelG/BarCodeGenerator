

next Topic : [[Run Blocking]]

---

- Main - UI
- IO -> Secondary works like network, db activities
- Default -> Complex and long running calcs, It won't block the main thread
- Unconfine  -> kdjfkldjfskldfj(onnum vilangala)


```kotlin

  
class MainActivity : AppCompatActivity() {  
    @SuppressLint("SetTextI18n")  
    override fun onCreate(savedInstanceState: Bundle?) {  
        super.onCreate(savedInstanceState)  
        setContentView(R.layout.activity_main)  
  
        val TAG = "Main Activity"  
  
        GlobalScope.launch{  
            Log.d(TAG, "onCreate: log1")  
  
            val call2 = doNetworkCall2()  
            withContext(Dispatchers.Main){  
                val text2 = findViewById<TextView>(R.id.text2)  
                text2.text =call2  
            }  
  
            val call1 = doNetworkCall()  
            withContext(Dispatchers.Main){  
                val text1 = findViewById<TextView>(R.id.text1)  
                text1.text = call1  
            }  
  
        }    }  
  
    suspend fun doNetworkCall():String{  
        delay(5000L)  
        return "vina"  
    }  
  
    suspend fun doNetworkCall2():String{  
        delay(5000L)  
        return "Siva"  
    }  
  
  
}

```

### So this executed synchronously,  
- **donetworkcall takes 5 secs and updated to UI** 
- **Then only the donetworkcall2 called**
