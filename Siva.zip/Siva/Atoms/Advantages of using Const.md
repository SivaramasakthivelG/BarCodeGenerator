
- const only works for primitives
- const compile time, val run time 


```kotlin

const val key = "abkdl"

```

by using const we avoid extra effort by the compiler to decompile the code, as the value has been inlined (passed directly ), which improves the performance of the application 

```kotlin
val key = "abkdl"
```

where val leads to compile time overhead.

---

we can see the difference by using tools option and get kotin byetcode,

