misuse of context leads to memory leaks

activity context alive until the activity
- Used for UI related contexts like
	- Dialog
	- Broadcasts

Application context cannot be used for UI related applications
- alive as long as the application is alive!

