Wouldn't hurt a fly
To chicken out - you chickened out, you didn't dare dive off the high diving board.
Pig headed - be stubborn
Pig out - eat really fast and more 
When pigs fly - Probably never happens
Elephant in the room - the subject that no one wants to talk about.


To have a cow or don't have a cow  - don't make big deal out of something. to have a cow mean overly upset about something.
Till the cows come home - do something foreever

Don't  poke the bear

To smell  a rat  - is to be suspicious of something

don't let someone get your goat - don't let them get you upset 

Horsing around - excited and doing crazy things
Hold your horses -  Wait 