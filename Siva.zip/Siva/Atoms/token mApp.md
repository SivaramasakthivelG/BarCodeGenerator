[[mApp flow]]

---

curl -X POST "https://mapp.jasmin-infotech.com:8443/api/medicine-followed" ^
  -H "Content-Type: application/json" ^
  -H "Authorization: Bearer<token>" ^
  -d "[ 
    {\"PrescriptionId\":\"GN20244547\",\"MedicineId\":\"Test1\",\"MedicineName\":\"Metformin\",\"MedicineTaken\":\"AfterFood\",\"MedicineTakenTime\":1722502800000,\"MedicineStatus\":6,\"MedicineAmountTaken\":50,\"MedicineLastUpdatedTime\":7558738492736,\"PatientId\":\"Arjun\",\"PrescriptionBy\":\"Renuga\"},
    {\"PrescriptionId\":\"GN20244547\",\"MedicineId\":\"Test1\",\"MedicineName\":\"Metformin\",\"MedicineTaken\":\"AfterFood\",\"MedicineTakenTime\":1722502900000,\"MedicineStatus\":6,\"MedicineAmountTaken\":50,\"MedicineLastUpdatedTime\":7558738492737,\"PatientId\":\"Arjun\",\"PrescriptionBy\":\"Renuga\"},
    {\"PrescriptionId\":\"GN20244547\",\"MedicineId\":\"Test2\",\"MedicineName\":\"Paracetamol\",\"MedicineTaken\":\"BeforeFood\",\"MedicineTakenTime\":1722503000000,\"MedicineStatus\":5,\"MedicineAmountTaken\":500,\"MedicineLastUpdatedTime\":7558738492740,\"PatientId\":\"Arjun\",\"PrescriptionBy\":\"Renuga\"},
    {\"PrescriptionId\":\"GN20244548\",\"MedicineId\":\"Test3\",\"MedicineName\":\"Aspirin\",\"MedicineTaken\":\"AfterFood\",\"MedicineTakenTime\":1722503100000,\"MedicineStatus\":5,\"MedicineAmountTaken\":100,\"MedicineLastUpdatedTime\":7558738492750,\"PatientId\":\"Karthik\",\"PrescriptionBy\":\"Renuga\"}
  ]"


{"message":"Login successful","token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiUGF0aWVudCIsInVzZXJuYW1lIjoiVXNoYSIsImhvc3BpdGFsTmFtZSI6Ikdvb2QgU2hlcGFyZCIsInNwZWNpYWxpc2F0aW9uIjpudWxsLCJpYXQiOjE3NDQ2OTU2MDksImV4cCI6MTc0NDY5OTIwOX0.LZ-qC1v4kJCSxPcb4zYJAF5sztALcSRFir6PAmiuwes","role":"Patient","username":"Usha","hospitalName":"Good Shepard","specialisation":null}

prescription - //varying not there 

{  
  "PrescriptionId" : "GN20242956",  
  "PrescriptionBy" : "Renuga",  
  "Specialization" : "General",  
  "hospitalName" : "Good Shepard",  
  "flowOnAction" : "None",  
  "prescriptionOnDate" : "2024-03-10",  
  "PrescriptionFromDate" : "2024-03-10T00:00:00+00:00",  
  "PrescriptionToDate" : "2024-04-13T00:00:00+00:00",  
  "PrescriptionIsArchived" : true,  
  "SelectedPrefix" : "Dr",  
  "PrescriptionColor" : "fa7487bb",  
  "PrescriptionLastUpdated" : 1738143036713,  
  "PatientId" : "Usha"  
}

{

"PrescriptionId": "aj3",

"PrescriptionOnDate": "2025-03-30",

"PrescriptionBy": "doctor456",

"Specialization": "General",

"FlowOnAction": "ressst",

"PrescriptionFromDate": "2025-03-31 00:00:00",

"PrescriptionToDate": "2025-03-31 00:00:00",

"PrescriptionIsArchived": true,

"SelectedPrefix": "dr",

"PrescriptionColor": "VOU3470",

"PrescriptionLastUpdated": "170098834455",

"PatientId": "patient123",

"HospitalName": "aiims"

}

