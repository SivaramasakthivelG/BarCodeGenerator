```
@Test  
fun verify_moveFocusFromTabToRecyclerview_focusParkingView() {  
_launchFragmentInHiltContainer_<FavouriteListFragment> **{**  
val focusParkingView = mock(FocusParkingView::class._java_)  
  
Shadows.shadowOf(requireActivity()).setCurrentFocus(focusParkingView)  
this.moveFocusFromTabToRecyclerview()  
**}**  
}
```

