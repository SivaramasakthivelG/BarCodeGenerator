related: [[Market related]], [[NAV in MF]]
[[Role and functions of RBI]]

 March 2024
---
last decade profits beats market cap


![[Pasted image 20240429173018.png]]


![[Pasted image 20240429173314.png]]


![[Pasted image 20240429173547.png]]

![[Pasted image 20240429173735.png]]

![[Pasted image 20240429180416.png]]

