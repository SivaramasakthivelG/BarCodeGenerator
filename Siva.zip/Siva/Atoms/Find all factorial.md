![[Pasted image 20241001115413.png]]


```java

// User function Template for Java
class Solution {
        public static long factorial(long n){
            if(n == 0)
                return 1;
            else
                return n*factorial(n-1);
        }
    static ArrayList<Long> factorialNumbers(long n) {
        // code here
        ArrayList<Long> ar = new ArrayList<>();
        
        for(int i = 1; i <= n; i++){
            long fact = factorial(i);
            if(fact > n)
                return ar;
            else
                ar.add(fact);
        }
        
        return ar;
    }
}

```


```Java 

class Solution {
    public static ArrayList<Long> ans;
    static ArrayList<Long> factorialNumbers(long n) {
        ans = new ArrayList<>();
        getFact(1, 1, n);
        return ans;
    }
    
    public static void getFact(long currNum, long currFact, long target) {
        if(currFact > target) {
            return;
        }
        
        ans.add(currFact);
        getFact(currNum + 1, currFact * (currNum + 1), target);
    }
}

```