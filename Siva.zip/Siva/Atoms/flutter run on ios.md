
we need, rupy, rosetta and homebrew to install cocoapods -> which installs 3rd party libs for ios

create .zprofile 
- add path of homebrew 
- and source it in android studio 

brew install cocoa pods 

run done

