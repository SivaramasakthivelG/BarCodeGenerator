[[Unit Testing Android]]
[[Android Related]]


```

implementation("com.google.firebase:firebase-auth-ktx:21.1.0")
implementation("com.google.android.gms:play-services-auth:20.4.1")
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.0")
implementation("androidx.lifecycle:lifecycle-runtime-compose:2.6.0")
implementation("androidx.navigation:navigation-compose:2.5.3")
implementation("io.coil-kt:coil-compose:2.2.2")

// Dagger Hilt
implementation("com.google.dagger:hilt-android:2.45")
kapt("com.google.dagger:hilt-android-compiler:2.45")
kapt("androidx.hilt:hilt-compiler:1.0.0")
implementation("androidx.hilt:hilt-navigation-compose:1.0.0")


```