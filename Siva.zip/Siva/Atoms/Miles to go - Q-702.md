As the next step of change I would like to ---------
because I want --------

