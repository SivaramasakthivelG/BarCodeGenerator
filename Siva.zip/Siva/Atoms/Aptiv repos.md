
Internal KT aptiv
---

ENTERTAINMENT -   
git clone "[https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/EntertainmentHMI"](https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/EntertainmentHMI%22 "https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/entertainmenthmi%22") && (cd "EntertainmentHMI" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)

DT RadioHMi -  
git clone "[https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/RadioHMI"](https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/RadioHMI%22 "https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/radiohmi%22") && (cd "RadioHMI" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)

DT mediaHmi -  
git clone "[https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/Media"](https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/Media%22 "https://gitgerrit.asux.aptiv.com/specific/dt/hmi_evo/packages/gradle/media%22") && (cd "Media" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)


### Ihp

CNHI ihp_mediahmi


git clone "[https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/gradle/Media"](https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/gradle/Media%22 "https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/gradle/media%22") && (cd "Media" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)

RadioService repo

git clone "[https://gitgerrit.asux.aptiv.com/infotain/android/packages/gradle/RadioService"](https://gitgerrit.asux.aptiv.com/infotain/android/packages/gradle/RadioService%22 "https://gitgerrit.asux.aptiv.com/infotain/android/packages/gradle/radioservice%22") && (cd "RadioService" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)


CNHI_setting repo:

git clone "[https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/apps/Settings"](https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/apps/Settings%22 "https://gitgerrit.asux.aptiv.com/specific/cnhi/ihp/packages/apps/settings%22") && (cd "Settings" && mkdir -p .git/hooks && curl -Lo `git rev-parse --git-dir`/hooks/commit-msg [https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;](https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg; "https://gitgerrit.asux.aptiv.com/tools/hooks/commit-msg;") chmod +x `git rev-parse --git-dir`/hooks/commit-msg)


