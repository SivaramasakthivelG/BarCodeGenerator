
All icon figma for aptiv
https://www.figma.com/file/nSBjicWpOalQYexNeYkgPw/CNHi_Visual-Design_Baseline?type=design&node-id=1-2&mode=design&t=Pwsi5BbgvIWzr4OV-0


pressed state effects
https://www.figma.com/file/nSBjicWpOalQYexNeYkgPw/CNHi_Visual-Design_Baseline?type=design&node-id=14460-226402&mode=design&t=nj8ZNloZ6EybS7qP-0

others:

[11:22] R, Vadivel

SWDL: [https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=21016%3A845198&mode=design&t=XALJFe4vrwUZwkFO-1](https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=21016%3A845198&mode=design&t=XALJFe4vrwUZwkFO-1 "https://www.figma.com/file/gizyvcjucn7t5jhslglhwg/cnhi_final_visual-design?type=design&node-id=21016%3a845198&mode=design&t=xaljfe4vrwuzwkfo-1")

[11:22] R, Vadivel

TELEMATICS: [https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=20167%3A786266&mode=design&t=XALJFe4vrwUZwkFO-1](https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=20167%3A786266&mode=design&t=XALJFe4vrwUZwkFO-1 "https://www.figma.com/file/gizyvcjucn7t5jhslglhwg/cnhi_final_visual-design?type=design&node-id=20167%3a786266&mode=design&t=xaljfe4vrwuzwkfo-1")

[11:23] R, Vadivel

Engineering Menu: [https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=24996%3A674630&mode=design&t=XALJFe4vrwUZwkFO-1](https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=24996%3A674630&mode=design&t=XALJFe4vrwUZwkFO-1 "https://www.figma.com/file/gizyvcjucn7t5jhslglhwg/cnhi_final_visual-design?type=design&node-id=24996%3a674630&mode=design&t=xaljfe4vrwuzwkfo-1")

[11:26] R, Vadivel

Vehicle: [https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=16212%3A689435&mode=design&t=XALJFe4vrwUZwkFO-1](https://www.figma.com/file/GIzyvcjuCN7t5JhSLgLhwG/CNHi_Final_Visual-Design?type=design&node-id=16212%3A689435&mode=design&t=XALJFe4vrwUZwkFO-1 "https://www.figma.com/file/gizyvcjucn7t5jhslglhwg/cnhi_final_visual-design?type=design&node-id=16212%3a689435&mode=design&t=xaljfe4vrwuzwkfo-1")