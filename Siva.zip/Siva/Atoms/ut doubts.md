onconfiguration changed
shadow problem
adapter issue 