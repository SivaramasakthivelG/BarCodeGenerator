[[Hashing]]

[[Recursion fundmental]]

[[Recursion problems]]

----

Base condition - Base condition is where the recursion will stop making new calls.