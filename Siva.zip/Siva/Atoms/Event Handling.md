---
Testing: JavaReflection,Fragment,EventHandling
---


![[FragmentCategoryListingTest (1).kt]]





