

Bug Fixing Quality

Definition: No. of Bugs Reopened / Total No. of Bugs Closed

How to Measure: Analyze data from a Defect Management Tool (e.g., JIRA, Digite, Elementool) 

Target: 0 

---


Quality

Definition: No. of MISRA Warnings / Coding Guidance Violations found after code is committed

How to Measure: Use a code analysis tool or system (like static code analysis tools) to identify and count MISRA warnings and coding guideline violations post code commit.

Target: 0 warning/violations

---

Unit Test Coverage

Definition: Statement Coverage & Branch Coverage

How to Measure: Utilize a Code Coverage Tool (e.g., TestCocoon, BullsEye) 

Target: 100% Statement Coverage; 85% Branch Coverage 

---


Schedule Adherence

Definition: No. of Tasks completed on Time / Total No. of Tasks Assigned

How to Measure: Track tasks and timelines using a Project Management Tool 

Target: 100% 

---


Implementation Productivity

Definition: No. of executable Lines of Code produced / man day  
(Produced means implemented, Static analysis & Unit Tested & Verified; Code to Comment Ratio should be 1 : 0.9)

How to Measure: Take the data from the GIT server - Codes checked in by you as 'Author' (or) Manually measure using a tool like "LOCMetrics"

Target: 15 LOC / Man day 