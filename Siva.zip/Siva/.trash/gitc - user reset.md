git config --global --unset credential.helper

git config --global credential.helper store


