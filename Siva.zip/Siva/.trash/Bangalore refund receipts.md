4th march(Monday) - 8th march spendings.

Monday
- Majestic to bloom hotel (bus) - 40 rupees
- Bloom hotel to Brigade tech gardens (Auto) - 60 

Tuesday - Friday (with bus return ticket)
2152

Total
2152+100 = 2252
