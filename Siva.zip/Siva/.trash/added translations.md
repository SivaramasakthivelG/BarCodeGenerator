audio settings - from sourceselection page
