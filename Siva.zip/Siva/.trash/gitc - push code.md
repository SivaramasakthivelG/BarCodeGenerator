
related: [[gitc - user reset]]

---
git push origin HEAD:refs/for/master

