Sleeping time matters even on weekends 

