**Win + D** - To minimize and maximize **Current Tab**

**Win/shift/s** - To Snip using and copy to clipboard

**Win/M** (Win/shift/M) - To minimize all tabs

**Win/R** - [[windows run]]

