
    - Win + E --------------------> Opens File Manager
        
    - ENTER  ---------------------> Right click
        
    - SHIFT + F10 ---------------> Left click (or paragraph key)
        
    - BACKSPACE ----------------> Access to previous page
        
    - F2 --------------------------> Rename
        
    - F11 -------------------------> Full Screen
        
    - CTRL + SHIFT + N ---------> Create New Folder
        
    - ALT + ENTER  --------------> Opens the Properties
    
