TEXT FIELD SHORTCUTS 

**CTRL + MOVE RIGHT / MOVE LEFT**  (Shift to select text also ) -  Move the cursor faster word by word. 

**HOME**  - For start of the line 

**END** - For the end of the line 