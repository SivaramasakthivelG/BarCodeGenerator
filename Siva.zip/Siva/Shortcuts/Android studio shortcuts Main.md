
[[Androd Basic shortcuts]] - Useful to know Basic shorcuts

[[XML shorcuts]]


Personal shortcuts

