SHIFT + N  ------------------> Next Video

     SHIFT + L   ------------------> Last Video
 
     F               -------------------> To Minimize & Maximize the screen

     K               -------------------> To Pause & Play the Video

     J               -------------------> It Skips previous 10secs

     L               -------------------> It Skips Later 10secs

     C               -------------------> To access & deny the Captions
