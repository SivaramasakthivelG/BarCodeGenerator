EDIT SHORTCUTS 

**CTRL + Q** 
	- To get the return type  

**Ctrl + alt + L**           
	- to rearrange the xml blocks in order! 

**CTRL + F4**       
	- Closes the window in the android studio 

**CTRL + Y**         
	-<span style="color:#ffff00"> Delete the current line  </span>

**CTRL + C & CTRL + X**          
	- We can directly apply the lines, there is no need to select if you're going to copy the entire line! 

**CTRL + UP/DOWN**           
	- To Move the line up and down. 

**CTRL + D -** 
	To duplicate the lines  

**CTRL + SHIFT + F**
	- Searches for individual words available in xml and kotlin classes ! And
**CTRL + F** 
	only works for that particular file you work currently . 

**CTRL + SHIFT + R**
	- Replaces text with giventext in all files ! CTRL + R - Only replaces in the current file. 

**CTRL + ALT + S**  
	- To open settings ! 

**CTRL + W** 
	- Select text, it expands in awesome way just give a try ! 

**CTRL + E -**
	Searching for recent files 

**CTRL + I** 
	- Implements necessary abstract methods 

**CTRL + O** 
	- Implements overridable methods.
