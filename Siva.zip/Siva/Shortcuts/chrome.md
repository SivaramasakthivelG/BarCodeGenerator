
Related: 
	 - [[File manager]] 
	 - [[UTUBE]]


---


    - Ctrl + W --------------------> Closes the particular tab
        
    - Ctrl + N --------------------> New Chrome Page
        
    - Ctrl + J ---------------------> Opens Download page
        
    - Ctrl + H --------------------> Opens History page
        
    - Ctrl + D --------------------> Bookmarks the page
        
    - CTRL +F --------------------> Search within a webpage
        
    - Win + D --------------------> Minimize & Maximize the Page
        
    - Win + M --------------------> Minimize window
        
    - Win + V ---------------------> List of lines (clipboard)
        
    - ALT + E , s ------------------> Open settings
        
    - CTRL + SHIFT + T --------------> Reopen last closed tab
        
    - CTRL + SHIFT + M -----------------> Open different profile
        
    - CTRL + SHIFT + w --------------> Back to normal mode
        
    - CTRL + SHIFT + N ---------------> Open incognito page
        
    - CTRL + SHIFT + O -----------------> Bookmark manager
        
    - CTRL + SHIFT + DELETE -------------> Clear browsing history
        
    - CTRL +    &   CTRL - ---------> Zoom in and out
    - Ctrl + 1 - Ctrl + 9 ----------> to switch respective tabs, and ctrl 9 for rightmost   and ctrl1 for leftmost.
    - Alt + home -------------> to make the tab back to home page


##### Special
- ctrl/D + ctrl/enter = to duplicate a chrome tab



     
   
