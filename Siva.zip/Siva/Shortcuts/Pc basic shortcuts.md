When the screen is just showing the wallpaper, ***type the name of the app*** you want to open if it available in shortcut, the focus switches there!


***shift/f10*** - for mouse leftclick or paragraph button

***Alt / Space / then S*** resize a tab using arrow keys

***Alt / Space / then M*** - move tab using arrowkeys, Controlled movement using **Ctrl / Arrowkey**




