Edit & Preview - ALT + SHIFT + (RIGHT / LEFT ARROW) 

Switch Orientation - O