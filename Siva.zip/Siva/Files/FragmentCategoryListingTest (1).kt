package com.aptiv.dtsxmhmi.fragments.main

import android.content.Context
import android.os.Bundle
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragment
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ApplicationProvider
import com.aptiv.dtsxmhmi.R
import com.aptiv.dtsxmhmi.main.activities.channel_list.FragmentCategoryListing
import com.aptiv.dtsxmhmi.main.delegate.ImageDelegate
import com.aptiv.dtsxmhmi.main.events.EventServiceOnUpdate
import com.aptiv.dtsxmhmi.main.events.EventUpdateCategoryListCategories
import com.aptiv.dtsxmhmi.main.events.EventUpdateCategoryListChannels
import com.aptiv.dtsxmhmi.main.events.EventUpdateCategoryListEpisodes
import com.aptiv.dtsxmhmi.main.events.EventUpdateCategoryListSpotlightRecommendations
import com.aptiv.dtsxmhmi.shadow.ShadowBanner
import com.aptiv.dtsxmhmi.util.RecommendationsUtil
import com.siriusxm.emma.generated.Category
import com.siriusxm.emma.generated.Episode
import com.siriusxm.emma.generated.LiveChannel
import com.siriusxm.emma.generated.ServiceEvent
import com.siriusxm.emma.generated.ServiceId
import com.siriusxm.emma.generated.Show
import com.siriusxm.emma.generated.SuperCategory
import com.siriusxm.emma.generated.VectorCategory
import com.siriusxm.emma.generated.VectorEpisode
import com.siriusxm.emma.generated.VectorLiveChannel
import com.siriusxm.emma.generated.VectorSuperCategory
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers
import java.lang.reflect.Method
import java.util.Vector

//stub: VectorEpisodeData
@RunWith(RobolectricTestRunner::class)
@Config(shadows = [ShadowBanner::class])
class FragmentCategoryListingTest {

    private var fragmentScenario: FragmentScenario<FragmentCategoryListing>? = null

    private lateinit var fragmentCategoryListing: FragmentCategoryListing
    private lateinit var context: Context
    private lateinit var category: FragmentCategoryListing.CategoriesVH

    private lateinit var recommendationsUtil: RecommendationsUtil.RecommendationInfo

    private var vector = Vector<RecommendationsUtil.RecommendationInfo>()

    @Mock
    private lateinit var breadCrumbs: Pair<SuperCategory,Category>

    private lateinit var view: View
    val args = Bundle()



    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)

        vector = Vector()

        context = ApplicationProvider.getApplicationContext()
        fragmentCategoryListing = FragmentCategoryListing()


        view =
            LayoutInflater.from(context)
                .inflate(R.layout.item_category_tile, null, false)

        val imageDelegate = ImageDelegate()

//        val imageDelegate = Mockito.mock(ImageDelegate::class.java)
        category = FragmentCategoryListing.CategoriesVH(view,breadCrumbs,imageDelegate)

    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun testFragmentLifeCycle() {
        val b = Bundle()
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED
            )
        fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
        fragmentScenario!!.onFragment { fragment ->
            fragment.onCreate(b)
            fragmentScenario!!.onFragment { fragment ->
                fragment.onStart()
                fragmentScenario!!.onFragment { fragment ->
                    fragment.onResume()
                    fragmentScenario!!.onFragment { fragment ->
                        fragment.onPause()
                        fragmentScenario!!.onFragment { fragment ->
                            fragment.onStop()
                            fragmentScenario!!.onFragment { fragment -> fragment.onDestroy() }
                        }
                    }
                }
            }
        }
    }

    @Test
    fun test_removeSpotlightRecommendations() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            ReflectionHelpers.callInstanceMethod<Void>(it,"removeSpotlightRecommendations")

        }
    }

    @Test
    fun test_onItemClicked() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            val show = Show()
            recommendationsUtil = Mockito.mock(RecommendationsUtil.RecommendationInfo::class.java)

            val recommendationsUtil1 = RecommendationsUtil.RecommendationInfoType.LiveChannel

            Mockito.`when`(recommendationsUtil.type).thenReturn(recommendationsUtil1)
            Mockito.`when`(recommendationsUtil.show).thenReturn(show)


            it.onItemClicked(recommendationsUtil,0)
//            it.onItemClicked(recommendationsUtil,1)

        }
    }

    @Test
    fun test_onItemClicked_if_and_elseCase() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            recommendationsUtil = Mockito.mock(RecommendationsUtil.RecommendationInfo::class.java)

            val recommendationsUtil1 = RecommendationsUtil.RecommendationInfoType.ArtistRadioChannel

            Mockito.`when`(recommendationsUtil.type).thenReturn(recommendationsUtil1)

            it.onItemClicked(recommendationsUtil,0)
            val recommendationsUtil11 = RecommendationsUtil.RecommendationInfoType.Show

            //elseif

            var show = Mockito.mock(Show::class.java)
            Mockito.`when`(recommendationsUtil.type).thenReturn(recommendationsUtil11)
            Mockito.`when`(recommendationsUtil.show).thenReturn(show)

            it.onItemClicked(recommendationsUtil,0)

        }
    }


    @Test
    fun test_extractRecommendedShowEpisodes() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            val show = Show()

            ReflectionHelpers.callInstanceMethod<Void>(it,"extractRecommendedShowEpisodes",
                ReflectionHelpers.ClassParameter(Show::class.java,show))
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_extractRecommendedShowEpisodes_StatusError() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            val show = Show()

            ReflectionHelpers.callInstanceMethod<Void>(it,"extractRecommendedShowEpisodes",
                ReflectionHelpers.ClassParameter(Show::class.java,show))
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }


    //Adapter class
    @Test
    fun test_categoriesAdapter() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            val liveChannel = VectorLiveChannel()
            val liveCategory = VectorCategory()
            val vectorEpisode = VectorEpisode()

            it.categoriesAdapter.onCreateViewHolder(it.view as ViewGroup,0)

            it.categoriesAdapter.updateChannels(liveChannel)
            it.categoriesAdapter.updateCategories(liveCategory)
            it.categoriesAdapter.updateEpisodes(vectorEpisode)

        }
    }

    @Test
    fun test_categoriesAdapter_onBindViewHolder() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            category = Mockito.mock(FragmentCategoryListing.CategoriesVH::class.java)
            val bindView = Mockito.mock(SuperCategory::class.java)
            val superCategory = Mockito.mock(VectorSuperCategory::class.java)
            ReflectionHelpers.setField(it.categoriesAdapter,"superCategories",superCategory)
            Mockito.`when`(superCategory.at(Mockito.anyLong())).thenReturn(bindView)
            it.categoriesAdapter.onBindViewHolder(category,1)
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_categoriesAdapter_onBindViewHolder_tileTypeCategory() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            category = Mockito.mock(FragmentCategoryListing.CategoriesVH::class.java)
            val tileType = FragmentCategoryListing.TileType.Category
            ReflectionHelpers.setField(it.categoriesAdapter,"tileType",tileType)
            it.categoriesAdapter.onBindViewHolder(category,1)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }
    @Test
    fun test_categoriesAdapter_onBindViewHolder_tileTypeChannel() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            category = Mockito.mock(FragmentCategoryListing.CategoriesVH::class.java)
            val tileType = FragmentCategoryListing.TileType.Channel
            ReflectionHelpers.setField(it.categoriesAdapter,"tileType",tileType)
            it.categoriesAdapter.onBindViewHolder(category,1)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }


    @Test
    fun test_categoriesAdapter_onBindViewHolder_tileTypeEpisode() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            category = Mockito.mock(FragmentCategoryListing.CategoriesVH::class.java)
            val tileType = FragmentCategoryListing.TileType.Episode
            ReflectionHelpers.setField(it.categoriesAdapter,"tileType",tileType)
            it.categoriesAdapter.onBindViewHolder(category,1)
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }

    @Test
    fun test_setupEvents_onUpdate() {
        val scenario = launchFragment<FragmentCategoryListing>()
            scenario.onFragment{

                val serviceId = Mockito.mock(ServiceId::class.java)
                val serviceEvent = Mockito.mock(ServiceEvent::class.java)

                val eventServiceOnUpdate = EventServiceOnUpdate(serviceId, serviceEvent)

                eventServiceOnUpdate.emit()
            }
    }


    @Test
    fun test_setupEvents_listCategories() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment{

            val serviceId = Mockito.mock(ServiceId::class.java)
            val categories = Mockito.mock(VectorCategory::class.java)

            val eventUpdateCategoryListCategories = EventUpdateCategoryListCategories("Title",categories)

            eventUpdateCategoryListCategories.emit()

            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_setupEvents_listChannels() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment{

            val serviceId = Mockito.mock(ServiceId::class.java)
            val channels = Mockito.mock(VectorLiveChannel::class.java)

            val eventUpdateCategoryListChannels = EventUpdateCategoryListChannels("Title",channels)

            eventUpdateCategoryListChannels.emit()

            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }



    @Test
    fun test_setupEvents_recommendations() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment{

            val eventUpdateCategoryListSpotlightRecommendations =
                EventUpdateCategoryListSpotlightRecommendations(vector)

            eventUpdateCategoryListSpotlightRecommendations.emit()

            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_setupEvents_listEpisodes() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment{

            val episodes = Mockito.mock(VectorEpisode::class.java)

            val eventUpdateCategoryListEpisodes =
                EventUpdateCategoryListEpisodes(episodes)

            eventUpdateCategoryListEpisodes.emit()

            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_setupEvents_ChannelList() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment{

            val method: Method = FragmentCategoryListing::class.java.getDeclaredMethod("updateData",
                FragmentCategoryListing.TileType::class.java,
                Pair::class.java)
            method.isAccessible = true
            method.invoke(it, FragmentCategoryListing.TileType.Channel, breadCrumbs)


            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }

    //categoriesVH
    @Test
    fun test_bindView() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {

            val mockCategory = Mockito.mock(Category::class.java)
            val mockEpisode = Mockito.mock(Episode::class.java)
            val mockSuperCategory = Mockito.mock(SuperCategory::class.java)

            val button = ReflectionHelpers.getField<ConstraintLayout>(category,"clItemGroup")

            category.bindView(mockCategory)
            button.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()

            category.bindView(mockEpisode)
            button.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()


            category.bindView(mockSuperCategory)
            button.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }

    }

    @Test
    fun test_bindView_setOnLongClickListener_Channel() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {

            val mockChannel = Mockito.mock(LiveChannel::class.java)

            val button = ReflectionHelpers.getField<ConstraintLayout>(category,"clItemGroup")


            ShadowBanner.setActionLink("")
            category.bindView(mockChannel)
            button.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()


        }

    }


    @Test
    fun test_bindView_setOnLongClickListener_Episode() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {

            val mockEpisode = Mockito.mock(Episode::class.java)

            val button = ReflectionHelpers.getField<ConstraintLayout>(category,"clItemGroup")


            ShadowBanner.setActionLink("")
            category.bindView(mockEpisode)
            button.performLongClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()


        }

    }

    @Test
    fun test_bindView_Channel_elseCase() {

        val mockChannel = Mockito.mock(LiveChannel::class.java)
        val button = ReflectionHelpers.getField<ConstraintLayout>(category,"clItemGroup")
        Mockito.`when`(mockChannel.isMixChannel).thenReturn(true)
        category.bindView(mockChannel)
        Shadows.shadowOf(Looper.getMainLooper()).idle()
        button.performClick()
    }

    @Test
    fun test_bindView_Episode_setOnLongClickListener() {

        val mockChannel = Mockito.mock(Episode::class.java)
        val button = ReflectionHelpers.getField<ConstraintLayout>(category,"clItemGroup")

        category.bindView(mockChannel)
        Shadows.shadowOf(Looper.getMainLooper()).idle()
        button.performLongClick()
    }

    @Test
    fun test_bindView_Banner_isNotEmpty_Channel() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.onFragment {

            ShadowBanner.setActionLink("work")
            val mockChannel = Mockito.mock(LiveChannel::class.java)
            val button = ReflectionHelpers.getField<ConstraintLayout>(category, "clItemGroup")

            category.bindView(mockChannel)
            button.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }
    }

    @Test
    fun test_bindView_Banner_isNotEmpty_Episode() {
        val scenario = launchFragment<FragmentCategoryListing>()
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onFragment {


            ShadowBanner.setActionLink("work")
            val mockEpisode = Mockito.mock(Episode::class.java)
            val button = ReflectionHelpers.getField<ConstraintLayout>(category, "clItemGroup")

            category.bindView(mockEpisode)
            button.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()

        }
    }





}