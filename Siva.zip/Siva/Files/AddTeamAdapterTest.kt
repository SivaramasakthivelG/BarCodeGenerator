package com.aptiv.dtsxmhmi.fragments.adapter

import android.content.Context
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ApplicationProvider
import com.aptiv.dtsxmhmi.R
import com.aptiv.dtsxmhmi.databinding.AddTeamItemBinding
import com.aptiv.dtsxmhmi.main.fragments.adapter.AddTeamAdaptor
import com.aptiv.dtsxmhmi.shadow.ShadowVectorSportsFavoriteItem
import com.aptiv.dtsxmhmi.util.AlertsUtil
import com.aptiv.dtsxmhmi.util.DialogUtils
import com.google.common.truth.Truth
import com.siriusxm.emma.generated.ImageSet
import com.siriusxm.emma.generated.SportsTeam
import com.siriusxm.emma.generated.Status
import com.siriusxm.emma.generated.VectorSportsFavoriteItem
import junit.framework.TestCase
import kotlinx.android.synthetic.main.generic_custom_listitems.view.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

/** Verifying all the callbacks and APIs in the SportsCountAdapter class */
@RunWith(RobolectricTestRunner::class)
@Config(shadows = [ShadowVectorSportsFavoriteItem::class])
class AddTeamAdapterTest {
    lateinit var binding: AddTeamItemBinding
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: AddTeamAdaptor
    lateinit var itemList: ArrayList<SportsTeam>
    lateinit var context: Context
    lateinit var alertsUtil: AlertsUtil
    lateinit var sportAlerts: VectorSportsFavoriteItem
    //    lateinit var itemClickListener: AddTeamAdaptor.ItemClickListener
    //    lateinit var addTeamAdaptorViewHolder: AddTeamAdaptor.ViewHolder

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        context = ApplicationProvider.getApplicationContext()
        alertsUtil = Mockito.mock(AlertsUtil::class.java)
        sportAlerts = Mockito.mock(VectorSportsFavoriteItem::class.java)
        recyclerView = RecyclerView(ApplicationProvider.getApplicationContext())
        recyclerView.layoutManager =
            LinearLayoutManager(ApplicationProvider.getApplicationContext())
        itemList = arrayListOf(buildRacoonTeams(), buildFreyTeams())
        adapter = AddTeamAdaptor(context, itemList)
        recyclerView.adapter = adapter

        val layoutInflater =
            ApplicationProvider.getApplicationContext<Context>()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as
                LayoutInflater
        binding = AddTeamItemBinding.inflate(layoutInflater)

        ShadowVectorSportsFavoriteItem.setSizeData(5)
        Shadows.shadowOf(Looper.getMainLooper()).idle()

    }

    fun buildRacoonTeams(): SportsTeam {
        val sportsTeam = Mockito.mock(SportsTeam::class.java)
        Mockito.`when`(sportsTeam.name()).thenReturn("Raccoon")
        Mockito.`when`(sportsTeam.nickname()).thenReturn("Raccoon")
        Mockito.`when`(sportsTeam.isFavorite).thenReturn(true)
        Mockito.`when`(sportsTeam.leagueId()).thenReturn(111)
        Mockito.`when`(sportsTeam.teamId()).thenReturn(1234789)
        Mockito.`when`(sportsTeam.getImageSet(Mockito.any())).thenReturn(Status.OK)
        return sportsTeam
    }

    fun buildFreyTeams(): SportsTeam {
        val sportsTeam = Mockito.mock(SportsTeam::class.java)
        Mockito.`when`(sportsTeam.name()).thenReturn("Frey")
        Mockito.`when`(sportsTeam.nickname()).thenReturn("Frey")
        Mockito.`when`(sportsTeam.isFavorite).thenReturn(false)
        Mockito.`when`(sportsTeam.leagueId()).thenReturn(122)
        Mockito.`when`(sportsTeam.teamId()).thenReturn(1313678)
        return sportsTeam
    }

    fun buildNullTeams(): SportsTeam {
        val sportsTeam = Mockito.mock(SportsTeam::class.java)
        Mockito.`when`(sportsTeam.name()).thenReturn(null)
        Mockito.`when`(sportsTeam.nickname()).thenReturn(null)
        Mockito.`when`(sportsTeam.isFavorite).thenReturn(false)
        Mockito.`when`(sportsTeam.leagueId()).thenReturn(133)
        Mockito.`when`(sportsTeam.teamId()).thenReturn(1313678)
        return sportsTeam
    }

    /** verify the Adapter is Loading */
    @Test
    fun testAdapterIsNotEmpty() {
        TestCase.assertNotNull(adapter)
    }

    /** To test itemCount of adapter */
    @Test
    fun testItemCount() {
        TestCase.assertEquals(adapter.itemCount, itemList.size)
    }

    /** To test CreateViewHolder returns not null */
    @Test
    fun testCreateViewHolder() {
        (binding!!.root as ViewGroup?)?.let {
            adapter.onCreateViewHolder(it, R.layout.add_team_item)
        }
        TestCase.assertNotNull(binding!!.root)
        Truth.assertThat(binding!!.teamLogo).isNotNull()
        Truth.assertThat(binding!!.textViewSportTeamName).isNotNull()
    }

    /** To test live sports count is Zero */
    @Test
    fun testBindViewHolderPosZero() {
        (binding!!.root as ViewGroup?)?.let {
            val t = Pair(itemList[0].leagueId(), itemList[0].teamId())
            val teamStr = "${itemList[0]?.name()} ${itemList[0]?.nickname()}"
            Mockito.`when`(alertsUtil.isSportsTeamInAlerts(teamStr)).thenReturn(t)
            val vh = adapter.onCreateViewHolder(it, 0)
            adapter.onBindViewHolder(vh, 0)
            //            Shadows.shadowOf(Looper.getMainLooper()).idle()
            System.out.println("item list name = ${vh.binding!!.textViewSportTeamName.text}")
            System.out.println("isChecked before = ${vh.binding!!.toggleTeam.isChecked}")
            //            Truth.assertThat(vh.binding!!.toggleTeam.isChecked).isTrue()

            ShadowVectorSportsFavoriteItem.setSizeData(31)
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            vh.binding.addTeamItem.performClick()
            //     Shadows.shadowOf(Looper.getMainLooper()).idle()
            Truth.assertThat(vh.binding!!.textViewSportTeamName.text).isEqualTo(itemList[0].name())
            Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }

    @Test
    fun testBindViewHolderMaxAlerts() {
        (binding!!.root as ViewGroup?)?.let {
            val t = Pair(itemList[0].leagueId(), itemList[0].teamId())
            val teamStr = "${itemList[0]?.name()} ${itemList[0]?.nickname()}"
            Mockito.`when`(alertsUtil.isSportsTeamInAlerts(teamStr)).thenReturn(t)

            Mockito.`when`(sportAlerts.size()).thenReturn(30)
            Mockito.`when`(alertsUtil.getSportsAlerts()).thenReturn(sportAlerts)

            val vh = adapter.onCreateViewHolder(it, 0)
            adapter.onBindViewHolder(vh, 0)
            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            Truth.assertThat(vh.binding!!.textViewSportTeamName.text).isEqualTo(itemList[0].name())
            Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }

    @Test
    fun testBindViewHolderPosOne() {
        (binding!!.root as ViewGroup?)?.let {
            val vh = adapter.onCreateViewHolder(it, 0)
            adapter.onBindViewHolder(vh, 1)
            //            Shadows.shadowOf(Looper.getMainLooper()).idle()
            System.out.println("item list name = ${vh.binding!!.textViewSportTeamName.text}")
            System.out.println("isChecked before = ${vh.binding!!.toggleTeam.isChecked}")

            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            Truth.assertThat(vh.binding!!.textViewSportTeamName.text).isEqualTo(itemList[1].name())
            Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }

    @Test
    fun testBindViewHolderPosOneNull() {
        (binding!!.root as ViewGroup?)?.let {
            itemList = arrayListOf(buildRacoonTeams(), buildNullTeams())
            adapter = AddTeamAdaptor(context, itemList)
            recyclerView.adapter = adapter
            val vh = adapter.onCreateViewHolder(it, 0)
            adapter.onBindViewHolder(vh, 1)
            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            // Truth.assertThat(vh.binding!!.textViewSportTeamName.text).isEqualTo(itemList[1].name())
            // Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            // System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }

    @Test
    fun testBindViewHolderFocusedItem() {
        (binding!!.root as ViewGroup?)?.let {
            val vh = adapter.onCreateViewHolder(it, 0)
            vh.view.requestFocus()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            adapter.onBindViewHolder(vh, 0)
            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            Truth.assertThat(vh.view.isFocused).isTrue()
            // Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            // System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }

    @Test
    fun testBindViewHolderLoadImageTest() {

        (binding!!.root as ViewGroup?)?.let {
            val vh = adapter.onCreateViewHolder(it, 0)
            val imgSet = Mockito.mock(ImageSet::class.java)
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            adapter.onBindViewHolder(vh, 1)
            Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            adapter.onBindViewHolder(vh, 0)
        }
    }

    @Test
    fun testMaxAlerts() {
        (binding!!.root as ViewGroup?)?.let {
            val vh = adapter.onCreateViewHolder(it, 0)
            val t = Pair(itemList[1].leagueId(), itemList[1].teamId())
            //            val timber = Mockito.mock(Timber::class.java)
            //            val imgSet = Mockito.mock(ImageSet::class.java)
            val dialogUtils = Mockito.mock(DialogUtils::class.java)
            val alertsUtilStatic = Mockito.mockStatic(AlertsUtil::class.java)
            val alertsUtil = Mockito.mock(AlertsUtil::class.java)
            val sportAlerts = Mockito.mock(VectorSportsFavoriteItem::class.java)
            Mockito.`when`(sportAlerts.size()).thenReturn(0)
            Mockito.`when`(alertsUtil.getSportsAlerts()).thenReturn(sportAlerts)
            val teamStr = "${itemList[0]?.name()} ${itemList[0]?.nickname()}"
            Mockito.`when`(alertsUtil.isSportsTeamInAlerts(teamStr)).thenReturn(t)
            adapter.onBindViewHolder(vh, 0)
            System.out.println("before isChecked = ${vh.binding!!.toggleTeam.isChecked}")
            //            Shadows.shadowOf(Looper.getMainLooper()).idle()
            vh.binding.addTeamItem.performClick()
            Shadows.shadowOf(Looper.getMainLooper()).idle()
            //            Mockito.verify(dialogUtils).showMaxNotificationDialog(context)
            //
            // Mockito.verify(alertsUtil).addSportsAlert(itemList[1].leagueId(),itemList[1].teamId())
            //            Mockito.verifyNoInteractions(Timber.i("onBindViewHolder"))
            //            Mockito.verifyNoInteractions(imgSet)
            // Truth.assertThat(vh.binding!!.teamLogo.isVisible).isTrue()
            System.out.println("isChecked = ${vh.binding!!.toggleTeam.isChecked}")
        }
    }
}
