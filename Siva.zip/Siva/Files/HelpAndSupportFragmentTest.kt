package com.aptiv.dtsxmhmi.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.MutableLiveData
import androidx.test.core.app.ApplicationProvider
import com.aptiv.dtsxmhmi.ServiceUtil
import com.aptiv.dtsxmhmi.databinding.FragmentHelpSupportBinding
import com.aptiv.dtsxmhmi.main.fragments.main.HelpAndSupportFragment
import com.aptiv.dtsxmhmi.main.managers.SxmDeviceManager
import com.aptiv.dtsxmhmi.shadow.ShawdowFragment
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Spy
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(shadows = [ShawdowFragment::class])
class HelpAndSupportFragmentTest {

    @Spy
    lateinit var sxmDeviceManager: SxmDeviceManager

    lateinit var helpAndSupportFragment: HelpAndSupportFragment
    var fragmentScenario: FragmentScenario<HelpAndSupportFragment>? = null
    @Mock var isdeviceAvaiable = MutableLiveData<Boolean>(true)
    @Mock lateinit var binding: FragmentHelpSupportBinding

    @Before
    fun setUp() {
        helpAndSupportFragment = HelpAndSupportFragment()
        val inflater = LayoutInflater.from(ApplicationProvider.getApplicationContext())

        sxmDeviceManager = SxmDeviceManager()
        binding = FragmentHelpSupportBinding.inflate(inflater)

    }

    @After fun tearDown() {}

    @Test
    fun testFragmentLifeCycle() {
        // test setup
        val args = Bundle()
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)
        ShawdowFragment.setResource(ApplicationProvider.getApplicationContext<Context>().resources)
        // Move the fragment to the RESUMED state
        fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)

        var fragment: HelpAndSupportFragment? = null

        // Test action
        fragmentScenario!!.onFragment { fragmentInstance ->
            fragment = fragmentInstance

            // Ensure the fragment is in the RESUMED state
            Assert.assertEquals(Lifecycle.State.RESUMED, fragmentInstance.lifecycle.currentState)

            // Move the fragment to the PAUSED state
            fragmentScenario!!.moveToState(Lifecycle.State.CREATED)
        }

        // Verify the fragment's state after the action
        Assert.assertNotNull(fragment) // Ensure the fragment instance is not null
        Assert.assertEquals(Lifecycle.State.CREATED, fragment?.lifecycle?.currentState)
    }

    @Test
    fun test_oncreateView() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)

        fragmentScenario!!.onFragment { fragmentInstance ->
            fragment = fragmentInstance
            ReflectionHelpers.setField(fragment, "isDeviceAvailable", true)
            fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
            binding = ReflectionHelpers.getField(fragment, "binding")
            binding.contact.relat.performClick()
            binding.contact.relat.isPressed = true
            binding.contact.relat.requestFocus()
        }
    }

    @Test
    fun test_oncreateView_isDeviceAvailable() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        val inflater = LayoutInflater.from(ApplicationProvider.getApplicationContext())
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)
        fragmentScenario!!.onFragment { fragmentInstance ->

           val livedate =  SxmDeviceManager::class.java.getDeclaredField("_isDeviceAvailable")
            livedate.isAccessible = true
        val test =    livedate.get(ServiceUtil.INSTANCE.serviceManager) as MutableLiveData<Boolean>
            test.value = false
            test.value = true

            fragment = fragmentInstance
            ReflectionHelpers.setField(fragment, "isDeviceAvailable", true)
            ShawdowFragment.setResource(
                ApplicationProvider.getApplicationContext<Context>().resources)
            fragment!!.onCreateView(inflater, binding.root as ViewGroup, args)
            binding = ReflectionHelpers.getField(fragment, "binding")
            binding.contact.relat.performClick()
            binding.contact.relat.isPressed = true
            binding.contact.relat.requestFocus()
        }
    }

    @Test
    fun test_oncreateView_isDeviceAvailable_else() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        val inflater = LayoutInflater.from(ApplicationProvider.getApplicationContext())
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)
        fragmentScenario!!.onFragment { fragmentInstance ->

            val livedate =  SxmDeviceManager::class.java.getDeclaredField("_isDeviceAvailable")
            livedate.isAccessible = true
            val test = livedate.get(ServiceUtil.INSTANCE.serviceManager) as MutableLiveData<Boolean>
            test.value = true
            test.value = false

            fragment = fragmentInstance
            ReflectionHelpers.setField(fragment, "isDeviceAvailable", true)
            ShawdowFragment.setResource(
                ApplicationProvider.getApplicationContext<Context>().resources)
            fragment!!.onCreateView(inflater, binding.root as ViewGroup, args)
            binding = ReflectionHelpers.getField(fragment, "binding")
            binding.contact.relat.performClick()
            binding.contact.relat.isPressed = true
            binding.contact.relat.requestFocus()
        }
    }


    @Test
    fun test_OnItemClick() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)

        fragmentScenario!!.onFragment { fragmentInstance ->
            fragment = fragmentInstance
            ReflectionHelpers.setField(fragment, "isDeviceAvailable", true)
            fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
            fragment!!.OnItemClick(0)
        }
    }

    @Test
    fun test_OnFocusChangeListener() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)

        fragmentScenario!!.onFragment { fragmentInstance ->
            fragment = fragmentInstance
            ReflectionHelpers.setField(fragment, "isDeviceAvailable", true)
            fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
            binding = ReflectionHelpers.getField(fragment, "binding")
            binding.contact.relat.isPressed = true
            binding.contact.relat.onFocusChangeListener.onFocusChange(binding.contact.relat, true)
        }
    }

    @Test
    fun test_onPause() {
        val args = Bundle()
        var fragment: HelpAndSupportFragment? = null
        fragmentScenario =
            launchFragmentInContainer(
                fragmentArgs = args, initialState = Lifecycle.State.INITIALIZED)

        fragmentScenario!!.onFragment { fragmentInstance ->
            fragment = fragmentInstance
            ShawdowFragment.setResource(
                ApplicationProvider.getApplicationContext<Context>().resources)
            fragmentScenario!!.moveToState(Lifecycle.State.RESUMED)
            fragment!!.onPause()
        }
    }
}
